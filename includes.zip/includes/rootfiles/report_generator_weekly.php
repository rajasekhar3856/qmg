<?php
ini_set('display_errors', 1);
error_reporting(22517);
$path = '/var/www/html/qaportal/';
//$path = "D:\\xampp\htdocs\qmg.csscorp.com\source//";
$_SESSION['master_from_type']=1;//Changed by Subbu for Raw data not getting generated for Week41
chdir($path);
include_once("custom/settings/settings.php");
ini_set('display_errors','On'); //Off,On
include_once("includes/mysql.inc");
include_once("misc/Spreadsheet/Excel/Writer.php");
global $db_url;
cameo_connect($db_url['default_ctas']);
global $dbLink;
//$path = "D:\\xampp\htdocs\qaportal.csscorp.com\source//";
//$path = "/var/www/html/qaportal/";
$replocation = "reports/";
$report_path = $path.$replocation;
$log_file =  $path."logs/report_log.log";
$exts = ".xls";
//echo print_r($db_url)."hi";
//print_r($dbLink);
//echo "dfdsf";
$report_type = "weekly";//daily,weekly,monthly,yearly
if($report_type == "daily") {
	$startdate =  date('Y-m-d 00:00:00',mktime(0,0,0,date("m"),date("d")-1,date("Y")));
    $enddate = date('Y-m-d 23:59:59',mktime(0,0,0,date("m"),date("d")-1,date("Y")));
} elseif($report_type == "weekly") {
	 $time = strtotime("next Monday");
	   //echo date("Y-m-d H:i:s",strtotime("next Monday"));
	   $n = 6;
	   $arr = array();
		while ($n-- > 0) {
			$arr[] = array_reverse(array(
				date('Y-m-d 23:59:59', $time-=86400),   // sunday
				date('Y-m-d 00:00:00', $time-=6*86400)  // monday
			));
		}	

	$startdate = $arr[1][0];
	$enddate = $arr[1][1];

    //$startdate = date("Y-m-d 00:00:00",strtotime("last Monday"));
	//$enddate = date("Y-m-d 23:59:59",strtotime("last Sunday"));	
//exit;


} elseif($report_type == "monthly") {	
	$mm = date('m',mktime(0,0,0,date("m")-1,date("d"),date("Y")));
	if($mm == 12) {
		$yy = date('Y',mktime(0,0,0,date("m"),date("d"),date("Y")-1));
	} else {
		$yy = date('Y');
	}	
	$nodays = cal_days_in_month(CAL_GREGORIAN, $mm,$yy);
	$startdate = "$yy-$mm-01 00:00:00";
	$enddate = "$yy-$mm-$nodays 23:59:59";
} elseif($report_type == "yearly") {
	$yy = date('Y')-1;
	$startdate = "$yy-01-01 00:00:00";
	$enddate = "$yy-12-31 23:59:59";
} else {
	$startdate =  date('Y-m-d 00:00:00',mktime(0,0,0,date("m"),date("d")-1,date("Y")));
    $enddate = date('Y-m-d 23:59:59',mktime(0,0,0,date("m"),date("d")-1,date("Y")));
}
//$startdate = "2013-10-07 00:00:00";
//$enddate = "2013-10-13 23:59:59";	
$plist = "SELECT * FROM(SELECT geo.geography_name, geo.geography_id, prj.project_id, prj.project_name, sht.sheet_name,sht.sheet_id, sht.sheet_type , shtmap.form_id, frm.form_type  
            FROM tm_geography_mas geo 
            LEFT JOIN tm_projects_mas prj ON prj.project_geography=geo.geography_id
            LEFT JOIN tm_sheets_mas sht ON sht.project_id= prj.project_id 
			LEFT JOIN tm_sheet_form_map shtmap ON shtmap.sheet_id = sht.sheet_id
			LEFT JOIN tm_forms_mas frm ON frm.form_id = shtmap.form_id) x WHERE x.form_type='1'";
$plistrs = cameo_query($plist);
while($plistrow = cameo_fetch_object($plistrs)){
	$block['data']["geography"][$plistrow->geography_id]["geography_name"]=$plistrow->geography_name;
	$block['data']["geography"][$plistrow->geography_id]["projects"][$plistrow->project_id]["project_name"]=$plistrow->project_name;
	$block['data']["geography"][$plistrow->geography_id]["projects"][$plistrow->project_id]["sheets"][$plistrow->sheet_id] = array("sheet_name"=>$plistrow->sheet_name, "sheet_type"=>$plistrow->sheet_type,"form_type"=>$plistrow->form_type,"form_id"=>$plistrow->form_id);
}
//echo '<pre>';
//print_r($block['data']["geography"]);
//$block['data']["geography"] = array_slice($block['data']["geography"], 0, 1); 
//print_r($block['data']["geography"]);
//exit;
$dir = $report_path.$report_type;
$dbreportloc = $replocation.$report_type;
if(!file_exists($dir) && !is_dir($dir)) {
		mkdir($dir, 0777, true) or error_log("Can not create folder:".$dir."\r\n", 3, $log_file);
} 

$mttable='tm_user_monitoring_tmf_trans';
$timestamp = strtotime($startdate);		
if(file_exists($dir) && is_dir($dir)) {
	$report_folder = "";
	if($report_type == "daily") {												
	} elseif($report_type == "weekly") {
		$report_folder = "Week_".date("W",$timestamp);
	} elseif($report_type == "monthly") {
		$report_folder = "Month_".date("M_Y",$timestamp);
	} elseif($report_type == "yearly") {
		$report_folder = "Year_".date("Y",$timestamp);
	}
	$rdir = $dir."/".$report_folder;
	$dbrdir = $dbreportloc."/".$report_folder;
	if(!file_exists($rdir) && !is_dir($rdir)) {
		mkdir($rdir, 0777, true) or error_log("Can not create folder:".$rdir."\r\n", 3, $log_file);
	} 
	if(file_exists($rdir) && is_dir($rdir)) {
		if(is_array($block['data']["geography"]) && !empty($block['data']["geography"])) {
			foreach($block['data']["geography"] as $geo=>$geolocation) {
				if(is_array($geolocation["projects"]) && !empty($geolocation["projects"])) {
					foreach($geolocation["projects"] as  $proid=>$projects) {		
						if(is_array($projects['sheets']) && !empty($projects['sheets'])) {
							foreach($projects['sheets'] as $shid=>$sheetinfo) {								
								if($sheetinfo['form_type'] == 1) {
									$sheet_name = preg_replace('/\s+/', '_', $sheetinfo['sheet_name']);											
									$timestamp = strtotime($startdate);											
									$report_prefix = "Day_".date("Y_m_d",$timestamp);
									if($report_type == "daily") {												
									} elseif($report_type == "weekly") {
										$report_prefix = "Week_".date("W",$timestamp);
									} elseif($report_type == "monthly") {
										$report_prefix = "Month_".date("M_Y",$timestamp);
									} elseif($report_type == "yearly") {
										$report_prefix = "Year_".date("Y",$timestamp);
									}
									$projectid = $proid;
									$sheetid = $shid;	
									$startdate = date("Y-m-d",strtotime($startdate));
									$enddate = date("Y-m-d",strtotime($enddate));												
									$sstime = time();
									$fname = $report_prefix."_".$geolocation["geography_name"]."_".$projects['project_name']."_".$sheet_name.$exts;
									$filename = $rdir."/".$fname;
									//if(isset($excel))
										//unset($excel);
									//echo "<br>==>>>".$sheetinfo['sheet_name']."===".$filename."===".$projectid."==".$sheetid."==".$startdate."===".$enddate."==".$filename;
									$excel = new Spreadsheet_Excel_Writer($filename);
                                                                        $excel->setVersion(8); // Use Excel97/2000 Format, IF content length > 255 it'll help us get more
                                                                        $percent_format =& $excel->addFormat();
                                                                        $date_format =& $excel->addFormat();
                                                                        $date_format->setNumFormat('D-MM-YYYY');
                                                                        $date_format->setTextWrap();
                                                                        $date_time_format =& $excel->addFormat();
                                                                        $date_time_format->setNumFormat('YYYY-MM-D h:mm:ss');
                                                                        $date_time_format->setTextWrap();

                                                                        $forms_ver_sql = "SELECT fver.id,frm.form_id,frm.form_name,fver.created_date,fver.version  
                                                                                FROM `tm_sheet_versions` fver
                                                                                LEFT JOIN tm_forms_mas frm ON frm.form_id = fver.form_id 	
                                                                        WHERE fver.`sheet_id` ='%s' AND DATE(fver.created_date) <= '%s' AND frm.form_type = 1 ORDER BY created_date DESC";//BETWEEN '%s' AND '%s'
                                                                        //echo sprintf($forms, $sheet_id,$startdate,$enddate);
                                                                        $form_ver_rs = cameo_query($forms_ver_sql, $sheetid, $enddate);//,$startdate
                                                                        $version = array();
                                                                        if(cameo_num_rows($form_ver_rs) > 0) {
                                                                                        $i = cameo_num_rows($form_ver_rs);
                                                                                        $lastversion='';
                                                                                        while($ver_row = cameo_fetch_object($form_ver_rs)){
                                                                                                if($lastversion!='')
                                                                                                $tillvesion="_to_".date("d-m-y",strtotime($lastversion));
                                                                                                else
                                                                                                $tillvesion='';
                                                                                                $_version_name = 'Version_'.$i.'_'.date("d-m-y",strtotime($ver_row->created_date)).$tillvesion;
                                                                                                $version[] = array($ver_row->version,$ver_row->form_id,$ver_row->form_name,$_version_name);
                                                                                                $lastversion=$ver_row->created_date;
                                                                                                $i--;
                                                                                        }
                                                                        //print_r($version);exit;
                                                                                        if(is_array($version) && !empty($version)) {
                                                                                        $cfheader = "SELECT scf.cf_id, cf.cf_name, cf.cf_type FROM tm_sheet_custom_field_map scf                 
                                                                                        LEFT JOIN tm_custom_field_mas cf ON cf.cf_id=scf.cf_id
                                                                                        WHERE scf.sheet_id=%d group by scf.cf_id ORDER BY scf.cf_order";
                                                                                        //$block["cfheaders"][$cfheadrow->cf_id]["name"] = $cfheadrow->cf_name;
                                                                                        $cfheaderrs = cameo_query($cfheader, $sheetid);
                                                                                        $block["cfheaders"] = array();
                                                                                        if(cameo_num_rows($cfheaderrs) > 0) {
                                                                                         while($cfheadrow = cameo_fetch_object($cfheaderrs)) {
                                                                                                        $block["cfheaders"][$cfheadrow->cf_id]["name"] = $cfheadrow->cf_name;                        
                                                                                         }
                                                                                        }
                                                                                        $comment = "SELECT cmnt.eval_id_fk, cmnt.updated_role, cmnt.comments,TIMEDIFF(cmnt.updated_on,cmnt.review_start_time),cmnt.updated_on,cmnt.review_start_time,cmnt.ip_address,cmnt.pending_queue,cmnt.coached FROM tm_user_monitoring_comments cmnt 
                                                                                                        LEFT JOIN tm_user_monitoring_mas m ON m.eval_id_pk = cmnt.eval_id_fk 
                                                                                                        WHERE m.deleted=0 AND m.form_type=".$_SESSION['master_from_type']."  AND m.project_id=%d AND m.sheet_id=%d AND DATE(m.monitor_date) BETWEEN '%s' AND '%s' ORDER BY cmnt.updated_on ASC";
                                                                                        $commentrs = cameo_query($comment, $projectid,$sheetid, $startdate, $enddate);
                                                                                        while($commentrow = cameo_fetch_row($commentrs)) {
                                                                                                $cmntdata[$commentrow[0]][] = $commentrow;
                                                                                        }

                                                                                        foreach($version as $_ver_arr) {
                                                                                                $_form_id = $_ver_arr[1];
                                                                                                $_version_no = $_ver_arr[0];
                                                                                                if(!empty($_form_id) && $_version_no != "") {
                                                                                                        //
                                                                                                        $_version_name = $_ver_arr[3];
                                                                                                        /*if($_version_no == 0) {
                                                                                                                $_tree_hirerchy = "SELECT tree.node_type,tree.type_id,
                                                                                                                                (CASE tree.node_type
                                                                                                                                WHEN 'C' THEN (SELECT cat.category_name FROM tm_categories_mas cat WHERE cat.category_id=tree.type_id)
                                                                                                                                WHEN 'Q' THEN (SELECT q.question_name FROM  tm_questions_mas q WHERE q.question_id=tree.type_id)
                                                                                                                                END) as name
                                                                                                                                  FROM tm_trees_hirarchy_mas tree 
                                                                                                                        WHERE tree.form_id='".$_form_id."' AND tree.node_type !='A'";
                                                                                                                //echo sprintf($_tree_hirerchy);
                                                                                                                $_tree_hirerchy_rs = cameo_query($_tree_hirerchy);
                                                                                                                if(cameo_num_rows($_tree_hirerchy_rs)) {
                                                                                                                        while($_tree_row = cameo_fetch_object($_tree_hirerchy_rs)) {
                                                                                                                                //print_r($_tree_row);						
                                                                                                                                if($_tree_row->node_type == 'C') {
                                                                                                                                        $_cc_cat_id = $_tree_row->type_id;
                                                                                                                                        if(!isset($_tree[$_cc_cat_id])) {
                                                                                                                                                $_tree[$_cc_cat_id] = array("name"=>$_tree_row->name,"items"=>array());
                                                                                                                                        }							
                                                                                                                                } else {
                                                                                                                                        if($_cc_cat_id != "") {
                                                                                                                                                //$_type_id = $_tree_row->type_id;
                                                                                                                                                $_tree[$_cc_cat_id]["items"][$_tree_row->type_id] = $_tree_row->name;
                                                                                                                                        }
                                                                                                                                }						
                                                                                                                        }
                                                                                                                }
                                                                                                        } else {*/
                                                                                                                $_tree_hirerchy = "SELECT tree.node_type,tree.type_id,
                                                                                                                                (CASE tree.node_type
                                                                                                                                WHEN 'C' THEN (SELECT cat.category_name FROM tm_categories_mas cat WHERE cat.category_id=tree.type_id)
                                                                                                                                WHEN 'Q' THEN (SELECT q.question_name FROM  tm_questions_mas q WHERE q.question_id=tree.type_id)
                                                                                                                                END) as name
                                                                                                                                  FROM tm_trees_hirarchy_mas_version tree 
                                                                                                                        WHERE tree.form_id='".$_form_id."' AND tree.version_no='".$_version_no."' AND tree.node_type !='A' ORDER BY tree.tree_id";
                                                                                                                //echo "<br>==>>Form==".$_form_id."==Version===".$_version_name."==".sprintf($_tree_hirerchy);
                                                                                                                $_tree_hirerchy_rs = cameo_query($_tree_hirerchy);
                                                                                                                if(cameo_num_rows($_tree_hirerchy_rs)) {
                                                                                                                        while($_tree_row = cameo_fetch_object($_tree_hirerchy_rs)) {
                                                                                                                                //print_r($_tree_row);						
                                                                                                                                if($_tree_row->node_type == 'C') {
                                                                                                                                        $_cc_cat_id = $_tree_row->type_id;
                                                                                                                                        if(!isset($_tree[$_cc_cat_id])) {
                                                                                                                                                $_tree[$_cc_cat_id] = array("name"=>$_tree_row->name,"items"=>array());
                                                                                                                                        }							
                                                                                                                                } else {
                                                                                                                                        if($_cc_cat_id != "") {
                                                                                                                                                //$_type_id = $_tree_row->type_id;
                                                                                                                                                $_tree[$_cc_cat_id]["items"][$_tree_row->type_id] = $_tree_row->name;
                                                                                                                                        }
                                                                                                                                }						
                                                                                                                        }
                                                                                                                }
                                                                                                        /*}*/
                                                                                                        //print_r($_tree);
                                                                                                        $repsql = "SELECT m.eval_id_pk, g.geography_name, prj.project_name, sht.sheet_name, m.emp_id, usr1.name, usr2.name, 
                                                                                                        role.user_role_name, usr3.name, usr4.name, m.monitor_date, 

                                                                                                        WEEK(m.monitor_date,3), MONTH(m.monitor_date), nt.ntrans_name, mt.mtype_name, m.call_duration, m.cls_id, m.cls_date,m.case_no, tq.qtrans_name, m.overall_score, m.trans_status, m.overall_score1,sht.sheet_id,m.coach_complete_date,m.monitor_duration,m.direction_type,m.trans_type";
                                                                                                        $repsql .=" FROM tm_user_monitoring_mas m ";
                                                                                                        $repsql .=" LEFT JOIN tm_projects_mas prj ON prj.project_id = m.project_id
                                                                                                        LEFT JOIN tm_sheets_mas sht ON sht.sheet_id = m.sheet_id
                                                                                                        LEFT JOIN tm_geography_mas g ON g.geography_id=m.geography_id
                                                                                                        LEFT JOIN tm_nature_transaction_mas nt ON nt.ntrans_id =m.trans_nature
                                                                                                        LEFT JOIN tm_monitoring_type_mas mt ON mt.mtype_id = m.monitor_type
                                                                                                        LEFT JOIN tm_transaction_quality_mas tq ON tq.qtrans_id = m.trans_quality 
                                                                                                        LEFT JOIN tm_user_mas usr1 ON usr1.emp_id = m.emp_id 
                                                                                                        LEFT JOIN tm_user_mas usr2 ON usr2.emp_id = m.monitor_by 
                                                                                                        LEFT JOIN tm_user_mas usr3 ON usr3.emp_id = m.emp_reporting_1 
                                                                                                        LEFT JOIN tm_user_mas usr4 ON usr4.emp_id = m.emp_reporting_2
                                                                                                        LEFT JOIN tm_user_role_mas role ON role.user_role_id = m.monitor_by_role 
                                                                                                        WHERE m.deleted=0 AND m.form_type=".$_SESSION['master_from_type']."  AND m.project_id=%d AND m.sheet_id=%d AND DATE(m.monitor_date) BETWEEN '%s' AND '%s' AND form_id=%d AND m.version_no=%d";
                                                                                                        //echo "<br>==>>Form==".$_form_id."==Version===".$_version_name."==".sprintf($repsql, $projectid , $sheetid, $startdate, $enddate, $_form_id, $_version_no);
                                                                                                        $reprs = cameo_query($repsql, $projectid , $sheetid, $startdate, $enddate, $_form_id, $_version_no);
                                                                                                        //printf($repsql, $projectid , $sheetid, $startdate, $enddate, $_form_id, $_version_no);exit;
                                                                                                        //echo "<br>==>>Form==".$_form_id."==Version===".$_version_name."==".cameo_num_rows($reprs);
                                                                                                        $sht_name = $_version_name;
                                                                                                        if(strlen($sht_name) > 30) {
                                                                                                                $sht_name = substr($sht_name,0,30);
                                                                                                        }
                                                                                                        $sheet =& $excel->addWorksheet($sht_name);
                                                                                                        $sheet->setInputEncoding('utf-8');
                                                                                                        $sheet->freezePanes(array(0, 6));
                                                                                                        if( cameo_num_rows($reprs)>0 ){
                                                                                                                //unset($sheet);
                                                                                                                //$sheet = new stdClass();				
                                                                                                                $headerformat =& $excel->addFormat();
                                                                                                                //$headerformat->setBgColor('yellow');
                                                                                                                //$headerformat->setPattern(1);
                                                                                                                $headerformat->setFgColor('yellow');
                                                                                                                $headerformat->setBold(1); 
                                                                                                                $headers = array("Key Id", "Location", "Project", "Form Name", "Agent Id", "Agent Name", "Monitory By", "Monitor By Designation","TL Name", "TM Name", "Date", "Week", "Month","Nature of Transaction","Monitoring Type" ,"Call Duration","CLS ID","CLS Date","Case No","Transaction Quality","Overall", "Result");
                                                                                                                $row = 2;			
                                                                                                                while($reprow = cameo_fetch_row($reprs)) {
                                                                                                                        $col = 0;
                                                                                                                        foreach($headers as $key=>$header) { 
                                                                                                                                $sheet->write(1, $col, $header,$headerformat);
                                                                                                                                if($key==20)
                                                                                                                                        $overallscr = $reprow[$key]==NULL? 'NA':($reprow[$key]/100);
                                                                                                                                else 
                                                                                                                                        $overallscr = $reprow[$key];
                                                                                                                                if($key==20) {
                                                                                                                                        $percent_format->setNumFormat('0.00%');
                                                                                                                                        $sheet->write($row, $col, $overallscr,$percent_format);
                                                                                                                                } else {
                                                                                                                                        if($key==10)
                                                                                                                                                $sheet->write($row, $col, $overallscr,$date_time_format);
                                                                                                                                        else if($key==17)
                                                                                                                                                $sheet->write($row, $col, $overallscr,$date_format);
                                                                                                                                        else    
                                                                                                                                                $sheet->write($row, $col, $overallscr);
                                                                                                                                }
                                                                                                                                $col++;
                                                                                                                        }
                                                                                                                        //Critical Section Starts here	
                                                                                                                        $tmfcrtsql = "SELECT * FROM `tm_user_monitoring_tmf_criticals_trans` tmfctrns WHERE eval_id_fk=%d";
                                                                                                                        $tmfcrtrs = cameo_query($tmfcrtsql, $reprow[0]);
                                                                                                                        $tmfcrtrow = cameo_fetch_object($tmfcrtrs);

                                                                                                                        $crtlsql = "SELECT * FROM `tm_criticals_mas` WHERE `default`=1";
                                                                                                                        $crtlrs = cameo_query($crtlsql);
                                                                                                                        $crtlceascore = $crtlnceascore = $ctrlceacnt = $ctrlnceacnt = 0;
                                                                                                                        $critical_short_code = array();

                                                                                                                        $headerformat_green =& $excel->addFormat();
                                                                                                                        $headerformat_green->setColor('white');
                                                                                                                        //$headerformat_green->setPattern(6);
                                                                                                                        $headerformat_green->setFgColor('green');
                                                                                                                        $headerformat_green->setBold(1);

                                                                                                                        while($crtlrow = cameo_fetch_object($crtlrs)) {					
                                                                                                                                $cid = $crtlrow->critical_id;
                                                                                                                                 if($crtlrow->critical_nature==1) {
                                                                                                                                        $critical_short_code[$crtlrow->short_code] = $cid;
                                                                                                                                }
                                                                                                                                if($tmfcrtrow->{c.$cid._id}!=NULL) {
                                                                                                                                        $sheet->write(1, $col, $crtlrow->critical_name,$headerformat_green);
                                                                                                                                        $percent_format->setNumFormat('0.00%');						
                                                                                                                                        $sheet->write($row, $col, $tmfcrtrow->{c.$cid._score}==NULL?'NA':($tmfcrtrow->{c.$cid._score}/100),$percent_format);
                                                                                                                                        if($tmfcrtrow->{c.$cid._score}!=NULL) {
                                                                                                                                                if($crtlrow->critical_nature==1) {
                                                                                                                                                        $crtlceascore += $tmfcrtrow->{c.$cid._score};
                                                                                                                                                        $ctrlceacnt++;
                                                                                                                                                } else {
                                                                                                                                                        $crtlnceascore += $tmfcrtrow->{c.$cid._score};
                                                                                                                                                        $ctrlnceacnt++;
                                                                                                                                                }
                                                                                                                                        }
                                                                                                                                        $col++;

                                                                                                                                }
                                                                                                                        }
                                                                                                                        //Critical Section Ends here
                                                                                                                   $grds = "SELECT ctgy.category_id, ctgy.category_name, ques.question_name, mtrns.score, crtl.short_code, mtrns.opportunity, crtl.critical_id, crtl.critical_nature, mtrns.met,  ques.question_id, mtrns.node_type 
                                                                                                                                        FROM tm_user_monitoring_tmf_trans mtrns 
                                                                                                                                        LEFT JOIN tm_categories_mas ctgy ON ctgy.category_id = mtrns.category_id
                                                                                                                                        LEFT JOIN tm_questions_mas ques ON ques.question_id=mtrns.question_id
                                                                                                                                        LEFT JOIN tm_criticals_mas crtl ON crtl.critical_id= mtrns.critical_id
                                                                                                                                        WHERE mtrns.eval_id_fk= %d ORDER BY mtrns.fk_tree_id"; //AND mtrns.node_type='Q'
                                                                                                                        //echo "<br>==>>>".sprintf($grds, $reprow[0]);
                                                                                                                        $grdsrs = cameo_query($grds, $reprow[0]);
                                                                                                                        $qsection = array();
                                                                                                                        $qsubsection = array();
                                                                                                                        $ceasection = array();
                                                                                                                        $nceasection = array();				
                                                                                                                        //echo "<pre>";
                                                                                                                        $_prev_cat_id = "";
                                                                                                               $_diff_same_cat_id = 0;
                                                                                                                        while($grdsrow = cameo_fetch_row($grdsrs)) {
                                                                                                                                                if($grdsrow[0] != $_prev_cat_id) {
                                                                                                                                      $_diff_same_cat_id++;
                                                                                                                                      }
                                                                                                                                      $qsection[$_diff_same_cat_id.'-'.$grdsrow[0]]["name"] = $grdsrow[1];
                                                                                                                                      if($grdsrow[10] == 'Q') {
                                                                                                                                      $qsection[$_diff_same_cat_id.'-'.$grdsrow[0]]["score"][$grdsrow[9]] = array($grdsrow[3], $grdsrow[4]==NULL?'na':$grdsrow[4], $grdsrow[5], $grdsrow[2], $grdsrow[9], $grdsrow[10]);
                                                                                                                                      } elseif($grdsrow[10] == 'SQ') {
                                                                                                                                      $qsubsection[$_diff_same_cat_id.'-'.$grdsrow[0]]["score"][$grdsrow[9]] = array($grdsrow[3], $grdsrow[4]==NULL?'na':$grdsrow[4], $grdsrow[5], $grdsrow[2], $grdsrow[9], $grdsrow[10]);
                                                                                                                                      }
                                                                                                                                      if($grdsrow[7]!=NULL) {
                                                                                                                                      if($grdsrow[7]==1) {

                                                                                                                                      $ceasection[$grdsrow[6]]["name"] = $grdsrow[4];  

                                                                                                                                      $ceasection[$grdsrow[6]]["oppnty"][] = $grdsrow[8]==NULL?NULL: 1;
                                                                                                                                      $ceasection[$grdsrow[6]]["actual"][] = $grdsrow[8]==1?1:NULL;
                                                                                                                                      } else if($grdsrow[7]==0) { 

                                                                                                                                      $nceasection[$grdsrow[6]]["name"] = $grdsrow[4]; 
                                                                                                                                      $nceasection[$grdsrow[6]]["oppnty"][] = $grdsrow[3]==NULL?NULL:$grdsrow[5];
                                                                                                                                      $nceasection[$grdsrow[6]]["actual"][] = $grdsrow[3]; 
                                                                                                                                      }   
                                                                                                                                      } 
                                                                                                                                      $_prev_cat_id = $grdsrow[0];
                                                                                                                        }
                                                                                                                        //print_r($ceasection);
                                                                                                                        //CEA Calculation
                                                                                                                        //$notrecord_critical = array_keys($critical_short_code);
                                                                                                                        //print_r($ceasection);
                                                                                                                        if(is_array($critical_short_code) && !empty($critical_short_code)) {
                                                                                                                                foreach($critical_short_code as $shot_code =>$critical_id) {
                                                                                                                                        if(!isset($ceasection[$critical_id])) {
                                                                                                                                                $ceasection[$critical_id]["name"] = $shot_code;  

                                                                                                                                                $ceasection[$critical_id]["oppnty"][] = NULL;
                                                                                                                                                $ceasection[$critical_id]["actual"][] = NULL;
                                                                                                                                        }
                                                                                                                                }
                                                                                                                        }
                                                                                                                        $ceacnt = count($ceasection);
                                                                                                                        $sheet->setMerge(0, $col, 0, $col+$ceacnt-1);
                                                                                                                        $sheet->write(0, $col, "CEA Opportunity",$headerformat_green);

                                                                                                                        $sheet->setMerge(0, $col+$ceacnt, 0, $col+($ceacnt*2)-1);
                                                                                                                        $sheet->write(0, $col+$ceacnt, "CEA Actual",$headerformat_green);

                                                                                                                        $overallceaopnty = $overallceaact = 0;                
                                                                                                                        foreach($ceasection as $cea) {					
                                                                                                                                $sheet->write(1, $col, $cea["name"],$headerformat_green);
                                                                                                                                if(count($cea["oppnty"]) == 1) {
                                                                                                                                        $oppor = ($cea["oppnty"][0] == NULL)?'NA':$cea["oppnty"][0];
                                                                                                                                } else {
                                                                                                                                        $oppor = array_sum($cea["oppnty"]);
                                                                                                                                }
                                                                                                                                if(count($cea["actual"]) == 1) {
                                                                                                                                        $actual = ($cea["actual"][0] == NULL)?'NA':$cea["actual"][0];
                                                                                                                                } else {
                                                                                                                                        $actual = array_sum($cea["actual"]);
                                                                                                                                }
                                                                                                                                $sheet->write($row, $col,  $oppor);

                                                                                                                                $sheet->write(1, $col+$ceacnt, $cea["name"],$headerformat_green);
                                                                                                                                $sheet->write($row, $col+$ceacnt,  $actual);

                                                                                                                                $overallceaopnty += array_sum($cea["oppnty"]);
                                                                                                                                $overallceaact += array_sum($cea["actual"]);

                                                                                                                                $col++;
                                                                                                                        }
                                                                                                                        $col += $ceacnt;

                                                                                                                        $sheet->setMerge(0, $col, 0, $col+2-1);
                                                                                                                        $sheet->write(0, $col, "Overall CEA Score",$headerformat_green);

                                                                                                                        $sheet->write(1, $col, "Overall Critical Opportunity",$headerformat_green);
                                                                                                                        $sheet->write($row, $col++, $overallceaopnty);

                                                                                                                        $sheet->write(1, $col, "Overall Critical Actual",$headerformat_green);
                                                                                                                        $sheet->write($row, $col++, $overallceaact);

                                                                                                                        //NCEA Calculation
                                                                                                                        $nceacnt = count($nceasection);
                                                                                                                        $sheet->setMerge(0, $col, 0, $col+$nceacnt-1);
                                                                                                                        $sheet->write(0, $col, "NCEA Opportunity",$headerformat_green);

                                                                                                                        $sheet->setMerge(0, $col+$nceacnt, 0, $col+($nceacnt*2)-1);
                                                                                                                        $sheet->write(0, $col+$nceacnt, "NCEA Actual",$headerformat_green);

                                                                                                                        $overallnceaopnty = $overallnceaact = 0;
                                                                                                                        foreach($nceasection as $ncea) {
                                                                                                                                $sheet->write(1, $col, $ncea["name"],$headerformat_green);
                                                                                                                                $sheet->write($row, $col,  array_sum($ncea["oppnty"]));

                                                                                                                                $sheet->write(1, $col+$nceacnt, $ncea["name"],$headerformat_green);
                                                                                                                                $sheet->write($row, $col+$nceacnt,  array_sum($ncea["actual"]));

                                                                                                                                $overallnceaopnty += array_sum($ncea["oppnty"]);
                                                                                                                                $overallnceaact += array_sum($ncea["actual"]);

                                                                                                                                $col++;
                                                                                                                        }
                                                                                                                        $col += $nceacnt;

                                                                                                                        $sheet->setMerge(0, $col, 0, $col+2-1);
                                                                                                                        $sheet->write(0, $col, "Overall NCEA Score",$headerformat_green);

                                                                                                                        $sheet->write(1, $col, "Overall Non Critical Opportunity",$headerformat_green);
                                                                                                                        $sheet->write($row, $col++, $overallnceaopnty);

                                                                                                                        $sheet->write(1, $col, "Overall Non Critical Actual",$headerformat_green);
                                                                                                                        $sheet->write($row, $col++, $overallnceaact);

                                                                                                                        //Section Calculation
                                                                                                                        $headerformat_qsecs =& $excel->addFormat();
                                                                                                                        $headerformat_qsecs->setColor('white');

                                                                                                                        $headerformat_qsecs->setFgColor('red');
                                                                                                                        $headerformat_qsecs->setBold(1);

                                                                                                                        $qno = 1;$icol = $col; $newcol=0;
                                                                                                                        $seccol1 = count($qsection);
                                                                                                                        foreach($qsection as $qsec) { 
                                                                                                                                $seccol2 = count($qsec["score"]);   
                                                                                                                                if($row == 2) {									
                                                                                                                                        $sheet->write(1, $col, $qsec["name"],$headerformat_qsecs); 
                                                                                                                                        $sheet->setMerge(0, ($icol+$seccol1), 0, ($icol+($seccol1+$seccol2)-1));
                                                                                                                                        $sheet->write(0, $icol+$seccol1, $qsec["name"],$headerformat_qsecs);
                                                                                                                                }
                                                                                                                                $sectiontotal = $sectionoptny = 0;
                                                                                                                                foreach($qsec["score"] as $qvalue) {
                                                                                                                                        if($row == 2) {
                                                                                                                                                $sheet->writeNote(1,$icol+$seccol1, $qvalue[3]);
                                                                                                                                                $sheet->write(1, $icol+$seccol1, $qvalue[1]."\n".$qno,$headerformat_qsecs);
                                                                                                                                        }
                                                                                                                                        $sheet->write($row, $icol+$seccol1, ($qvalue[0]==NULL)? 'NA':$qvalue[0] );
                                                                                                                                        if($qvalue[0]!=NULL) {
                                                                                                                                        $sectiontotal +=  $qvalue[0];
                                                                                                                                        $sectionoptny +=  $qvalue[2];
                                                                                                                                        }
                                                                                                                                        $qno++;
                                                                                                                                        $icol++;
                                                                                                                                }
                                                                                                                                if($sectiontotal==0 && $sectionoptny==0) {
                                                                                                                                        $sheet->write($row, $col, 'NA');
                                                                                                                                } else {
                                                                                                                                        $percent_format->setNumFormat('0.00%');
                                                                                                                                        //(round(($sectiontotal/$sectionoptny)*100,2))
                                                                                                                                       if($_tmp_score > 0) { 
                                                                                                                                     $sheet->write($row, $col, (($sectiontotal/$sectionoptny)) ,$percent_format);
                                                                                                                             } else {
                                                                                                                                     $sheet->write($row, $col, 0 ,$percent_format);
                                                                                                                             }
                                                                                                                                }
                                                                                                                                $newcol += $seccol2;
                                                                                                                                $col++;
                                                                                                                        }	

                                                                                                                        $col += $newcol;
                                                                                                                        $cmtcol = $col;

                                                                                                                        $format6 =& $excel->addFormat();
                                                                                                                        $format6->setColor('white');
                                                                                                                        //$format6->setPattern(6);
                                                                                                                        $format6->setFgColor('fuchsia');
                                                                                                                        $format6->setBold(1);

                                                                                                                        $sheet->setMerge(0, $cmtcol, 0, $cmtcol+2);
                                                                                                                        $sheet->write(0,$cmtcol, "Evaluation By",$format6);

                                                                                                                        $sheet->setMerge(0, $cmtcol+3, 0, $cmtcol+7);
                                                                                                                        $sheet->write(0,$cmtcol+3, "Coaching By",$format6);

                                                                                                                        $sheet->setMerge(0, $cmtcol+8, 0, $cmtcol+12);
                                                                                                                        $sheet->write(0,$cmtcol+8, "Agent Response By",$format6);

                                                                                                                        $sheet->setMerge(0, $cmtcol+13, 0, $cmtcol+15);
                                                                                                                        $sheet->write(0,$cmtcol+13, "Escaleted By",$format6);                                                 

                                                                                                                        $sheet->write(1,$cmtcol, "Overall Summary",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+1, "Evaluation Duration",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+2, "Evaluation IP",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+3, "Comment by QA/TL",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+4, "Role",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+5, "Coached in person",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+6, "Coaching Duration",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+7, "Coaching IP",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+8, "Accept/Escalate",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+9, "Comment by Agent",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+10, "Coached in person",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+11, "Agent Response Duration",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+12, "Agent Response IP",$format6); 
                                                                                                                        $sheet->write(1,$cmtcol+13, "Comment by TM",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+14, "Escalated Duration",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+15, "Escalated IP",$format6);
                                                                                                                        $sheet->write(1,$cmtcol+16, "Evaluation Overall time",$format6);

                                                                                                                        foreach($cmntdata[$reprow[0]] as $key=>$comment) {											 
                                                                                                                        $comment[2]=str_replace("=","Smiley",$comment[2]);
                                                                                                                        $comment[2]=html_entity_decode($comment[2]);
                                                                                                                        if($key==0) { 
                                                                                                                                $sheet->write($row, $cmtcol, stripslashes($comment[2]));
                                                                                                                                $sheet->write($row, $cmtcol+1, $comment[3]);
                                                                                                                                $sheet->write($row, $cmtcol+2, $comment[6]);
                                                                                                                        } else {                                                    

                                                                                                                                if($comment[1]== 2 || $comment[1]== 3) {							   
                                                                                                                                    $sheet->write($row, $cmtcol+3,stripslashes($comment[2]));
                                                                                                                                    if($comment[1]== 2)
                                                                                                                                            $sheet->write($row, $cmtcol+4, 'TL');
                                                                                                                                    else
                                                                                                                                            $sheet->write($row, $cmtcol+4, 'QA');
                                                                                                                                    if($comment[8]==1)$coached='Yes'; elseif($comment[8]==2) $coached='No';

                                                                                                                                     $sheet->write($row, $cmtcol+5, $coached);
                                                                                                                                    $sheet->write($row, $cmtcol+6, $comment[3]);
                                                                                                                                    $sheet->write($row, $cmtcol+7, $comment[6]);                                                               

                                                                                                                                } else if ($comment[1]== 4) {							   
                                                                                                                                    $sheet->write($row, $cmtcol+13, stripslashes($comment[2]));
                                                                                                                                    $sheet->write($row, $cmtcol+14, $comment[3]);
                                                                                                                                    $sheet->write($row, $cmtcol+15, $comment[6]); 
                                                                                                                                    $escalate=1;
                                                                                                                                } else if ($comment[1]== 1) {

                                                                                                                                    if($comment[7]==4) $acceptcoment='Escalate'; else $acceptcoment='Accept';
                                                                                                                                    $sheet->write($row, $cmtcol+8, $acceptcoment);
                                                                                                                                    $sheet->write($row, $cmtcol+9, stripslashes($comment[2]));
                                                                                                                                    if($comment[8]==1)$coached='Yes'; elseif($comment[8]==2) $coached='No';
                                                                                                                                    $sheet->write($row, $cmtcol+10, $coached);
                                                                                                                                    $sheet->write($row, $cmtcol+11, $comment[3]);
                                                                                                                                    $sheet->write($row, $cmtcol+12, $comment[6]); 
                                                                                                                                }
                                                                                                                        } 
                                                                                                                   //$col++;
                                                                                                                } 



                                                                                                                $_mon_date=  strtotime($reprow[10]);
                                                                                                                $select_last_comment="Select updated_on from  tm_user_monitoring_comments WHERE eval_id_fk=%d ORDER BY updated_on DESC LIMIT 0,1";        
                                                                                                                $qry_last_comment = cameo_query($select_last_comment, $reprow[0]);
                                                                                                                $fetch_last_comment = cameo_fetch_object($qry_last_comment);
                                                                                                                $evalution_last_comment=strtotime($fetch_last_comment->updated_on);
                                                                                                                if(gmdate("d",$evalution_last_comment-$_mon_date)!=01 || gmdate("d",$evalution_last_comment-$_mon_date)!=='01' || gmdate("d",$evalution_last_comment-$_mon_date)!==1)
                                                                                                                {
                                                                                                                    $days=(gmdate("d",$evalution_last_comment-$_mon_date)-1)*24;
                                                                                                                }else{
                                                                                                                    $days=00;
                                                                                                                }
                                                                                                                 $totla_hrs=$days+gmdate("H",$evalution_last_comment-$_mon_date);
                                                                                                                 if($totla_hrs<10)
                                                                                                                     $totla_hrs='0'.$totla_hrs;
                                                                                                                $evaluation_interval=$totla_hrs.':'.gmdate("i:s",$evalution_last_comment-$_mon_date);
                                                                                                                $sheet->write($row, $cmtcol+16, $evaluation_interval);
                                                                                                                $col +=17;
                                                                                                                $sheet->write(1,$col, "2nd Overall Score",$format6);
                                                                                                                if($reprow[22]!= NULL) {                    
                                                                                                                        $sheet->write($row, $col, $reprow[22]);
                                                                                                                }
                                                                                                                $col++ ;

                                                                                                                $format7 =& $excel->addFormat();
                                                                                                                $format7->setColor('white');
                                                                                                                        //$format7->setPattern(6);
                                                                                                                        $format7->setFgColor('brown');
                                                                                                                        $format7->setBold(1);

                                                                                                                        $cfheader = "SELECT scf.cf_id, cf.cf_name, cf.cf_type FROM tm_sheet_custom_field_map scf 
                                                                                                                        LEFT JOIN  tm_user_monitoring_mas mon ON mon.sheet_id=scf.sheet_id 
                                                                                                                        LEFT JOIN tm_custom_field_mas cf ON cf.cf_id=scf.cf_id
                                                                                                                        WHERE mon.eval_id_pk=%d";
                                                                                                                        $cfheadrs = cameo_query($cfheader, $reprow[0]);
                                                                                                                        $cfdsql = '';
                                                                                                                        $cfs = array();
                                                                                                                        $cftb = "";
                                                                                                                        while($cfheadrow = cameo_fetch_object($cfheadrs)) {
                                                                                                                                //$block["cfheaders"][$cfheadrow->cf_id]["name"] = $cfheadrow->cf_name;
                                                                                                                                        if($cfheadrow->cf_type==1 || $cfheadrow->cf_type==2 || $cfheadrow->cf_type==5){
                                                                                                                                                $cfs[] = "m.cf_$cfheadrow->cf_id"; 

                                                                                                                                        } else if($cfheadrow->cf_type==3 || $cfheadrow->cf_type==4){
                                                                                                                                                $cfs[] = "cft_$cfheadrow->cf_id.text cf_$cfheadrow->cf_id";
                                                                                                                                                $cftb .= "LEFT JOIN tm_custom_field_options_trans cft_$cfheadrow->cf_id ON cft_$cfheadrow->cf_id.cf_id_fk='$cfheadrow->cf_id' and m.cf_$cfheadrow->cf_id=cft_$cfheadrow->cf_id.cf_opt_id ";
                                                                                                                                        }
                                                                                                                        }

                                                                                                                        $cfdsql = "SELECT ". implode(",",$cfs)." FROM tm_user_monitoring_headers_trans m $cftb WHERE m.eval_id_fk=%d";
                                                                                                                   // echo "<br>===>>>".sprintf($cfdsql,$reprow[0]);
                                                                                                                        $cfdrs = cameo_query($cfdsql,$reprow[0]);
                                                                                                                        $cfdata = cameo_fetch_object($cfdrs);
                                                                                                                        //print_r($cfdata);
                                                                                                                        foreach($block["cfheaders"] as $cfkey=>$cfd) {
                                                                                                                           // $block["cfheaddata"][] = array($cfd["name"], );
                                                                                                                                if($row == 2) {
                                                                                                                                        $sheet->write(1,$col, $cfd["name"],$format7);
                                                                                                                                }
                                                                                                                                $dummy = "cf_".$cfkey;
                                                                                                                                $sheet->write($row, $col, $cfdata->$dummy);
                                                                                                                                $col++;
                                                                                                                        }


                                                                                                                        /*
                                                                                                                          Sections
                                                                                                                        */

                                                                                                                        $headerformatsec =& $excel->addFormat();
                                                                                                                        $headerformatsec->setColor('white');
                                                                                                                        //$headerformatsec->setPattern(6);
                                                                                                                        $headerformatsec->setFgColor('blue');
                                                                                                                        $headerformatsec->setBold(1);
                                                                                                                        $secsql = "SELECT sec.section_id, st.form_id,sec.section_name, ft.form_type_id,ft.form_type_name, st.score FROM tm_user_monitoring_sections_trans st 
                                                                                                                                                LEFT JOIN tm_sections_mas sec ON sec.section_id= st.section_id
                                                                                                                                                LEFT JOIN tm_form_type_mas ft ON ft.form_type_id = st.form_type_id WHERE st.eval_id_fk =%d";
                                                                                                                        $secrs = cameo_query($secsql, $reprow[0]);
                                                                                                                        $sections = array();
                                                                                                                        while($secrow = cameo_fetch_object($secrs)) {
                                                                                                                                $sections[$secrow->section_id]["name"] = $secrow->section_name; 
                                                                                                                                $sections[$secrow->section_id]["score"] = ($secrow->score==NULL)?'NA':$secrow->score;  
                                                                                                                                $sections[$secrow->section_id]["form_id"] = $secrow->form_id; 
                                                                                                                                //$sheet->write(1,$col, "2nd Overall Score");
                                                                                                                           //$block['sections'][$secrow->form_type_id]["name"] = $secrow->form_type_name;
                                                                                                                           //$block['sections'][$secrow->form_type_id]["sections"][$secrow->section_id] = array($secrow->section_name, $secrow->score);
                                                                                                                           //$col++;
                                                                                                                        }
                                                                                                                        $seccount = count($sections);				
                                                                                                                        if($seccount > 0) {
                                                                                                                                ksort($sections,SORT_NUMERIC);
                                                                                                                                $sheet->setMerge(0, $col, 0, ($col+($seccount-1)));
                                                                                                                                $sheet->write(0, $col, "Sections Block",$headerformatsec);
                                                                                                                                if(is_array($sections) && !empty($sections)) {
                                                                                                                                        foreach($sections as $sec_id=>$section) {
                                                                                                                                                $sheet->write(1, $col, $section["name"],$headerformatsec);
                                                                                                                                                $_sec_score = "";
                                                                                                                                                if(isset($sections[$sec_id]["score"])) {
                                                                                                                                                        $_sec_score = $sections[$sec_id]["score"];
                                                                                                                                                }
                                                                                                                                                $sheet->write($row, $col,  $_sec_score);
                                                                                                                                                $col++;	
                                                                                                                                        }
                                                                                                                                }					
                                                                                                                                if(is_array($sections) && !empty($sections)) {
                                                                                                                                        //SELECT f.form_id, f.form_type FROM `tm_sheet_form_map` sf left join tm_forms_mas f ON f.form_id=sf.form_id WHERE `sheet_id`='14'
                                                                                                                                        $_secans = "SELECT mt.section_id,mt.question_id,mt.answer_id,ans.answer FROM tm_user_monitoring_tmf_trans mt LEFT JOIN tm_answer_mas ans  ON ans.answer_id = mt.answer_id WHERE mt.eval_id_fk=%d AND mt.`section_id` IS NOT NULL AND mt.section_id != '0' ORDER BY mt.fk_tree_id";
                                                                                                                                        $sec_answer_rs = cameo_query($_secans, $reprow[0]);
                                                                                                                                        $_ans = array();
                                                                                                                                        while($sec_ans_row = cameo_fetch_object($sec_answer_rs)) {							
                                                                                                                                                $_ans[$sec_ans_row->section_id][$sec_ans_row->question_id] = $sec_ans_row->answer;
                                                                                                                                        }						
                                                                                                                                        //echo '<pre>';
                                                                                                                                        //print_r($sections);
                                                                                                                                        $_secsql = "SELECT th.form_id,th.type_id,q.question_name,th.section_id FROM `tm_trees_hirarchy_mas` th LEFT JOIN  tm_questions_mas q ON q.question_id=th.type_id WHERE `form_id` =%d AND `section_id` IS NOT NULL AND section_id != '0' AND node_type = 'Q' ORDER BY th.tree_id";
                                                                                                                                        //$_secsql = "SELECT form_id,type_id FROM `tm_trees_hirarchy_mas` th WHERE `form_id` = %d AND `section_id` IS NOT NULL AND section_id != '0' AND node_type = 'Q'";
                                                                                                                                        //echo "<br>".sprintf($_secsql, $_form_id);
                                                                                                                                        $sec_head_rs = cameo_query($_secsql, $_form_id);
                                                                                                                                        $que_sections = array();
                                                                                                                                        while($que_row = cameo_fetch_object($sec_head_rs)) {
                                                                                                                                                $que_sections[$que_row->section_id][$que_row->type_id]['que'] = $que_row->question_name; 
                                                                                                                                        }						
                                                                                                                                        $que_count = count($que_sections);
                                                                                                                                        //echo '<pre>';
                                                                                                                                        //print_r($que_sections);
                                                                                                                                        foreach($sections as $sec_id=>$section) {							
                                                                                                                                                $_sub_sec_que = $que_sections[$sec_id];
                                                                                                                                                $que_count_sub = count($_sub_sec_que);
                                                                                                                                                //echo '<pre>';
                                                                                                                                                //print_r($_sub_sec_que);

                                                                                                                                                if($que_count_sub > 0) {								

                                                                                                                                                        $sheet->setMerge(0, $col, 0, ($col+($que_count_sub-1)));
                                                                                                                                                        $sheet->write(0, $col, $section["name"],$headerformatsec);
                                                                                                                                                        foreach($_sub_sec_que as $q_id=>$ques) {
                                                                                                                                                                $_q_ans = '';
                                                                                                                                                                if(isset($_ans[$sec_id][$q_id])) {
                                                                                                                                                                        $_q_ans = $_ans[$sec_id][$q_id];
                                                                                                                                                                }
                                                                                                                                                                $sheet->write(1, $col, $ques['que'],$headerformatsec);
                                                                                                                                                                $sheet->write($row, $col,  $_q_ans);
                                                                                                                                                                $col++;	
                                                                                                                                                        }
                                                                                                                                                } else {
                                                                                                                                                        $sheet->setMerge(0, $col, 0, ($col+($que_count_sub-1)));
                                                                                                                                                        $sheet->write(0, $col, $section["name"],$headerformatsec);
                                                                                                                                                        $sheet->write(1, $col, 'NA',$headerformatsec);
                                                                                                                                                        $sheet->write($row, $col, 'NA');
                                                                                                                                                        $col++;	
                                                                                                                                                }
                                                                                                                                        }
                                                                                                                                }
                                                                                                                        }
                                                                                                                        //exit;
                                                                                                                        /**
                                                                                                                        * Monitoring Duration and Coach Completion Date
                                                                                                                        **/
                                                                                                                        $headercoachcom =& $excel->addFormat();
                                                                                                                        $headercoachcom->setColor('white');
                                                                                                                                                        //$headercoachcom->setPattern(6);
                                                                                                                        $headercoachcom->setFgColor('blue');
                                                                                                                        $headercoachcom->setBold(1);
                                                                                                                        $sheet->write(1, $col, "Coaching Completion Date",$headercoachcom);

                                                                                                                        if($reprow[24] == "0000-00-00 00:00:00") {
                                                                                                                                $coach_com = "NA";
                                                                                                                        } else {
                                                                                                                                $coach_com = $reprow[24];
                                                                                                                        }
                                                                                                                        $sheet->write($row, $col,  $coach_com);
                                                                                                                        $col++;	
                                                                                                                        $sheet->write(1, $col, "Monitor Duration",$headercoachcom);
                                                                                                                        $sheet->write($row, $col,  $reprow[25]);				
                                                                                                                        $col++;	
                                                                                                                        $sheet->write(1, $col, "Direction of Transaction",$headercoachcom);
                                                                                                                        if($reprow[26]==NULL || $reprow[26]=='')
                                                                                                                                $reprow[26]='NA';

                                                                                                                        $sheet->write($row, $col,  $reprow[26]);

                                                                                                                                                   $col++;	
                                                                                                                        $sheet->write(1, $col, "Transaction Type",$headercoachcom);
                                                                                                                        if($reprow[27]==NULL || $reprow[27]=='')
                                                                                                                                $reprow[27]='NA';

                                                                                                                        $sheet->write($row, $col,  $reprow[27]);
                                                                                                                                                        $col++;

                                                                                                                        $grds = "SELECT ctgy.category_id, ctgy.category_name, ques.question_name, mtrns.score, crtl.short_code, mtrns.opportunity, crtl.critical_id, crtl.critical_nature, mtrns.met,  ques.question_id, mtrns.node_type 
                                                                                                                                        FROM tm_user_monitoring_tmf_trans mtrns 
                                                                                                                                        LEFT JOIN tm_categories_mas ctgy ON ctgy.category_id = mtrns.category_id
                                                                                                                                        LEFT JOIN tm_questions_mas ques ON ques.question_id=mtrns.question_id
                                                                                                                                        LEFT JOIN tm_criticals_mas crtl ON crtl.critical_id= mtrns.critical_id
                                                                                                                                        WHERE mtrns.eval_id_fk= %d ORDER BY mtrns.fk_tree_id"; //AND mtrns.node_type='Q'
                                                                                                                        //echo "<br>==>>>".sprintf($grds, $reprow[0]);
                                                                                                                        $grdsrs = cameo_query($grds, $reprow[0]);
                                                                                                                        $qsection = array();
                                                                                                                        $qsubsection = array();
                                                                                                                        $ceasection = array();
                                                                                                                        $nceasection = array();				
                                                                                                                        //echo "<pre>";
                                                                                                                        $_prev_cat_id = "";
                                                                                                               $_diff_same_cat_id = 0;
                                                                                                                        while($grdsrow = cameo_fetch_row($grdsrs)) {
                                                                                                                                                if($grdsrow[0] != $_prev_cat_id) {
                                                                                                                                      $_diff_same_cat_id++;
                                                                                                                                      }
                                                                                                                                      $qsection[$_diff_same_cat_id.'-'.$grdsrow[0]]["name"] = $grdsrow[1];
                                                                                                                                      if($grdsrow[10] == 'Q') {
                                                                                                                                      $qsection[$_diff_same_cat_id.'-'.$grdsrow[0]]["score"][$grdsrow[9]] = array($grdsrow[3], $grdsrow[4]==NULL?'na':$grdsrow[4], $grdsrow[5], $grdsrow[2], $grdsrow[9], $grdsrow[10]);
                                                                                                                                      } elseif($grdsrow[10] == 'SQ') {
                                                                                                                                      $qsubsection[$_diff_same_cat_id.'-'.$grdsrow[0]]["score"][$grdsrow[9]] = array($grdsrow[3], $grdsrow[4]==NULL?'na':$grdsrow[4], $grdsrow[5], $grdsrow[2], $grdsrow[9], $grdsrow[10]);
                                                                                                                                      }
                                                                                                                                      if($grdsrow[7]!=NULL) {
                                                                                                                                      if($grdsrow[7]==1) {

                                                                                                                                      $ceasection[$grdsrow[6]]["name"] = $grdsrow[4];  

                                                                                                                                      $ceasection[$grdsrow[6]]["oppnty"][] = $grdsrow[8]==NULL?NULL: 1;
                                                                                                                                      $ceasection[$grdsrow[6]]["actual"][] = $grdsrow[8]==1?1:NULL;
                                                                                                                                      } else if($grdsrow[7]==0) { 

                                                                                                                                      $nceasection[$grdsrow[6]]["name"] = $grdsrow[4]; 
                                                                                                                                      $nceasection[$grdsrow[6]]["oppnty"][] = $grdsrow[3]==NULL?NULL:$grdsrow[5];
                                                                                                                                      $nceasection[$grdsrow[6]]["actual"][] = $grdsrow[3]; 
                                                                                                                                      }   
                                                                                                                                      } 
                                                                                                                                      $_prev_cat_id = $grdsrow[0];
                                                                                                                        }

                                                                                                                        $headerformat_qsecs =& $excel->addFormat();
                                                                                                                        $headerformat_qsecs->setColor('white');

                                                                                                                        $headerformat_qsecs->setFgColor('red');
                                                                                                                        $headerformat_qsecs->setBold(1);

                                                                                                                        $qno = 1;$icol = $col; $newcol=0;
                                                                                                                        $seccol1 = count($qsection);
                                                                                                                        foreach($qsection as $qsec) { 
                                                                                                                                $seccol2 = count($qsec["score"]);   
                                                                                                                                if($row == 2) {									
                                                                                                                                        //$sheet->write(1, $col, $qsec["name"],$headerformat_qsecs); 
                                                                                                                                        $sheet->setMerge(0, ($icol), 0, ($icol+($seccol2)-1));
                                                                                                                                        $sheet->write(0, $icol, $qsec["name"],$headerformat_qsecs);
                                                                                                                                }
                                                                                                                                $sectiontotal = $sectionoptny = 0;
                                                                                                                                foreach($qsec["score"] as $qvalue) {
                                                                                                                                        if($row == 2) {
                                                                                                                                                //$sheet->writeNote(1,$icol+$seccol1, $qvalue[3]);
                                                                                                                                                $sheet->write(1, $icol, $qvalue[3],$headerformat_qsecs);
                                                                                                                                        }
                                                                                                                                        $sheet->write($row, $icol, ($qvalue[0]==NULL)? 'NA':$qvalue[0] );
                                                                                                                                        if($qvalue[0]!=NULL) {
                                                                                                                                        $sectiontotal +=  $qvalue[0];
                                                                                                                                        $sectionoptny +=  $qvalue[2];
                                                                                                                                        }
                                                                                                                                        $qno++;
                                                                                                                                        $icol++;
                                                                                                                                }
                                                                                                                                if($sectiontotal==0 && $sectionoptny==0) {
                                                                                                                                        //$sheet->write($row, $col, 'NA');
                                                                                                                                } else {
                                                                                                                                        //$percent_format->setNumFormat('0.00%');
                                                                                                                                        //(round(($sectiontotal/$sectionoptny)*100,2))
                                                                                                                                        //$sheet->write($row, $col, (($sectiontotal/$sectionoptny)) ,$percent_format);
                                                                                                                                }
                                                                                                                                $newcol += $seccol2;
                                                                                                                                $col++;
                                                                                                                        }
                                                                                                                        $col = $col + 3;

                                                                                                                        //Master Loop
                                                                                                                        $row++;
                                                                                                                }			
                                                                                                        } //end of form version sheet have any transactions		
                                                                                                } //end of !empty form and version check
                                                                                        } //end of version loop
                                                                                } //end of version array not empty check
                                                                        }
            
            
									/**************** LOGIC END   ******************/											
									$excel->close();
									$eetime = time();
									/*** Write into DB *****/
									//echo "<br>==>>>".$sheetinfo['sheet_name']."===".$filename."===".$projectid."==".$sheetid."==".$startdate."===".$enddate;												
									$dbpath = $dbrdir."/";																					
									$r_day = date("d",$timestamp);
									$r_month = date("m",$timestamp);
									$r_year = date("Y",$timestamp);
									$r_week = date("W",$timestamp);												
									$_sql_insert1 = "INSERT INTO tm_misteam_reports_log(geography_id,project_id,sheet_id,form_id,trend,filename,filepath,starttime,endtime,r_day,r_month,r_year,r_week,repdate) values('".$geo."','".$projectid."','".$sheetid."','".$sheetinfo['form_id']."','".$report_type."','".$fname."','".$dbpath."','".date("Y-m-d H:i:s",$sstime)."','".date("Y-m-d H:i:s",$eetime)."','".$r_day."','".$r_month."','".$r_year."','".$r_week."',now())";
									//echo "<br>==>>".date("Y-m-d H:i:s",$sstime)."===".date("Y-m-d H:i:s",$eetime);
									//echo "<br>".sprintf($_sql_insert1);
									//exit;
									$_insrs = cameo_query($_sql_insert1);												
									//$_insrs = cameo_query($_sql_insert1);
									//print_r($_insrs);
									/*** Write into DB *****/
									//echo "==>>>there";									
								} //end of sheet type check, TMF only to report
							} //end of sheet loop
						}
					}
				} //end of projects check
			} 
		}	//end of geolocation loop
	} //end of report directory exist 
} //end of dir folder checking

?>
