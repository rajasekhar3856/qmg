<?php
ini_set('display_errors','On'); //Off,On
$event_start = '2013-11-08 03:00:00';
$event_end = '2013-11-08 04:00:00';
$timezone = "Asia/Kolkata";
/*echo "<br>dtstart==".$dtstart = (string) gmdate('Ymd\THi00\Z', strtotime($event_start));

echo "<br>dtend==".$dtend = (string) gmdate('Ymd\THi00\Z', strtotime($event_end));
echo "<br>dtstartdddd==".date("Y-m-d H:i:s",strtotime($dtstart));
echo "<br>dtendsddd==".date("Y-m-d H:i:s",strtotime($event_end));
$tz = new DateTimeZone($timezone);
$nowTz = new DateTime($event_start, $tz);
echo "<br>tzone==".date("Y-m-d H:i:s",$nowTz->getTimestamp());*/

/*$date = new DateTime($event_start, new DateTimeZone($timezone));
$date->setTimezone(new DateTimeZone('PST'));
echo $date->format('Y-m-d H:i:s');

$date = new DateTime($event_end, new DateTimeZone($timezone));
$date->setTimezone(new DateTimeZone('PST'));
echo $date->format('Y-m-d H:i:s');*/

echo "<br>".$_stime = 1396994400;
echo "<br>".$_etime = 1396996200;
echo "<br>".date("Y-m-d H:i:s",$_stime);
echo "<br>".date("Y-m-d H:i:s",$_etime);
echo "<br>". gmdate('Ymd\THi00\Z', $_stime );
echo "<br>". gmdate('Ymd\THi00\Z', $_etime );
$date = new DateTime("@$_stime");
$date->setTimezone(new DateTimeZone('America/Los_Angeles'));
echo "<br>". $date->format('Y-m-d H:i:s');
$date->setTimezone(new DateTimeZone('America/Los_Angeles'));
echo "<br>". $date->format('Y-m-d H:i:s');
echo "<br>";

$_cal_starttime = 1396994400;
$_cal_endtime =1396996200;

$event_start = new DateTime("@$_cal_starttime", new DateTimeZone('Asia/Kolkata'));
$event_start->setTimezone(new DateTimeZone('America/Los_Angeles'));
echo "<br>".$cal_event_start = $event_start->format('Y-m-d H:i:s');
echo "<br>".$event_start->getTimestamp();
$event_end = new DateTime("@$_cal_endtime", new DateTimeZone('Asia/Kolkata'));
$event_end->setTimezone(new DateTimeZone('UTC'));
echo "<br>".$cal_event_end = $event_end->format('Y-m-d H:i:s');
echo "<br>".$event_end->getTimestamp();
echo "<br>";
echo "<br>".$_stime = strtotime("2014-04-08 15:00:00");
echo "<br>".$_etime = strtotime("2014-04-08 15:30:00");
echo "<br>".date("Y-m-d H:i:s",$_stime);
echo "<br>".date("Y-m-d H:i:s",$_etime);

?>