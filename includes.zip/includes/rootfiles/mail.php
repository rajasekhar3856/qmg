<?php
include 'misc/PHPMailer/class.phpmailer.php';
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded



$body             =  '
			<html>
			<head>
			  <title>QMG - Calibaration Scheduler</title>
			</head>
			<body>
			  <p></p>
			  <table>
				<tr>
				  <th>When</th><td>&nbsp;</td><td>Some Date</td>
				</tr>
				<tr>
				  <th>Where</th><td>&nbsp;</td><td>Some mettings</td>
				</tr>
				<tr>
				  <td>Please click here to attend the calibration: <a href="http://qmg.csscorp.com/monitor/evaluate_calibrate/">Name of calib</a></td>
				</tr>
			  </table>
			</body>
			</html>
			';
$body             = eregi_replace("[\]",'',$body);
$mail             = new PHPMailer();
$mail->IsSMTP(); // telling the class to use SMTP
try {
/*$mail->Host       = "relay.csscorp.com"; // SMTP server
$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
//$mail->Port       = 25;                    // set the SMTP port for the GMAIL server
$mail->Username   = "qaportal.admin@csscorp.com"; // SMTP account username
$mail->Password   = "@dmn!p0t@q29";// SMTP account password
//$mail->SMTPSecure = 'tls';

$mail->SetFrom('QAPortal.Admin@csscorp.com', 'QAPortal.Admin');

$mail->AddReplyTo("QAPortal.Admin@csscorp.com","QAPortal.Admin");*/

$mail->Subject    = "PHPMailer Test Subject via smtp, basic with authentication";

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

$address = "mahesh.mahendran@csscorp.com";
$mail->AddAddress($address);
//$mail->AddAddress("mahesh.maya@gmail.com");

//$mail->AddAttachment("images/phpmailer.gif");      // attachment
//$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
echo '<pre>';
if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}
} catch (phpmailerException $e) {
	echo $e->errorMessage(); //Pretty error messages from PHPMailer
} catch (Exception $e) {
  echo $e->getMessage(); //Boring error messages from anything else!
}
?>