<?php
ini_set('display_errors', "on");
error_reporting(22517);
$path = '/var/www/html/qaportal/';
//$path = "D:\\xampp\htdocs\qaportal.csscorp.com\source//";
chdir($path);
require_once("custom/settings/settings.php");
ini_set('display_errors', "on");
require_once("includes/mysql.inc");
require_once("misc/Spreadsheet/Excel/Writer.php");
global $db_url;
cameo_connect($db_url['default']);
global $dbLink;
$_version_name = "Version_15";
$_form_id = 159;
$_version_no = 15;
$filename = "comments.xls";
$projectid = 61;
$sheetid = 165; 
$startdate= "2014-01-01";
$enddate="2014-01-31";
$filename = "process_doc/comments.xls";
/*$_form_id = 6;
$_version_no = 3;
$projectid = 1;
$sheetid = 3; 
$startdate= "2013-06-01";
$enddate="2013-06-31";*/
echo "==>Start";
$excel = new Spreadsheet_Excel_Writer($filename);
$excel->setVersion(8); // Use Excel97/2000 Format, IF content length > 255 it'll help us get more
$percent_format =& $excel->addFormat();
$date_format =& $excel->addFormat();
$date_format->setNumFormat('D-MM-YYYY');
$date_format->setTextWrap();
$date_time_format =& $excel->addFormat();
$date_time_format->setNumFormat('YYYY-MM-D h:mm:ss');
$date_time_format->setTextWrap();
$_tree_hirerchy = "SELECT tree.node_type,tree.type_id,
							(CASE tree.node_type
							WHEN 'C' THEN (SELECT cat.category_name FROM tm_categories_mas cat WHERE cat.category_id=tree.type_id)
							WHEN 'Q' THEN (SELECT q.question_name FROM  tm_questions_mas q WHERE q.question_id=tree.type_id)
							END) as name
							  FROM tm_trees_hirarchy_mas_version tree 
					WHERE tree.form_id='".$_form_id."' AND tree.version_no='".$_version_no."' AND tree.node_type !='A' ORDER BY tree.tree_id asc";
			//echo "<br>==>>Form==".$_form_id."==Version===".$_version_name."==".sprintf($_tree_hirerchy);
			$_tree_hirerchy_rs = cameo_query($_tree_hirerchy);
			if(cameo_num_rows($_tree_hirerchy_rs)) {
					while($_tree_row = cameo_fetch_object($_tree_hirerchy_rs)) {
							//print_r($_tree_row);						
							if($_tree_row->node_type == 'C') {
									$_cc_cat_id = $_tree_row->type_id;
									if(!isset($_tree[$_cc_cat_id])) {
											$_tree[$_cc_cat_id] = array("name"=>$_tree_row->name,"items"=>array());
									}							
							} else {
									if($_cc_cat_id != "") {
											//$_type_id = $_tree_row->type_id;
											$_tree[$_cc_cat_id]["items"][$_tree_row->type_id] = $_tree_row->name;
									}
							}						
					}
			}
//echo '<pre>';			
//print_r($_tree);
$repsql = "SELECT m.eval_id_pk, g.geography_name, prj.project_name, sht.sheet_name, m.emp_id, usr1.name, usr2.name as monitor_by_name, 
                                                                                                        role.user_role_name, usr3.name as rep1_name , usr4.name as rep2_name, m.monitor_date, 

WEEK(m.monitor_date,3), MONTH(m.monitor_date), nt.ntrans_name, mt.mtype_name, m.call_duration, m.cls_id, m.cls_date,m.case_no, tq.qtrans_name, m.overall_score, m.trans_status, m.overall_score1,sht.sheet_id,m.coach_complete_date,m.monitor_duration,m.direction_type,m.trans_type";
$repsql .=" FROM tm_user_monitoring_mas m ";
$repsql .=" LEFT JOIN tm_projects_mas prj ON prj.project_id = m.project_id
LEFT JOIN tm_sheets_mas sht ON sht.sheet_id = m.sheet_id
LEFT JOIN tm_geography_mas g ON g.geography_id=m.geography_id
LEFT JOIN tm_nature_transaction_mas nt ON nt.ntrans_id =m.trans_nature
LEFT JOIN tm_monitoring_type_mas mt ON mt.mtype_id = m.monitor_type
LEFT JOIN tm_transaction_quality_mas tq ON tq.qtrans_id = m.trans_quality 
LEFT JOIN tm_user_mas usr1 ON usr1.emp_id = m.emp_id 
LEFT JOIN tm_user_mas usr2 ON usr2.emp_id = m.monitor_by 
LEFT JOIN tm_user_mas usr3 ON usr3.emp_id = m.emp_reporting_1 
LEFT JOIN tm_user_mas usr4 ON usr4.emp_id = m.emp_reporting_2
LEFT JOIN tm_user_role_mas role ON role.user_role_id = m.monitor_by_role 
WHERE m.deleted=0 AND m.project_id=%d AND m.form_type=1  AND m.sheet_id=%d AND DATE(m.monitor_date) BETWEEN '%s' AND '%s' AND form_id=%d AND m.version_no=%d";
//echo "<br>==>>Form==".$_form_id."==Version===".$_version_name."==".sprintf($repsql, $projectid , $sheetid, $startdate, $enddate, $_form_id, $_version_no);
$reprs = cameo_query($repsql, $projectid , $sheetid, $startdate, $enddate, $_form_id, $_version_no);
//echo sprintf($repsql, $projectid , $sheetid, $startdate, $enddate, $_form_id, $_version_no);
$sht_name = $_version_name;
if(strlen($sht_name) > 30) {
		$sht_name = substr($sht_name,0,30);
}
$sheet =& $excel->addWorksheet($sht_name);
$sheet->setInputEncoding('utf-8');
$sheet->freezePanes(array(0, 6));
if( cameo_num_rows($reprs)>0 ){
	//echo cameo_num_rows($reprs);
	$headerformat =& $excel->addFormat();
	//$headerformat->setBgColor('yellow');
	//$headerformat->setPattern(1);
	$headerformat->setFgColor('yellow');
	$headerformat->setBold(1); 
	$headers = array("Key Id", "Location", "Project", "Form Name", "Agent Id", "Agent Name", "Monitory By", "Monitor By Designation","TL Name", "TM Name", "Date", "Week", "Month","Nature of Transaction","Monitoring Type" ,"Call Duration","CLS ID","CLS Date","Case No","Transaction Quality","Overall", "Result");
	//$headers = array("Evaluation ID","Project","Agent Id", "Agent Name", "Monitory By", "Monitor By Designation","TL Name", "TM Name","Date",
	/*if(!empty($_tree)) {
		foreach($_tree as  $cat_id=>$ques_arr) {
			if(!empty($ques_arr['items'])) {
				foreach($ques_arr['items'] as  $ques_id=>$ques_name) {
					$headers[] = $ques_name;
				}
			}
		}
	}*/
	//print_r($headers);
	$row = 2;
	$inc = 0;
	while($reprow = cameo_fetch_row($reprs)) {
			$col = 0;
			foreach($headers as $key=>$header) { 
					if($inc == 0) {
						$sheet->write(1, $col, $header,$headerformat);
					}
					if($key==20)
							$overallscr = $reprow[$key]==NULL? 'NA':($reprow[$key]/100);
					else 
							$overallscr = $reprow[$key];
					if($key==20) {
							$percent_format->setNumFormat('0.00%');
							$sheet->write($row, $col, $overallscr,$percent_format);
					} else {
							if($key==10)
									$sheet->write($row, $col, $overallscr,$date_time_format);
							else if($key==17)
									$sheet->write($row, $col, $overallscr,$date_format);
							else    
									$sheet->write($row, $col, $overallscr);
					}
					$col++;
			}
			$grds = "SELECT ctgy.category_id, ctgy.category_name, ques.question_name, mtrns.score, crtl.short_code, mtrns.opportunity, crtl.critical_id, crtl.critical_nature, mtrns.met,  ques.question_id, mtrns.node_type,mtrns.comments 
						FROM tm_user_monitoring_tmf_trans mtrns 
						LEFT JOIN tm_categories_mas ctgy ON ctgy.category_id = mtrns.category_id
						LEFT JOIN tm_questions_mas ques ON ques.question_id=mtrns.question_id
						LEFT JOIN tm_criticals_mas crtl ON crtl.critical_id= mtrns.critical_id
						WHERE mtrns.eval_id_fk= %d ORDER BY mtrns.fk_tree_id ASC"; //AND mtrns.node_type='Q'
		   //echo "<br>==>>>".sprintf($grds, $reprow[0]);
		   $grdsrs = cameo_query($grds, $reprow[0]);
		   $_qtree = array();
		   if(cameo_num_rows($grdsrs)) {
				while($grdsrow = cameo_fetch_object($grdsrs)) {
					//print_r($_tree_row);
					$grdsrow->comments=str_replace("=","Smiley",$grdsrow->comments);
                    $grdsrow->comments=html_entity_decode($grdsrow->comments);
					$_qtree[$grdsrow->category_id][$grdsrow->question_id] = stripslashes($grdsrow->comments);
				}
			}
			if(!empty($_tree)) {
				foreach($_tree as  $cat_id=>$ques_arr) {					
					if(!empty($ques_arr['items'])) {
						foreach($ques_arr['items'] as  $ques_id=>$ques_name) {
							//$headers[] = $ques_name;
							if($inc == 0) {
								$sheet->write(1, $col, $ques_name,$headerformat);
							}
							$comments = "";
							if(isset($_qtree[$cat_id][$ques_id])) {
								$comments = $_qtree[$cat_id][$ques_id];
							}
							$sheet->write($row, $col, $comments);
							$col++;
						}
					}
				}
			}
			
		$row++;	
		$inc++;	
	}
}
$excel->close();
echo "<br>==>Done";
