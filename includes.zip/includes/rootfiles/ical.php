<?php
echo date("Y/m/d H:i:s");
//error_reporting(E_ALL);
//ini_set("display_errors",1);
//require_once("mail/mail.php");
//require_once("mail/class.smtp.php");
//require_once("mail/mail.class.php");
include './misc/PHPMailer/class.phpmailer.php';
include './misc/PHPMailer/class.icalendar.php';
include './misc/PHPMailer/class.vcalendar.php';

$domain = "-csscorp.com";
$calib_event_uid = date('Ymd').'T'.date('His')."-".rand().$domain; 
$_meeting_start_date = date("Y-m-d H:i:s",strtotime('03/10/2015 15:15:00'));
$_meeting_end_date = date("Y-m-d H:i:s",strtotime('03/10/2015 15:30:00'));
$calib_event_created = $calib_event_modified = (string) gmdate('Ymd\THis\Z', time());

echo $_meeting_start_date.'  =  '.$_meeting_end_date;
$cal = new ICalendar();
//$cal->exceptions = true;
$cal->Ical = 'delete';//create/update/delete - update can be add to,ccc,bcc or date and time or else location or subject , Delete -  cancel the event
$cal->cal_uid = $calib_event_uid;
$cal->cal_sequence = 0;
$cal->cal_event_created = $calib_event_created;
$cal->cal_event_modified = $calib_event_modified;
$cal->event_start = $_meeting_start_date;
$cal->event_end = $_meeting_end_date;
$cal->organizer_name = "Nagaraj Muthuvaradhan";//"Mahesh Mahendran";
$cal->organizer_email = "mnagas@gmail.com";//"mahesh.mahendran@csscorp.com";
$cal->cal_subject = "Nagaraj Ical Meeting";
$cal->cal_location = "Ambit";
$cal->reminder_chk = true;
$cal->reminder_time = 10;
$cal->timezone = 'Asia/Kolkata';//India Standard Time,
$cal->AddAddress('nagaraj.muthuvaradhan@csscorp.com', 'Nagaraj');
//$cal->AddAddress('Arunkumar.Vijaykumar@csscorp.com', 'Arun');
//$cal->AddAddress('mohan.suppu@csscorp.com', 'Mohan');

//$cal->AddAddress('subbiah.pradeep@csscorp.com', 'Subbiah Pradeep');
$cal->Body = "<div>This is a test meeting</div>";
$cal->Subject = "Nagaraj Ical Meeting";
$cal->Sender = "mnagas@gmail.com";
$cal->From = "mnagas@gmail.com";
//$cal->Sender = $user->email_id;
//$cal->From = $user->email_id;
$cal->FromName = "Nagaraj";	
$cal->Send();
echo "mail sent ok";
?>