<?php
ini_set('display_errors', 1);
error_reporting(22517);
$path = '/var/www/html/qaportal/';
chdir($path);
require_once("custom/settings/settings.php");
require_once("includes/mysql.inc");
require_once("misc/Spreadsheet/Excel/Writer.php");
global $db_url;
cameo_connect($db_url['default']);
global $dbLink;
//$skipArr = array("12345","77937","27192","30481","1234567");
$skipArr = array("100000000,��� 
100000001,��� 
100000002,��� 
100000003,�� 
100000004,��� 
100000005,��� 
100000006,��� 
100000007,�� 
100000008,��� 
100000009,��� 
100000010,��� 
100000011,��� 
100000012,�� 
100000013,��� 
100000014,��� 
100000015");
�	
$plist = "SELECT umas.user_id,umas.status,umas.emp_id,cdm.Emp_Status 
            FROM tm_user_mas umas 
            LEFT JOIN tm_cdm_emp_mas cdm ON cdm.Emp_Code = umas.emp_id WHERE umas.user_type=1";
$plistrs = cameo_query($plist);
if(cameo_num_rows($plistrs)) {
	while($plistrow = cameo_fetch_object($plistrs)){
		//print_r($plistrow);
		if(!in_array($plistrow->emp_id, $skipArr)) {
		if($plistrow->status == 1) {
			if($plistrow->Emp_Status != 1) {
				//$plistrow->status != 
				 $_update_sql = "UPDATE tm_user_mas as umas SET umas.status='".$plistrow->Emp_Status."' WHERE umas.user_id=".$plistrow->user_id;
				cameo_query($_update_sql);				
			}
		}
		}
	}
}
?>
