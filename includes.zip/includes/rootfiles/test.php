<?php
echo date('Y-m-d h:i:s'); die;
include "smb.php";
$dir = "smb://css105428:c@10.185.15.241/etas/QMG-Reports";
if(is_dir($dir)) {
   $dh = opendir($dir);
   while(($file=readdir($dh)) !== false) {
       echo "filename: $file - filetype: ".filetype($dir.'/'.$file)."\n";
   }
   closedir($dh);
}
else {
   echo $dir." Directory failed \n";
}

?>