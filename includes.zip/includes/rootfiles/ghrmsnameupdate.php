<?php

ini_set('display_errors', 1);
error_reporting(22517);
ini_set('max_execution_time', 0);
$livedb="qaportal_live_july31";
$db_url['default'] = "mysql://root:password@localhost/$livedb";
require_once("includes/mysql.inc");
cameo_connect($db_url['default']);


 
//SELECT * FROM tm_trees_hirarchy_mas WHERE 1  AND node_type='C' AND type_id IN('207','208','209')

//SELECT * FROM tm_trees_hirarchy_mas WHERE 1  AND node_type='Q' AND type_id IN('1501','1502','1503','1504','1505','1506','185','1507','1508','1509','1510','1511','1512')
?>