<?php
require 'misc/php/class.JavaScriptPacker.php';
$src = $_GET['file'];
$script = file_get_contents($src);
$packer = new JavaScriptPacker($script, 'Normal', true, false);
$packed = $packer->pack();
echo $packed;
?>