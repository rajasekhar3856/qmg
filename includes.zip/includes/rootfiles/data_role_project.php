<?php
ini_set('display_errors', 1);
error_reporting(22517);
//$db_url['default'] = "mysql://root:@localhost/$demodb";
$db_url['default'] = 'mysql://qaportalusr:Q4Ap0rt412#@localhost/qaportal_live';
require_once("includes/mysql.inc");
cameo_connect($db_url['default']);


$select_sheet_role="Select project_id,sheet_id from tm_sheets_mas where project_id!=''";
$qry_sheet_role = cameo_query($select_sheet_role); 
while($obj_sheet_role = cameo_fetch_object($qry_sheet_role)){
    $sheet_array[$obj_sheet_role->sheet_id]=$obj_sheet_role->project_id;
}



$selectmonitordate="SELECT project_id,sheet_id,emp_id,auto_id_fk FROM  tm_user_role_project_map_history Where status=1 AND sheet_id!=0 ";
$monitordatequery = cameo_query($selectmonitordate); 

while($monitordatefetch = cameo_fetch_object($monitordatequery)){    
   $project_affe[$monitordatefetch->auto_id_fk][$monitordatefetch->sheet_id]= $monitordatefetch->project_id;
}
echo "<pre>";
print_r($project_affe);
echo "--------->>".$sheet_array[86];
 $i=1;
foreach($project_affe as $auto_id_fk => $sheet_id){
     foreach($sheet_id as $sid=>$pid){
         //echo $pid[0]."<br>";
         echo $sid."||===>>>".$pid."||".$sheet_array[$sid]."<br>";
        //echo $sheet_array[$sid]."||===>>>".$pid[1]."||".$pid[0]."<br>";
        if($sheet_array[$sid]!=$pid){
            echo $sid."===>>>>".$sheet_array[$sid]."====>>".($i++)."<br>UPDATE  tm_user_role_project_map_history SET  project_id =".$sheet_array[$sid]." WHERE auto_id_fk=".$auto_id_fk."<br>";
            cameo_query("UPDATE  tm_user_role_project_map_history SET  project_id =".$sheet_array[$sid]." WHERE auto_id_fk=".$auto_id_fk);
//        }else{
//             echo $sheet_array[$sid]."||===>>>".$pid[1]."||".$pid[0]."<br>";
       }
        
            
     }
}

?>