<?php
require_once './includes/cameocore.inc';
global $pageaccess;
cameo_bootsystem();
$return =call_back_path_process();
if(file_exists($return[0]) && $return[3]) {
	if($pageaccess) {
		print themes('page', $return);
	} else {
		print 'Access denied for this page, Click <a href="'.base_path().'">here</a> to go back';
	}
} else {
	print 'Page not found, Click <a href="'.base_path().'">here</a> to go back';
}

//echo "welcome";
?>
