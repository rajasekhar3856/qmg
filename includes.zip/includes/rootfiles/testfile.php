<?php
echo base_path();
?>