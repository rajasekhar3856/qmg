<?php
if(in_array($_SERVER['REMOTE_ADDR'],array("10.8.28.39","10.8.28.32"))) {
require_once './includes/cameocore.inc';
global $pageaccess;
cameo_bootsystem();
$return = call_back_path_process();
if(file_exists($return[0]) && $return[3]) {
	if($pageaccess) {
		print themes('page', $return);
	} else {
		print 'Access denied for this page, Click <a href="'.base_path().'">here</a> to go back';
	}
} else {
	print 'Page not found, Click <a href="'.base_path().'">here</a> to go back';
}
} else {
?>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tableborder_grey">
  <tr>
    <td><table width="100%" border="0" cellpadding="2" cellspacing="0" class="tabborder_grey">
     <tr>
        <td class="tabheading">&nbsp;</td>
      </tr>
      <tr>
        <td class="home_txt">
        <p>
        <img src="server_maintain_img.jpg" align="left">
<b>For your kind information that QMG Portal Application will not be available 
<br><br>from 1.50PM - 2:30PM IST today 
<br><br>for Server Maintenance.
Sorry for the Inconvenience. 
</b>
</p>
		</td>
      </tr>
     </table></td>
  </tr>
</table>
<?php	
}
?>