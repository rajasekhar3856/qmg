<?php
$path = '/var/www/html/qaportal/';
//$path = "D:\\xampp\htdocs\qmg.csscorp.com\source//";
chdir($path);
require_once("custom/settings/settings.php");
require_once("includes/general.inc.php");
ini_set('display_errors', "on");
error_reporting(22517);
require_once("includes/mysql.inc");
global $db_url;
cameo_connect($db_url['default']);
global $dbLink;

$_action_status = array('0');
$_subject_of_alert = 'QMG MOM Manager - Alert Messenger';
$_plain_text = 'QMG MOM Manager - Alert Messenger - Due or Reminder';
$sitelogo = 'https://qmg.csscorp.com/logos/css_logo.png';
$_today = mktime(23,59,59,date("m",time()),date("d",time()),date("Y",time()));
$_10days_before = strtotime("-10 day");
$_tomorrow = strtotime("+2 day");
$_start_time =  mktime(0,0,0,date("m",$_10days_before),date("d",$_10days_before),date("Y",$_10days_before));
$_end_time =  mktime(23,59,59,date("m",$_tomorrow),date("d",$_tomorrow),date("Y",$_tomorrow));

$_action_alert_sql = 'SELECT act.*,DATEDIFF(curdate(),FROM_UNIXTIME(act.estimated_time,"%Y-%m-%d")) days_elapsed,tra.title,tra.agenda,usr.email_id as action_owner_email,usr.name as action_owner_name,IF(ISNULL(map.reporting_to_1),"dummy",map.reporting_to_1) as reporting_1,IF(ISNULL(map.reporting_to_2),"dummy",map.reporting_to_2) as reporting_2 
						   FROM mom_tracker_action_item act  
						   LEFT JOIN mom_tracker tra ON tra.event_id = act.event_id  
						   LEFT JOIN tm_user_role_project_map map ON map.emp_id = act.action_owner  
						   LEFT JOIN tm_user_mas usr ON usr.emp_id = act.action_owner
						   WHERE act.action_owner !=""   AND act.status=0 AND act.action_status IN('.implode(',',$_action_status).') 
						   GROUP BY act.event_action_id
						  ';
//AND FROM_UNIXTIME(act.estimated_time,"%Y-%m-%d") < curdate()
//AND act.estimated_time BETWEEN '.$_start_time.' AND '.$_end_time. '
$_act_result = mysql_query($_action_alert_sql);
//echo '<pre>';
$_arr_action_grouped = array();
if(cameo_num_rows($_act_result) > 0 ) {
	while($row = cameo_fetch_object($_act_result)) {
		if(!empty($row->action_owner)) {
			$_arr_action_grouped[$row->reporting_1][$row->reporting_2][$row->action_owner][] = $row;
		}		
	}
}
$_arr_mail = array();
if(is_array($_arr_action_grouped) && !empty($_arr_action_grouped)) {
	//print_r($_arr_action_grouped);
	//foreach($_arr_action_grouped as $action_data) {
		//print_r($action_data);
	//}
	foreach($_arr_action_grouped as $reporting_2=>$reporting2) {
		if(is_array($reporting2) && !empty($reporting2)) {
			foreach($reporting2 as $reporting_1=>$reporting1) {
				if(is_array($reporting1) && !empty($reporting1)) {
					foreach($reporting1 as $act_owner=>$arr_action_data) {
						if(is_array($arr_action_data) && !empty($arr_action_data)) {
							foreach($arr_action_data as $action_data) {
								//print_r($action_data);
								
								$_action_time = $action_data->estimated_time;
								$_reason = '';
								if($_action_time > $_today )
									$datediff = $_action_time - $_today;
								else
									$datediff = $_today - $_action_time;
								$_date_diff = floor($datediff/(60*60*24));
								//echo "<br>===>>".$action_data->event_id."====".$action_data->event_action_id."====".date("d/m/Y",$action_data->estimated_time)."===".($datediff)."===".(5 * 24 * 60 * 60)."===".(10 * 24 * 60 * 60);
								if($_action_time > $_today) {
									// remainder
									//echo "<br>===>>Reminder  days";
									$_reason = 'Reminder,'.$_date_diff.' Days to go';
									$_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder'][$action_data->event_id]['details'] = array('action_owner_email'=>$action_data->action_owner_email,'action_owner_name'=>$action_data->action_owner_name,'mom_title'=>$action_data->title,'mom_agenda'=>$action_data->agenda);
									$_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder'][$action_data->event_id]['act_data'][] = array('data'=>$action_data,'reason'=>$_reason);
								} elseif(($datediff > (5 * 24 * 60 * 60)) && ( $datediff < (10 * 24 * 60 * 60)) ) {
									// Due more or equal 5 days
									//echo "<br>===>>due 5 days";
									$_reason = 'Due,'.$_date_diff.' Days';
									//$_arr_mail[$reporting_2][$reporting_1]['due_5'][$action_data->event_id]['details'] = array('action_owner_email'=>$action_data->action_owner_email,'action_owner_name'=>$action_data->action_owner_name,'mom_title'=>$action_data->title,'mom_agenda'=>$action_data->agenda);
									$_arr_mail[$reporting_2][$reporting_1]['due_5'][] = array('data'=>$action_data,'reason'=>$_reason);
									$_arr_mail[$reporting_2][$reporting_1][$act_owner]['due5'][$action_data->event_id]['details'] = array('action_owner_email'=>$action_data->action_owner_email,'action_owner_name'=>$action_data->action_owner_name,'mom_title'=>$action_data->title,'mom_agenda'=>$action_data->agenda);
									$_arr_mail[$reporting_2][$reporting_1][$act_owner]['due5'][$action_data->event_id]['act_data'][] = array('data'=>$action_data,'reason'=>$_reason);
								} elseif(($datediff >= (10 * 24 * 60 * 60))) {
									// Due more or equal 10 days
									//echo "<br>===>>due 10 days";
									$_reason = 'Due,'.$_date_diff.' Days ';
									$_arr_mail[$reporting_2]['due_10'][] = array('data'=>$action_data,'reason'=>$_reason);
									$_arr_mail[$reporting_2][$reporting_1][$act_owner]['due10'][$action_data->event_id]['details'] = array('action_owner_email'=>$action_data->action_owner_email,'action_owner_name'=>$action_data->action_owner_name,'mom_title'=>$action_data->title,'mom_agenda'=>$action_data->agenda);
									$_arr_mail[$reporting_2][$reporting_1][$act_owner]['due10'][$action_data->event_id]['act_data'][] = array('data'=>$action_data,'reason'=>$_reason);
								}
							}	//end of action data					
						} //end of action data arr check
						
						if(isset($_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder']) && !empty($_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder'])) {
							//print_r($_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder']);
							$_actioned_item_details = '';
							$_arr_email_details = array();
							
							foreach($_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder'] as $_arr_act_data) {	
								$_arr_email_details = $_arr_act_data['details'];								
								$_actioned_item_details .='<tr>
								  <td><B>Meeting Title: '.$_arr_act_data['details']['mom_title'].'</B></td>
								</tr>
								<tr>
								  <td></td>
								</tr>
							   
								<tr>
								  <td>&nbsp;</td>
								</tr>
								<tr>
								  <td class="table_head">AGENDA:</td>
								</tr>
								<tr>
								  <td>'.$_arr_act_data['details']['mom_agenda'].'</td>
								</tr>
								
								<tr>
								  <td>&nbsp;</td>
								</tr>
								<tr>
								  <td class="table_head"> ACTION ITEM(S): </td>
								</tr>
								<tr>
								  <td>';
								$_actioned_item_details .= '<table width="100%" border="0" class="tableborder_grey">
														  <tr class="table_head_row">
															<td align="center"><strong>S.No</strong></td>
															<td align="center"><strong>Action Item </strong></td>
															<td align="center"><strong>Owner</strong></td>
															<td align="center"><strong>Priority</strong></td>
															<td align="center"><strong>Due Date </strong></td>
															<td align="center"><strong>Comments</strong></td>
															<td align="center"><strong>Reason</strong></td>
														  </tr>';
								$i=1;
								foreach($_arr_act_data['act_data'] as $_arr_act_details) {
									$_actioned_item_details .='<tr>
									  <td width="3%" align="center" valign="top">'.$i++.'</td>
									  <td>'.$_arr_act_details['data']->action_item.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->action_owner_name.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->priority.'</td>
									  <td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$_arr_act_details['data']->estimated_time).'</td>
									  <td align="left" valign="top">'.$_arr_act_details['data']->comment.'</td>
									  <td align="left" valign="top">'.$_arr_act_details['reason'].'</td>
								   </tr>';
								$i++;
							   }
							   $_actioned_item_details .='</table></td>
								</tr><tr>
								  <td>&nbsp;</td>
								</tr>';
							}
							$_template = getEmailTemplate1(5);
							
							$search= array('[username]','[chained_action_items]','[logo]','[momsignature]');
							$replace= array($_arr_email_details['action_owner_name'],$_actioned_item_details,$sitelogo,MOM_SIGNATURE);
							echo "Reminder act own==>>".$content = str_replace($search,$replace,$_template);
							$_arr_from = array();				
							$_arr_from[MOM_FROM_EMAIL] =  MOM_FROM_NAME;
							$_to = array();
							if(isset($_arr_email_details['action_owner_email']) && !empty($_arr_email_details['action_owner_email'])) {
								$_to[trim($_arr_email_details['action_owner_email'])] = $_arr_email_details['action_owner_name'];
							}
							$_options = array();
							if(!empty($_to)) {
								//_mailsend($_subject_of_alert,$content,$_plain_text,$_arr_from,$_to,$_cc,array(),array(),$_options);
							}
							
						}
						if(isset($_arr_mail[$reporting_2][$reporting_1][$act_owner]['due5']) && !empty($_arr_mail[$reporting_2][$reporting_1][$act_owner]['due5'])) {
							//print_r($_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder']);
							$_actioned_item_details = '';
							$_arr_email_details = array();
							
							foreach($_arr_mail[$reporting_2][$reporting_1][$act_owner]['due5'] as $_arr_act_data) {	
								$_arr_email_details = $_arr_act_data['details'];								
								$_actioned_item_details .='<tr>
								  <td><B>Meeting Title: '.$_arr_act_data['details']['mom_title'].'</B></td>
								</tr>
								<tr>
								  <td></td>
								</tr>
							   
								<tr>
								  <td>&nbsp;</td>
								</tr>
								<tr>
								  <td class="table_head">AGENDA:</td>
								</tr>
								<tr>
								  <td>'.$_arr_act_data['details']['mom_agenda'].'</td>
								</tr>
								
								<tr>
								  <td>&nbsp;</td>
								</tr>
								<tr>
								  <td class="table_head"> ACTION ITEM(S): </td>
								</tr>
								<tr>
								  <td>';
								$_actioned_item_details .= '<table width="100%" border="0" class="tableborder_grey">
														  <tr class="table_head_row">
															<td align="center"><strong>S.No</strong></td>
															<td align="center"><strong>Action Item </strong></td>
															<td align="center"><strong>Owner</strong></td>
															<td align="center"><strong>Priority</strong></td>
															<td align="center"><strong>Due Date </strong></td>
															<td align="center"><strong>Comments</strong></td>
															<td align="center"><strong>Reason</strong></td>
														  </tr>';
								$i=1;
								foreach($_arr_act_data['act_data'] as $_arr_act_details) {
									$_actioned_item_details .='<tr>
									  <td width="3%" align="center" valign="top">'.$i++.'</td>
									  <td>'.$_arr_act_details['data']->action_item.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->action_owner_name.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->priority.'</td>
									  <td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$_arr_act_details['data']->estimated_time).'</td>
									  <td align="left" valign="top">'.$_arr_act_details['data']->comment.'</td>
									  <td align="left" valign="top">'.$_arr_act_details['reason'].'</td>
								   </tr>';
								$i++;
							   }
							   $_actioned_item_details .='</table></td>
								</tr><tr>
								  <td>&nbsp;</td>
								</tr>';
							}
							$_template = getEmailTemplate1(5);
							
							$search= array('[username]','[chained_action_items]','[logo]','[momsignature]');
							$replace= array($_arr_email_details['action_owner_name'],$_actioned_item_details,$sitelogo,MOM_SIGNATURE);
							echo "due5 act owner==>>".$content = str_replace($search,$replace,$_template);
							$_arr_from = array();				
							$_arr_from[MOM_FROM_EMAIL] =  MOM_FROM_NAME;
							$_to = array();
							if(isset($_arr_email_details['action_owner_email']) && !empty($_arr_email_details['action_owner_email'])) {
								$_to[trim($_arr_email_details['action_owner_email'])] = $_arr_email_details['action_owner_name'];
							}
							$_options = array();
							if(!empty($_to)) {
								//_mailsend($_subject_of_alert,$content,$_plain_text,$_arr_from,$_to,$_cc,array(),array(),$_options);
							}
							
						}
						if(isset($_arr_mail[$reporting_2][$reporting_1][$act_owner]['due10']) && !empty($_arr_mail[$reporting_2][$reporting_1][$act_owner]['due10'])) {
							//print_r($_arr_mail[$reporting_2][$reporting_1][$act_owner]['reminder']);
							$_actioned_item_details = '';
							$_arr_email_details = array();
							
							foreach($_arr_mail[$reporting_2][$reporting_1][$act_owner]['due10'] as $_arr_act_data) {	
								$_arr_email_details = $_arr_act_data['details'];								
								$_actioned_item_details .='<tr>
								  <td><B>Meeting Title: '.$_arr_act_data['details']['mom_title'].'</B></td>
								</tr>
								<tr>
								  <td></td>
								</tr>
							   
								<tr>
								  <td>&nbsp;</td>
								</tr>
								<tr>
								  <td class="table_head">AGENDA:</td>
								</tr>
								<tr>
								  <td>'.$_arr_act_data['details']['mom_agenda'].'</td>
								</tr>
								
								<tr>
								  <td>&nbsp;</td>
								</tr>
								<tr>
								  <td class="table_head"> ACTION ITEM(S): </td>
								</tr>
								<tr>
								  <td>';
								$_actioned_item_details .= '<table width="100%" border="0" class="tableborder_grey">
														  <tr class="table_head_row">
															<td align="center"><strong>S.No</strong></td>
															<td align="center"><strong>Action Item </strong></td>
															<td align="center"><strong>Owner</strong></td>
															<td align="center"><strong>Priority</strong></td>
															<td align="center"><strong>Due Date </strong></td>
															<td align="center"><strong>Comments</strong></td>
															<td align="center"><strong>Reason</strong></td>
														  </tr>';
								$i=1;
								foreach($_arr_act_data['act_data'] as $_arr_act_details) {
									$_actioned_item_details .='<tr>
									  <td width="3%" align="center" valign="top">'.$i++.'</td>
									  <td>'.$_arr_act_details['data']->action_item.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->action_owner_name.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->priority.'</td>
									  <td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$_arr_act_details['data']->estimated_time).'</td>
									  <td align="left" valign="top">'.$_arr_act_details['data']->comment.'</td>
									  <td align="left" valign="top">'.$_arr_act_details['reason'].'</td>
								   </tr>';
								$i++;
							   }
							   $_actioned_item_details .='</table></td>
								</tr><tr>
								  <td>&nbsp;</td>
								</tr>';
							}
							$_template = getEmailTemplate1(5);
							
							$search= array('[username]','[chained_action_items]','[logo]','[momsignature]');
							$replace= array($_arr_email_details['action_owner_name'],$_actioned_item_details,$sitelogo,MOM_SIGNATURE);
							echo "due10 act owner==>>".$content = str_replace($search,$replace,$_template);
							$_arr_from = array();				
							$_arr_from[MOM_FROM_EMAIL] =  MOM_FROM_NAME;
							$_to = array();
							if(isset($_arr_email_details['action_owner_email']) && !empty($_arr_email_details['action_owner_email'])) {
								$_to[trim($_arr_email_details['action_owner_email'])] = $_arr_email_details['action_owner_name'];
							}
							$_options = array();
							if(!empty($_to)) {
								//_mailsend($_subject_of_alert,$content,$_plain_text,$_arr_from,$_to,$_cc,array(),array(),$_options);
							}
							
						}
					} //end of act owner
				} //end of act owner arr check
				if(isset($_arr_mail[$reporting_2][$reporting_1]['due_5']) && !empty($_arr_mail[$reporting_2][$reporting_1]['due_5'])) {
					//print_r($_arr_mail[$reporting_2][$reporting_1]['due_5']);
					$_actioned_item_details = '';
					$_actioned_item_details = '<table width="100%" border="0" class="tableborder_grey">
														  <tr class="table_head_row">
															<td align="center"><strong>S.No</strong></td>
															<td align="center"><strong>MOM Title</strong></td>
															<td align="center"><strong>Action Item </strong></td>
															<td align="center"><strong>Owner</strong></td>
															<td align="center"><strong>Priority</strong></td>
															<td align="center"><strong>Due Date </strong></td>
															<td align="center"><strong>Comments</strong></td>
															<td align="center"><strong>Reason</strong></td>
														  </tr>';
					$i=1;
					foreach($_arr_mail[$reporting_2][$reporting_1]['due_5'] as $_arr_act_details) {
						$_actioned_item_details .='<tr>
									  <td width="3%" align="center" valign="top">'.$i++.'</td>
									  <td>'.$_arr_act_details['data']->title.'</td>
									   <td>'.$_arr_act_details['data']->action_item.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->action_owner_name.'</td>
									  <td align="center" valign="top">'.$_arr_act_details['data']->priority.'</td>
									  <td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$_arr_act_details['data']->estimated_time).'</td>
									  <td align="left" valign="top">'.$_arr_act_details['data']->comment.'</td>
									  <td align="left" valign="top">'.$_arr_act_details['reason'].'</td>
								   </tr>';
					$i++;
					}
					$_actioned_item_details .= '</table>';
					$_template = getEmailTemplate1(6);
					$_arr_rep1_details = getEmailAndName($reporting_1);
					if(!empty($_arr_rep1_details)) {
						$search= array('[username]','[actionitemlists]','[logo]','[momsignature]');
						$replace= array($_arr_rep1_details[$reporting_1]['name'],$_actioned_item_details,$sitelogo,MOM_SIGNATURE);
						echo "due5 reporting1==>>".$content = str_replace($search,$replace,$_template);
						$_arr_from = array();				
						$_arr_from[MOM_FROM_EMAIL] =  MOM_FROM_NAME;
						$_to = array();
						if(isset($_arr_rep1_details[$reporting_1]['id']) && !empty($_arr_rep1_details[$reporting_1]['id'])) {
							$_to[trim($_arr_rep1_details[$reporting_1]['id'])] = $_arr_rep1_details[$reporting_1]['name'];
						}
						$_options = array();
						if(!empty($_to)) {
							//_mailsend($_subject_of_alert,$content,$_plain_text,$_arr_from,$_to,$_cc,array(),array(),$_options);
						}
					}
				}
			} //end of reporting1
		} //end of act reporting 1 arr check
		if(isset($_arr_mail[$reporting_2]['due_10']) && !empty($_arr_mail[$reporting_2]['due_10'])) {
			
			$_actioned_item_details = '';
			$_actioned_item_details = '<table width="100%" border="0" class="tableborder_grey">
												  <tr class="table_head_row">
													<td align="center"><strong>S.No</strong></td>
													<td align="center"><strong>MOM Title</strong></td>
													<td align="center"><strong>Action Item </strong></td>
													<td align="center"><strong>Owner</strong></td>
													<td align="center"><strong>Priority</strong></td>
													<td align="center"><strong>Due Date </strong></td>
													<td align="center"><strong>Comments</strong></td>
													<td align="center"><strong>Reason</strong></td>
												  </tr>';
			$i=1;
			foreach($_arr_mail[$reporting_2]['due_10'] as $_arr_act_details) {
				$_actioned_item_details .='<tr>
							  <td width="3%" align="center" valign="top">'.$i++.'</td>
							  <td>'.$_arr_act_details['data']->title.'</td>
							  <td>'.$_arr_act_details['data']->action_item.'</td>
							  <td align="center" valign="top">'.$_arr_act_details['data']->action_owner_name.'</td>
							  <td align="center" valign="top">'.$_arr_act_details['data']->priority.'</td>
							  <td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$_arr_act_details['data']->estimated_time).'</td>
							  <td align="left" valign="top">'.$_arr_act_details['data']->comment.'</td>
							  <td align="left" valign="top">'.$_arr_act_details['reason'].'</td>
						   </tr>';
				$i++;
			}
			$_actioned_item_details .= '</table>';
			$_template = getEmailTemplate1(6);
			$_arr_rep2_details = getEmailAndName($reporting_2);
			
			$search= array('[username]','[actionitemlists]','[logo]','[momsignature]');
			$replace= array($_arr_rep2_details[$reporting_2]['name'],$_actioned_item_details,$sitelogo,MOM_SIGNATURE);
			echo "due5 reporting2==>>".$content = str_replace($search,$replace,$_template);
			$_arr_from = array();				
			$_arr_from[MOM_FROM_EMAIL] =  MOM_FROM_NAME;
			$_to = array();
			if(isset($_arr_rep2_details[$reporting_2]['id']) && !empty($_arr_rep2_details[$reporting_2]['id'])) {
				$_to[trim($_arr_rep2_details[$reporting_2]['id'])] = $_arr_rep2_details[$reporting_2]['name'];
			}
			$_options = array();
			if(!empty($_to)) {
				//_mailsend($_subject_of_alert,$content,$_plain_text,$_arr_from,$_to,$_cc,array(),array(),$_options);
			}
			
		}
	} //end of reporting2
	
}






?>