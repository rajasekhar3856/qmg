#!/bin/bash
cd /disk2/htdocs/qaportal/solr-4.6.0/example
/usr/bin/java -jar start.jar

#chmod og+x start.sh
#/etc/rc.local -- /disk2/htdocs/qaportal/start_solr.sh