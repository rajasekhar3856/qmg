<?php
ini_set('display_errors', 1);
error_reporting(22517);
//$path = '/var/www/html/qaportal/';
//chdir($path);
//echo "sagfsagfsd";
//require_once("custom/settings/settings.php");

$livedb="qaportal_live_july31";
$demodb="qaportal_demo";

$db_url['default'] = "mysql://root:@localhost/$demodb";
require_once("includes/mysql.inc");
cameo_connect($db_url['default']);


$selectmonitordate="SELECT monitor_date FROM  $demodb.tm_user_monitoring_mas ORDER BY eval_id_pk desc LIMIT 1";
$monitordatequery = cameo_query($selectmonitordate); 

$monitordatefetch = cameo_fetch_object($monitordatequery);
$monitor_date=$monitordatefetch->monitor_date;


$selectevalutionkey="SELECT eval_id_pk FROM  $livedb.tm_user_monitoring_mas WHERE monitor_date > '".$monitor_date."' AND project_id IN(19) AND sheet_id IN(26,27) LIMIT 1";
$evalutionkeyquery = cameo_query($selectevalutionkey); 
$evalutionkeyfetch = cameo_fetch_object($evalutionkeyquery);
$newEkeystarts=$evalutionkeyfetch->eval_id_pk;
if($monitor_date==''){
    $monitor_date='2012-06-01';
}
    

echo $insertUMMQuery="INSERT INTO $demodb.tm_user_monitoring_mas  SELECT * FROM $livedb.tm_user_monitoring_mas WHERE monitor_date > '".$monitor_date."' AND project_id IN(19) AND sheet_id IN(26,27)";
$aResultMasterTrans = cameo_query($insertUMMQuery);

$insertUmcQuery="INSERT INTO $demodb.tm_user_monitoring_comments  SELECT * FROM $livedb.tm_user_monitoring_comments WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmcQuery);

$insertUmcQuery="INSERT INTO $demodb.tm_user_monitoring_coaching  SELECT * FROM $livedb.tm_user_monitoring_coaching WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmcQuery);

$insertUmstQuery="INSERT INTO $demodb.tm_user_monitoring_sections_trans  SELECT * FROM $livedb.tm_user_monitoring_sections_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmstQuery);   

$insertUmbtQuery="INSERT INTO $demodb.tm_user_monitoring_bi_trans  SELECT * FROM $livedb.tm_user_monitoring_bi_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmbtQuery);  

$insertUmptQuery="INSERT INTO $demodb.tm_user_monitoring_pcsat_trans  SELECT * FROM $livedb.tm_user_monitoring_pcsat_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmptQuery);          

$insertUmttQuery="INSERT INTO $demodb.tm_user_monitoring_tmf_trans SELECT * FROM $livedb.tm_user_monitoring_tmf_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmttQuery);           

$insertUmctQuery="INSERT INTO $demodb.tm_user_monitoring_criticals_trans  SELECT * FROM $livedb.tm_user_monitoring_criticals_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmctQuery);   

$insertUmtctQuery="INSERT INTO $demodb.tm_user_monitoring_tmf_criticals_trans  SELECT * FROM $livedb.tm_user_monitoring_tmf_criticals_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmtctQuery); 

$insertUmtctQuery="INSERT INTO $demodb.tm_user_monitoring_headers_trans  SELECT * FROM $livedb.tm_user_monitoring_headers_trans WHERE eval_id_fk >='".$newEkeystarts."'";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_sheets_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_sheets_mas  SELECT * FROM $livedb.tm_sheets_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_sheet_versions";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_sheet_versions  SELECT * FROM $livedb.tm_sheet_versions WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_sheet_form_map";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_sheet_form_map  SELECT * FROM $livedb.tm_sheet_form_map WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_projects_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_projects_mas  SELECT * FROM $livedb.tm_projects_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_forms_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_forms_mas  SELECT * FROM $livedb.tm_forms_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_forms_criticals_map";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_forms_criticals_map  SELECT * FROM $livedb.tm_forms_criticals_map WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_forms_sections_map";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_forms_sections_map  SELECT * FROM $livedb.tm_forms_sections_map WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_sections_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_sections_mas  SELECT * FROM $livedb.tm_sections_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_questions_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_questions_mas  SELECT * FROM $livedb.tm_questions_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_answer_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_answer_mas  SELECT * FROM $livedb.tm_answer_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_criticals_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_criticals_mas  SELECT * FROM $livedb.tm_criticals_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_sections_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_sections_mas  SELECT * FROM $livedb.tm_sections_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_custom_field_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_custom_field_mas  SELECT * FROM $livedb.tm_custom_field_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_custom_field_options_trans";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_custom_field_options_trans  SELECT * FROM $livedb.tm_custom_field_options_trans WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_email_templates";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_email_templates  SELECT * FROM $livedb.tm_email_templates WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);


$truncate_table="TRUNCATE TABLE tm_user_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_user_mas  SELECT * FROM $livedb.tm_user_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_user_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_user_mas  SELECT * FROM $livedb.tm_user_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_trees_hirarchy_mas";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_trees_hirarchy_mas  SELECT * FROM $livedb.tm_trees_hirarchy_mas WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_trees_hirarchy_mas_history";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_trees_hirarchy_mas_history  SELECT * FROM $livedb.tm_trees_hirarchy_mas_history WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_trees_hirarchy_mas_version";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_trees_hirarchy_mas_version  SELECT * FROM $livedb.tm_trees_hirarchy_mas_version WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_user_role_project_map";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_user_role_project_map  SELECT * FROM $livedb.tm_user_role_project_map WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);

$truncate_table="TRUNCATE TABLE tm_user_role_project_map_history";
$Result_Query=  cameo_query($truncate_table);

$insertUmtctQuery="INSERT INTO $demodb.tm_user_role_project_map_history  SELECT * FROM $livedb.tm_user_role_project_map_history WHERE 1";	
$aResultComments = cameo_query($insertUmtctQuery);








?>