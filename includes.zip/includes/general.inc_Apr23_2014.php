<?php 
$_SESSION['MY_TITTLE']='QMG-CSS CORP';
function getClientIp() {
		 
		return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0000';
}
	
function getIpTable() {
	$_ipArray = file('./custom/settings/.iptable', FILE_IGNORE_NEW_LINES + FILE_SKIP_EMPTY_LINES);
	return $_ipArray;
}

function ipArrayToRegex($_ipArray) {
	$_return = array();
	foreach ($_ipArray as $_key => $_value) {
		$_value = trim($_value);
		if ($_value) {
			$_value = explode('.', $_value);
			if (4 == count($_value)) {
				$_return[$_key] = '/^' . preg_quote(implode('.', $_value)) . '$/';
			} else {
				$_return[$_key] = '/^' . preg_quote(implode('.', $_value)) . '/';
			}
		}
	}
	return $_return;
}
function pageid($id){
    $pages=array("1"=>"Monitoring User","2"=>"Monitoring Audit","3"=>"Callibration","4"=>"Calibration Audit");    
    return $pages[$id];
}
function blockIp() {
	global $user;
	$allowed = false;
	if($user->user_type != 2 &&  $user->active_role!=6 ) {
		$allowed = false;
		$_userIp    = getClientIp();
		if($_userIp == "::1") {
			$allowed = true;
		} else {
			$_allowedIp = ipArrayToRegex(getIpTable());
			foreach ($_allowedIp as $_regex) {
				if (preg_match($_regex, $_userIp)) {
					$allowed = true;
				}
			}
		}
	} else {
		$allowed = true;
	}
	$allowed = true;
	return $allowed;
}
function subval_sort($a,$subkey,$order='asc') {
    foreach($a as $k=>$v) {
            $b[$k] = strtolower($v[$subkey]);
    }
	if($order == 'asc')
		asort($b);
	else
		arsort($b);
    foreach($b as $key=>$val) {
            $c[] = $a[$key];
    }
    return $c;
}
function ExcelToPHP($dateValue = 0, $ExcelBaseDate = 1900) {
    if ($ExcelBaseDate == 1900) {
        $myExcelBaseDate = 25569;
        //    Adjust for the spurious 29-Feb-1900 (Day 60)
        if ($dateValue < 60) {
            --$myExcelBaseDate;
        }
    } else {
        $myExcelBaseDate = 24107;
    }

    // Perform conversion
    if ($dateValue >= 1) {
        $utcDays = $dateValue - $myExcelBaseDate;
        $returnValue = round($utcDays * 86400);
        if (($returnValue <= PHP_INT_MAX) && ($returnValue >= -PHP_INT_MAX)) {
            $returnValue = (integer) $returnValue;
        }
    } else {
        $hours = round($dateValue * 24);
        $mins = round($dateValue * 1440) - round($hours * 60);
        $secs = round($dateValue * 86400) - round($hours * 3600) - round($mins * 60);
        $returnValue = (integer) gmmktime($hours, $mins, $secs);
    }

    // Return
    return $returnValue;
}
function ExcelToPHPObject($dateValue = 0, $ExcelBaseDate = 1900) {
    $dateTime = ExcelToPHP($dateValue, $ExcelBaseDate);
    $days = floor($dateTime / 86400);
    $time = round((($dateTime / 86400) - $days) * 86400);
    $hours = round($time / 3600);
    $minutes = round($time / 60) - ($hours * 60);
    $seconds = round($time) - ($hours * 3600) - ($minutes * 60);
//	echo "<br>===>ss".$days."===".$hours."===".$minutes."===".$seconds;
    $dateObj = date_create('1-Jan-1970+'.$days.' days');
    $dateObj->setTime($hours,$minutes,$seconds);

    return $dateObj;
}

function find_week($ddate){
$duedt = explode("-", $ddate);
$date  = mktime(0, 0, 0, $duedt[1], $duedt[2], $duedt[0]);
$week  = (int)date('W', $date);
return $week;
}

function work_flow_processes() {
	$_arr_workflow = array('evaluation_done'=>'Evaluation Done','evaluation_done_fail'=>'Evaluation Done - Failed Transactions','coaching_done'=>'Coaching Done','coaching_accepted'=>'Coaching Accepted','coaching_escalated'=>'Coaching Escalated','coaching_escalation_com'=>'Coaching Escalation Comments');
	return $_arr_workflow;
}

function work_flow_processes_templates($_process) {
	$_arr_workflow = array('evaluation_done'=>1,'evaluation_done_fail'=>1,'coaching_done'=>2,'coaching_accepted'=>3,'coaching_escalated'=>4,'coaching_escalation_com'=>5);
	return $_arr_workflow[$_process];
}
function work_flow_processes_templates_bysheet($_sheet,$_process) {
	$_arr_workflow = array();
	//$_arr_workflow = array(1=>array('evaluation_done'=>1,'evaluation_done_fail'=>2,'coaching_done'=>3,'coaching_accepted'=>4,'coaching_escalated'=>5,'coaching_escalation_com'=>6));
	return (isset($_arr_workflow[$_sheet][$_process])?$_arr_workflow[$_sheet][$_process]:false);
}

function select_workflow_template($_sheet,$_process) {
	$template_id = work_flow_processes_templates_bysheet($_sheet,$_process);
	if(!$template_id) {
		$template_id = work_flow_processes_templates($_process);
	} 
	return $template_id;
	
}

function parse_template($_sheet,$_process,$replacements) {	
	/*$replacements = array(
	   'tl' => 'mytlname',
	   'agent' => 'myname',
	);*/
	$template_id = select_workflow_template($_sheet,$_process);	
	$sql = "SELECT * FROM `tm_email_templates` WHERE template_id=".$template_id;
	$result = cameo_query($sql);
	$_parsed_array = array();
	if(cameo_num_rows($result) > 0) {
		$row = cameo_fetch_object($result);
		//print_r($row);
		//\{\{ *form *\| *(\S+) *\}\}
		$template_to = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			return $replacements[strtolower($match[1])];
		}, $row->template_to);
		$template_cc = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			return $replacements[strtolower($match[1])];
		}, $row->template_cc);
		$template_bcc = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			return $replacements[strtolower($match[1])];
		}, $row->template_bcc);
		$template_subject = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			$_arr_result = explode(".",$match[1]);
			if(count($_arr_result)>1) {
				return $replacements[strtolower($_arr_result[0])][$_arr_result[1]];
			} else {
				return $replacements[strtolower($_arr_result[0])];
			}
		}, $row->template_subject);
		$template_content = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			$_arr_result = explode(".",$match[1]);
			if(count($_arr_result)>1) {
				return $replacements[strtolower($_arr_result[0])][$_arr_result[1]];
			} else {
				return $replacements[strtolower($_arr_result[0])];
			}
		}, $row->template_content);
		$_parsed_array =  array('template_to'=>$template_to,'template_cc'=>$template_cc,'template_bcc'=>$template_bcc,'template_subject'=>$template_subject,'template_content'=>$template_content);
		
	}
	return $_parsed_array;
}   

function category_name($cat_id){
    $cat="SELECT  category_name FROM tm_categories_mas Where category_id=".$cat_id;
    $category = cameo_query($cat);
    $category_data = cameo_fetch_object($category);
    return $category_data->category_name;
}

function question_name($que_id){
    $quest="SELECT  question_name FROM tm_questions_mas Where question_id=".$que_id;
    $question = cameo_query($quest);
    $question_data = cameo_fetch_object($question);
    return $question_data->question_name;
}

function answer_name($ans_id){
    $answ="SELECT  answer FROM tm_answer_mas Where answer_id=".$ans_id;
    $answer = cameo_query($answ);
    $answer_data = cameo_fetch_object($answer);
    return $answer_data->answer;
}

function evaluation_details($_eval_id) {
	$tid = $_eval_id;
	$headsql = "SELECT m.eval_id_pk, m.emp_id, m.emp_reporting_1 as reporting_1, m.emp_reporting_2 as reporting_2, m.project_id,m.sheet_id,m.monitor_by, m.monitor_by_role as role_id,
                m.monitor_date, m.overall_score, m.trans_status, m.coaching_type,m.trans_type,m.direction_type,
                m.call_duration, m.cls_id, m.cls_date,m.case_no, nt.ntrans_name, tq.qtrans_name, mt.mtype_name, 
                g.geography_name, prj.project_name, 
                usr.name, usr1.name as monitor_name, usr2.name as tl_name, usr3.name as rep_name
                FROM tm_user_monitoring_mas m 
                LEFT JOIN tm_geography_mas g ON g.geography_id=m.geography_id
                LEFT JOIN tm_projects_mas prj ON prj.project_id = m.project_id 
                LEFT JOIN tm_nature_transaction_mas nt ON nt.ntrans_id =m.trans_nature
                LEFT JOIN tm_monitoring_type_mas mt ON mt.mtype_id = m.monitor_type
                LEFT JOIN tm_transaction_quality_mas tq ON tq.qtrans_id = m.trans_quality 
                LEFT JOIN tm_user_mas usr ON usr.emp_id = m.emp_id 
                LEFT JOIN tm_user_mas usr1 ON usr1.emp_id = m.monitor_by 
                LEFT JOIN tm_user_mas usr2 ON usr2.emp_id = m.emp_reporting_1  
                LEFT JOIN tm_user_mas usr3 ON usr3.emp_id = m.emp_reporting_2                
                WHERE m.eval_id_pk=%d";
   $headrs = cameo_query($headsql, $tid);  
   
   while($headrow = cameo_fetch_object($headrs)) {
       $data['headers'] = $headrow;
   }
   $cfheader = "SELECT scf.cf_id, cf.cf_name, cf.cf_type FROM tm_sheet_custom_field_map scf 
                LEFT JOIN  tm_user_monitoring_mas mon ON mon.sheet_id=scf.sheet_id 
                LEFT JOIN tm_custom_field_mas cf ON cf.cf_id=scf.cf_id
                WHERE mon.eval_id_pk=%d";
   $cfheadrs = cameo_query($cfheader, $tid);
   while($cfheadrow = cameo_fetch_object($cfheadrs)) {
       $data["cfheaders"][$cfheadrow->cf_id]["name"] = $cfheadrow->cf_name;
        if($cfheadrow->cf_type==1 || $cfheadrow->cf_type==2){
            $cfs[] = "m.cf_$cfheadrow->cf_id"; 
        } else if($cfheadrow->cf_type==3 || $cfheadrow->cf_type==4){
            $cfs[] = "cft_$cfheadrow->cf_id.text cf_$cfheadrow->cf_id";
            $cftb .= "LEFT JOIN tm_custom_field_options_trans cft_$cfheadrow->cf_id ON cft_$cfheadrow->cf_id.cf_id_fk='$cfheadrow->cf_id' and m.cf_$cfheadrow->cf_id=cft_$cfheadrow->cf_id.cf_opt_id ";
        }
   }
   $cfdsql = "SELECT ". implode(",",$cfs)." FROM tm_user_monitoring_headers_trans m $cftb WHERE m.eval_id_fk=%d";
   $cfdrs = cameo_query($cfdsql,$tid);
   
   foreach($data["cfheaders"] as $cfkey=>$cfd) {
       $data["cfheaddata"][] = array($cfd["name"], cameo_result($cfdrs, 0,"cf_".$cfkey));
   }
   $gsql = "SELECT ctgy.category_id, ctgy.category_name, q.question_id, q.question_name,a.answer, mt.comments, mt.score, crtl.color , crtl.critical_name, crtl.short_code
            FROM tm_user_monitoring_tmf_trans mt 
            LEFT JOIN tm_categories_mas ctgy ON ctgy.category_id=mt.category_id 
            LEFT JOIN tm_questions_mas q ON q.question_id=mt.question_id
            LEFT JOIN tm_answer_mas a ON a.answer_id=mt.answer_id
	    LEFT JOIN tm_criticals_mas crtl ON crtl.critical_id=mt.critical_id
            WHERE mt.eval_id_fk =%d ORDER BY mt.fk_tree_id ASC";
   
   $grs = cameo_query($gsql, $tid);
   while($grow = cameo_fetch_object($grs)) {
       $data['gradings'][$grow->category_id]["name"] = $grow->category_name;
       $data['gradings'][$grow->category_id]["questions"][$grow->question_id] = array($grow->question_name,$grow->answer, $grow->score,$grow->comments, $grow->color, $grow->critical_name, $grow->short_code);
   }
   $tmfcrtsql = "SELECT * FROM `tm_user_monitoring_tmf_criticals_trans` tmfctrns
                LEFT JOIN tm_form_type_mas ft ON ft.form_type_id =tmfctrns.form_type_id 
                WHERE eval_id_fk=%d";
   $tmfcrtrs = cameo_query($tmfcrtsql, $tid);
   $tmfcrtrow = cameo_fetch_object($tmfcrtrs);
   $crtlsql = "SELECT * FROM `tm_criticals_mas` WHERE `default`=1";
   $crtlrs = cameo_query($crtlsql);
   
   while($crtlrow = cameo_fetch_object($crtlrs)) {
       $cid = $crtlrow->critical_id;
       if($tmfcrtrow->{c.$cid._id}!=NULL) {
       $data['criticals'][$crtlrow->form_type_id]["name"] = $tmfcrtrow->form_type_name;
       $data['criticals'][$crtlrow->form_type_id]["critical"][$crtlrow->critical_id] = array($crtlrow->critical_name, $tmfcrtrow->{c.$cid._score});
       }
   }
   
   $crtsql = "SELECT crts.critical_id, crts.critical_name, ft.form_type_id,ft.form_type_name, ct.score FROM tm_user_monitoring_criticals_trans ct 
            LEFT JOIN tm_criticals_mas crts ON crts.critical_id= ct.critical_id
            LEFT JOIN tm_form_type_mas ft ON ft.form_type_id = ct.form_type_id WHERE ct.eval_id_fk =%d";
   $crtrs = cameo_query($crtsql, $tid);
   while($crtrow = cameo_fetch_object($crtrs)) {
       $data['criticals'][$crtrow->form_type_id]["name"] = $crtrow->form_type_name;
       $data['criticals'][$crtrow->form_type_id]["critical"][$crtrow->critical_id] = array($crtrow->critical_name, $crtrow->score);

   }
	$replacements=array();	
	$replacements['agent_id'] = $data['headers']->emp_id;
	$replacements['tl_id'] = $data['headers']->reporting_1;
	$replacements['tm_id'] = $data['headers']->reporting_2;		
	$replacements['project_id'] = $data['headers']->project_id;
	$replacements['sheet_id'] = $data['headers']->sheet_id;
	$replacements['monitor_by_id'] = $data['headers']->monitor_by;
	$replacements['monitor_by_role_id'] = $data['headers']->role_id;
	$emp_ids = $data['headers']->emp_id.','.$data['headers']->reporting_1.','.$data['headers']->reporting_2.','.$data['headers']->monitor_by;
	$_email_arr = get_email_address($emp_ids);
	$replacements['agent_email'] = (isset($_email_arr[$data['headers']->emp_id]))?$_email_arr[$data['headers']->emp_id]['email']:'';
	$replacements['tl_email'] = (isset($_email_arr[$data['headers']->reporting_1]))?$_email_arr[$data['headers']->reporting_1]['email']:'';
	$replacements['tm_email'] = (isset($_email_arr[$data['headers']->reporting_2]))?$_email_arr[$data['headers']->reporting_2]['email']:'';
	$replacements['monitor_by_email'] = (isset($_email_arr[$data['headers']->monitor_by]))?$_email_arr[$data['headers']->monitor_by]['email']:'';
	
	
	$replacements['agent_name'] = (isset($_email_arr[$data['headers']->emp_id]))?$_email_arr[$data['headers']->emp_id]['name']:'';
	$replacements['tl_name'] = (isset($_email_arr[$data['headers']->reporting_1]))?$_email_arr[$data['headers']->reporting_1]['name']:'';
	$replacements['tm_name'] = (isset($_email_arr[$data['headers']->reporting_2]))?$_email_arr[$data['headers']->reporting_2]['name']:'';		
	$replacements['project_name'] = get_project_name($data['headers']->project_id);
	$replacements['sheet_name'] = get_sheet_name($data['headers']->sheet_id);
	$replacements['monitor_by_name'] = (isset($_email_arr[$data['headers']->monitor_by]))?$_email_arr[$data['headers']->monitor_by]['name']:'';
	$replacements['monitor_by_role_name'] = get_role_name($data['headers']->role_id);
	
	$replacements['monitoring_details'] = (array)$data['headers'];
	
   
   return $replacements;
   
}

function send_workflow_email($_sheet,$_process,$replacements=array(),$bmsg=false,$bsub=false) {
	$sql = "SELECT email_enabled,email_workflow FROM tm_sheets_mas WHERE sheet_id='%d'";
	//echo sprintf($sql,$_sheet);
	$result_set = cameo_query($sql,$_sheet);
	if(cameo_num_rows($result_set) > 0) {
		$_allowed_workflow = array();
		$row = cameo_fetch_object($result_set);
		if(!empty($row->email_workflow)) {
			$_allowed_workflow = explode(",",$row->email_workflow);
		}
		//print_r($_allowed_workflow);
		if($row->email_enabled == 1  && in_array($_process,$_allowed_workflow) ) {			
			$_parsed_array = parse_template($_sheet,$_process,$replacements);
			if(!empty($_parsed_array)) {
				//Sent mail to configred mails
				if($bmsg !== false ) {
				//Template already ready so just send
					$_parsed_array['template_content'] = $bmsg;
				} 
				if($bsub !== false) {
				//Template already ready so just send
					$_parsed_array['template_subject'] = $bsub;
				}
				$to_address = get_email_address(substr(trim($_parsed_array['template_to']), 0, -1));
				$cc_address = get_email_address(substr(trim($_parsed_array['template_cc']), 0, -1));
				$bcc_address = get_email_address(substr(trim($_parsed_array['template_bcc']), 0, -1));
				$_mail_array = array();
				$_mail_array['to'] = $to_address;
				$_mail_array['cc'] = $cc_address;
				$_mail_array['bcc'] = $bcc_address;
				$_mail_array['subject'] = trim($_parsed_array['template_subject']);
				$_mail_array['body'] = trim($_parsed_array['template_content']);
				//print_r($_mail_array);
				sendmail($_mail_array);
			} 
		}
	}
	//exit;
}

function get_email_address($emp_ids) {
	$_sql = "SELECT emp_id,email_id,name FROM tm_user_mas WHERE emp_id IN($emp_ids)";
	$_rset = cameo_query($_sql);
	$_email_arr = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset)) {
			$_email_arr[$row->emp_id] = array('name'=>$row->name,'email'=>$row->email_id);
		}
	}
	return $_email_arr;
}

function get_project_name($_project_id) {
	$_sql = "SELECT project_name FROM tm_projects_mas WHERE project_id = $_project_id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->project_name;
	}
	return '';
}

function critical_name($id){
    $_sql = "SELECT critical_name FROM tm_criticals_mas WHERE critical_id = $id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->critical_name;
	}
	return '';
}

function user_name($id){
    $_sql = "SELECT name FROM tm_user_mas WHERE emp_id = $id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->name;
	}
	return '';
}

function get_first_letter($string){
        $temp = explode(' ', $string);
        $result = '';
        foreach($temp as $t)
            $result .= $t[0];

        return strtoupper($result);
    }

function get_sheet_name($_sheet_id) {
	$_sql = "SELECT sheet_name FROM tm_sheets_mas WHERE sheet_id = $_sheet_id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->sheet_name;
	}
	return '';
}

function get_role_name($_role_id) {
	$_sql = "SELECT user_role_name FROM tm_user_role_mas WHERE user_role_id = $_role_id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->user_role_name;
	}
	return '';
}

function sendmail($_mail_array) {
	$mail = new PHPMailer(true);
	try {
		//$mail->SetFrom('mahesh.mahendran@csscorp.com', 'Mahesh M');
		$mail->AddReplyTo('noreply-qmg@csscorp.com', 'Quality Management Group');
		if(!empty($_mail_array['to'])) {
			foreach($_mail_array['to'] as $emails) {
				if (filter_var($emails['email'], FILTER_VALIDATE_EMAIL)) {
					$mail->AddAddress($emails['email'], $emails['name']);
				}
			}
		}
		if(!empty($_mail_array['cc'])) {
			foreach($_mail_array['cc'] as $emails) {
				if (filter_var($emails['email'], FILTER_VALIDATE_EMAIL)) {
					$mail->AddCC($emails['email'], $emails['name']);
				}
			}
		}
		if(!empty($_mail_array['bcc'])) {
			foreach($_mail_array['bcc'] as $emails) {
				if (filter_var($emails['email'], FILTER_VALIDATE_EMAIL)) {
					$mail->AddBCC($emails['email'], $emails['name']);
				}
			}
		}
		$mail->Subject = $_mail_array['subject'];
		$mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // optional - MsgHTML will create an alternate automatically
		$mail->MsgHTML($_mail_array['body']);
		$mail->Send();
		//print_r($mail);		
	} catch (phpmailerException $e) {
		echo $e->errorMessage();
	} catch (Exception $e) {
		echo $e->errorMessage();
	}
}

function getIsoWeeksInYear($year) {
	$date = new DateTime;
	$date->setISODate($year, 53);
	return ($date->format("W") === "53" ? 53 : 52);
}

function getStartAndEndDate($week, $year) {
	$date_string = $year . 'W' . sprintf('%02d', $week);
	$return[0] = date('Y-m-d', strtotime($date_string));
	$return[1] = date('Y-m-d', strtotime($date_string . '7'));
	return $return;
}

function getweeks($month,$year) {
    $months = array(1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December');
    $ts = strtotime("$months[$month] $year");
    $firstdate=date('Y-m-01', $ts);
    $lastdate=date('Y-m-t', $ts);
    $stweek=date('W',  strtotime($firstdate));
    $ltweek=date('W',  strtotime($lastdate));
	$weeks = array();
    for ($week=$stweek; $week<=$ltweek; $week++) {
       $weeks[] = (int)$week.'-'.$year;
    }    
    return $weeks;    
}

function screen_status($status,$param=''){
    if($status==1)
        $current_status='Waiting for TL/TM Approval';
    else if($status==2 && $param==0)
        $current_status='Declined by TL/TM';
    else if($status==2 && $param!=0)
        $current_status='Declined by TL/TM-Parameter';
    else if($status==3)
        $current_status='Improved Suggestion';
//    else if($status==4)
//        $current_status='Declined by Agent';
    else if($status==5)
        $current_status='TL/TM Accepted, Waiting for Manager Approval';
    else if($status==6)
        $current_status='Need Improvement by TL/TM';

    else if($status==8)
        $current_status='Accepted By Manager';
    else if($status==9)
        $current_status='Declined By Manager';
    else if($status==10)
        $current_status='Implementation status';
    else if($status==11)
        $current_status='Waiting for Certification';
     else if($status==12)
        $current_status='Implementation status-Yes';
      else if($status==13)
        $current_status='Implementation status-No';
       else if($status==14)
        $current_status='Implementation status-Pending';
    
    
    return $current_status;
    
}

function page_name($name){
    $select_name='Select module_name from fw_modules_mas Where page LIKE "%'.$name.'/%"  ORDER BY uid DESC  LIMIT 0,1';
   
    $_rset = cameo_query($select_name);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
                return ucfirst(str_replace("_", " ", $row->module_name));
        }else{
            $exp_name=explode($name);
            if($name=='/'){
                 return 'Home';
            }elseif ($exp_name[0]=='default') {
                  return 'Home';
             }else{            
             return 'Home';
             }
        }
}

function folder_tree($archive=0) {
    global $user;
    if($archive==0)
    $deleted=' AND tm_folder_mas.deleted=0 ';
else
    $deleted='';
	$select_name="select tm_folder_mas.*, (select count(distinct c1.folder_id) from tm_folder_mas as c1   where c1.folder_pararent_id = tm_folder_mas.folder_id ) as ChildCount from tm_folder_mas WHERE 1 $deleted  AND status=1 order by folder_order";
	$_rset = cameo_query($select_name);
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[] = $row;
		}
	}
	return $rows;	
}

function product_list($name='',$archive=0) { global $user;
if($archive==0)
    $deleted=' AND tm_documents_mas.deleted=0 ';
else
    $deleted='';
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND pfm.project_id='".$user->project_active."' AND pfm.sheet_id='".$user->project_skill."' AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id NOT IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .= " AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}

function product_list_common($name='',$archive=0) { global $user;
if($archive==0)
    $deleted=' AND tm_documents_mas.deleted=0 ';
else
    $deleted='';
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .=" AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}



function recurse($folder_tree, $parent = null, $level = 0,$product_list= array(),$archive=0) {
    if($archive==0)
        $id='browser';
     else
        $id='browser-1';
    
	if($level == 0) {
		$ret = '<ul id="'.$id.'" class="filetree">';
	} else {
		$ret = '<ul>';
	}
    foreach($folder_tree as $index => $_tree)
    {
        if($_tree->folder_pararent_id == $parent)
        {
            $ret .= '<li><span class="folder">' . $_tree->folder_name . '</span></a>';
            if($_tree->ChildCount > 0)
                $ret .= recurse($folder_tree, $_tree->folder_id, $level+1,$product_list);
			 
			 $ret .= product($product_list,$_tree->folder_id);
            $ret .= '</li>';
        }
    }
    return $ret . '</ul>';
}

function product($product_list, $folder_id = '') {	
	 $plist = '';
	if(is_array($product_list[$folder_id]) && !empty($product_list[$folder_id])) {
		 $plist = '<ul id="folder'.$folder_id.'">';
		foreach($product_list[$folder_id] as $index => $_product)
		{
			if($_product->version_no==0)
                            $_product->version_no='1.0';
			$plist .= '<li><span class="file" doc_id="'.$_product->doc_id.'" unique_id="'.$_product->doc_path.'" exet="'.$_product->doc_ext.'">' . $_product->doc_name . ' - V '.$_product->version_no.'</span>';
			$plist .= '</li>';
			
		}
		 $plist .= '</ul>';
	}
    return $plist;
}

//************************************************************ List Folder *********************************************************/

function folder_tree_list($archive=0) {
    global $user;
  $deleted=' AND tm_folder_mas.deleted=0 ';
	$select_name="select tm_folder_mas.*, (select count(distinct c1.folder_id) from tm_folder_mas as c1   where c1.folder_pararent_id = tm_folder_mas.folder_id ) as ChildCount from tm_folder_mas WHERE 1 $deleted  AND status=1 order by folder_order";
	$_rset = cameo_query($select_name);
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[] = $row;
		}
	}
	return $rows;	
}

function product_list_list($name='',$archive=0) { global $user;
$deleted=' AND tm_documents_mas.deleted=0 ';
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND pfm.project_id='".$user->project_active."' AND pfm.sheet_id='".$user->project_skill."' AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id NOT IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .= " AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}

function product_list_common_list($name='',$archive=0) { global $user; 
    $deleted=' AND tm_documents_mas.deleted=0 '; 
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .=" AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}



function recurse_list($folder_tree, $parent = null, $level = 0,$product_list= array(),$archive=0) {
    if($archive==0)
        $id='browser';
     else
        $id='browser-1';
    
	if($level == 0) {
		$ret = '<ul id="'.$id.'" class="filetree">';
	} else {
		$ret = '<ul>';
	}
        $i=0;
    foreach($folder_tree as $index => $_tree)
    {
        if($_tree->folder_pararent_id == $parent)
        {
            $ret .= '<li   id="del_'.$_tree->folder_id.'" ><span class="folder">' . $_tree->folder_name . ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit/'.$_tree->folder_id.'"><img src='.base_path(). path_to_theme().'/images/edit_icon.png /></a> &nbsp;<a href="#" id="delete_'.$i.'_'.$_tree->folder_id.'" class="delete"><img src='.base_path(). path_to_theme().'/images/remove.jpeg /></a>';
			if($_tree->ChildCount > 0)
				$ret .= '&nbsp;<img src="'.base_path(). path_to_theme().'/images/sort.jpeg" class="im_g" style="cursor: pointer;"   onclick=$("#sortid").val('.$_tree->folder_id.') />';
			$ret .= '</span>';
            if($_tree->ChildCount > 0)
                $ret .= recurse_list($folder_tree, $_tree->folder_id, $level+1,$product_list);
			 
			 
            $ret .= '</li>';
        }
		$i++;
	}
    return $ret . '</ul>';
}

 
/********************************************** End List Folder******************************************************************/



/************************************************************ List Folder Document *********************************************************/


function folder_tree_document($archive=0) {
    global $user;    
    $deleted=' AND tm_folder_mas.deleted=0 ';
 
	$select_name="select tm_folder_mas.*, (select count(distinct c1.folder_id) from tm_folder_mas as c1   where c1.folder_pararent_id = tm_folder_mas.folder_id ) as ChildCount from tm_folder_mas WHERE 1 $deleted  AND status=1 order by folder_order";
	$_rset = cameo_query($select_name);
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[] = $row;
		}
	}
	return $rows;	
}

function product_list_document($name='',$archive=0) { global $user;
 
    $deleted=' AND tm_documents_mas.deleted=0 ';
 
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND pfm.project_id='".$user->project_active."' AND pfm.sheet_id='".$user->project_skill."'   AND tm_documents_mas.folder_id NOT IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .= "  GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}

function product_list_common_document($name='',$archive=0) { global $user;

    $deleted=' AND tm_documents_mas.deleted=0 ';

	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1    ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .="   GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}



function recurse_document($folder_tree, $parent = null, $level = 0,$product_list= array(),$archive=0) {
    if($archive==0)
        $id='browser';
     else
        $id='browser-1';
    
	if($level == 0) {
		$ret = '<ul id="'.$id.'" class="filetree">';
	} else {
		$ret = '<ul>';
	}
    foreach($folder_tree as $index => $_tree)
    {
        if($_tree->folder_pararent_id == $parent)
        {    
            $sort='';
            if(is_array($product_list[$_tree->folder_id]) && !empty($product_list[$_tree->folder_id])) 
             $sort='&nbsp;<img src="'.base_path(). path_to_theme().'/images/sort.jpeg" class="im_g" style="cursor: pointer;"   onclick=$("#sortid").val('.$_tree->folder_id.') />';
            
            $ret .= '<li><span class="folder">' . $_tree->folder_name . $sort.'</span>';
            if($_tree->ChildCount > 0)
                $ret .= recurse_document($folder_tree, $_tree->folder_id, $level+1,$product_list);
			 
			 $ret .= product_document($product_list,$_tree->folder_id);
                         
            $ret .= '</li>';
        }
    }
    return $ret . '</ul>';
}


function product_document($product_list, $folder_id = '') {	
	 $plist = '';
	if(is_array($product_list[$folder_id]) && !empty($product_list[$folder_id])) {
		 $plist = '<ul id="folder'.$folder_id.'">';
                 $i=0;
		foreach($product_list[$folder_id] as $index => $_product)
		{
			if($_product->version_no==0)
                            $_product->version_no='1.0';
			$plist .= '<li><span class="file" doc_id="'.$_product->doc_id.'" unique_id="'.$_product->doc_path.'" exet="'.$_product->doc_ext.'">' . $_product->doc_name . ' - V '.$_product->version_no.' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit/'.$_product->doc_id.'"><img src='.base_path(). path_to_theme().'/images/edit_icon.png /></a> &nbsp;<a href="#" id="delete_'.$i.'_'.$_product->doc_id.'" class="delete"><img src='.base_path(). path_to_theme().'/images/remove.jpeg /></a></span>';
			$plist .= '</li>';
		$i++;	
		}
		 $plist .= '</ul>';
	}
    return $plist;
}
/********************************************** End List Folder document******************************************************************/


function document_status($st){
    $status=array(
         "0"=>"Wating for Review",
        "1"=>"Approved By reviewer",
        "2"=>"Declined By reviewer",
        "3"=>"Approved By Approver",
        "4"=>"Declined By Approver"
    );
    return $status[$st];
}

function parseEmailListToArray($t) {   

    foreach($t as $k => $v) {
        if (strpos($v,',') !== false) {
            $t[$k] = '"'.str_replace(' <','" <',$v);
        }
    }

    foreach ($t as $addr) {
        if (strpos($addr, '<')) {
            preg_match('!(.*?)\s?<\s*(.*?)\s*>!', $addr, $matches);
			if (filter_var_custom($matches[2], FILTER_VALIDATE_EMAIL)) {
				$emails[] = array(
					'email' => $matches[2],
					'name' => $matches[1]
				);
			}
        } else {
			if (filter_var_custom($addr, FILTER_VALIDATE_EMAIL)) {
				$emails[] = array(
					'email' => $addr,
					'name' => ''
				);
			}
        }
    }

    return $emails;
} 

function filter_var_custom($email,$_filter='') {
	if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$email)) {
		return false;
	} else {
		return true;
	}
}

function mom_category_name($cat_id){
    $cat="SELECT  cat_name FROM mom_category Where cat_id=".$cat_id;
    $category = cameo_query($cat);
    $category_data = cameo_fetch_object($category);
    return $category_data->cat_name;
}

function check_cdm_person_mail($mailid){
    $sel_email="SELECT  usr.emp_id   
                FROM `tm_user_mas` usr  
                WHERE usr.status='1' ";
if(!empty($mailid)) {
	$sel_email .= " AND   usr.email_id like '%%%s%%'  ";
}
$techrs = cameo_query($sel_email, $mailid );
$aRow = cameo_fetch_object($techrs);
    return $aRow->emp_id; 
    
}
function insert_record($table_name,$input){
 
		$sql = " INSERT INTO ".$table_name." ( ";

		$number_col = count($input);
		$col = 0;

		foreach (array_keys($input) as $column_name){
			$col++;
			if ($col == $number_col)
				$sql .= $column_name;
			else $sql .= $column_name.',';
		}

		$sql .= ') VALUES(';

		$col = 0;
		foreach (array_values($input) as $column_values){
			$col++;
			$column_values = trim($column_values);
			if ($col == $number_col){
				$sql .= "'".addslashes($column_values)."'";
			}
			else{
				$sql .= "'".addslashes($column_values)."'".',';
			}
		}

		$sql .= ')';

		 
		if (cameo_query($sql)){
			return   mysql_insert_id();
			 
		}
		else{
			return false;
		}

	}
        
        
        
function update_record($table_name,$input,$where){
 
		$sql = " UPDATE  ".$table_name." SET  ";

		$number_col = count($input);
		$col = 0;

		foreach ($input as $column_name=>$column_values){
			$col++;
			if ($col == $number_col)
				$sql .= $column_name.'="'.mysql_real_escape_string($column_values).'"';
			else $sql .= $column_name.'="'.mysql_real_escape_string($column_values).'",';
		}

		$sql .= $where; 
		 //echo $sql;exit;
		if (cameo_query($sql)){
			return   true;
			 
		}
		else{
			return false;
		}

}

function delete_record($table_name,$where){
	$sql = " DELETE FROM  ".$table_name."   ";
	
	$sql .= $where; 
	//echo $sql;exit;
	if (cameo_query($sql)){
		return true;
	}
	else{
		return false;
	}
}

function getPriority() {
	$priority = array('P1'=>'P1', 'P2'=>'P2', 'P3'=>'P3', 'P4'=>'P4');
	return $priority;
}
function getMomStatus() {
	//$momstatus = array(0=>'OPEN', 1=>'ONGOING', 2=>'PENDING', 3=>'COMPLETED');
	$momstatus = array(0=>'OPEN',1=>'COMPLETED');
	return $momstatus;
}
function getPriorityColor() {
	//$priority_color = array('P1'=>'#FF0000; color:#FFFFFF', 'P2'=>'#ff7c26; color:#FFFFFF', 'P3'=>'#a8ff26', 'P4'=>'#008000; color:#FFFFFF');
	$priority_color = array('P1'=>'red', 'P2'=>'blue', 'P3'=>'purple', 'P4'=>'green');
	return $priority_color;
}

function getEncryptedPassword($plain_pwd) {		
	$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
	$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	$key = "isteam!@#";
	$ppwd = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $plain_pwd, MCRYPT_MODE_ECB, $iv);
	return $ppwd;		
}

function getEmpId() {
	$_start_emp_id = '2000000000';//2147483647
	$_max_emp_sql = 'SELECT MAX(emp_id) AS emp_id FROM tm_user_mas';
	$_result = cameo_query($_max_emp_sql);
	$_final_emp_id = '2000000000';
	if( cameo_num_rows($_result) > 0 ) {
		$_arr_emp = cameo_fetch_array($_result);
		if(!empty($_arr_emp['emp_id'])) {
			if($_arr_emp['emp_id'] < $_start_emp_id) {
				$_final_emp_id = $_start_emp_id;
			} else {
				$_final_emp_id = $_arr_emp['emp_id']+1;
			}
		}
	}
	return $_final_emp_id;
}


function email_to_userid($_email_lists_or_email) {
	$_email_lists = array();
	$_arr_user_ids = array();
	if( !is_array($_email_lists_or_email) ) {
		$_email_lists[] =  array(
									'email' => $_email_lists_or_email,
									'name' => $_email_lists_or_email
								);
	} else {
		$_email_lists = $_email_lists_or_email;
	}
	if(is_array($_email_lists) && !empty($_email_lists)) {
		foreach($_email_lists as $_list) {
			$_email  = strtolower(trim($_list['email']));
			if(!empty($_email) && filter_var_custom($_email) ) {
				$sel_email = "SELECT * FROM tm_user_mas WHERE LOWER(email_id) = '".$_email."'";
				$aResultRs = cameo_query($sel_email);
				if(cameo_num_rows($aResultRs) > 0 ) {
					/*
					* User Exists
					*/
					$aRow = cameo_fetch_object($aResultRs);
					$_arr_user_ids[$aRow->emp_id] = $aRow->emp_id;
				} else {
					/*
					* User Exists in CDM Check
					*/
					$cdm_sel_email = "SELECT * FROM tm_cdm_emp_mas WHERE LOWER(Office_Email) = '".$_email."'";
					$aCDMResultRs = cameo_query($cdm_sel_email);
					if(cameo_num_rows($aCDMResultRs) > 0 ) {
						/*
						* User Exists in CDM
						*/
						$aRow = cameo_fetch_array($aCDMResultRs);
						$info = array();
						$info['emp_id'] = $aRow['Emp_Code'];
						$info['name'] = $aRow['Emp_Name'];
						$info['email_id'] = $_email;
						$info['user_type'] = 1;
						$info['status'] = 1;
						$info['password'] = getEncryptedPassword('pass!23');
						//$db->insert('user', $info);	
					} else {
						/*
						* User NOT Exists in CDM
						*/
						$info = array();
						$info['emp_id'] = getEmpId();
						$info['name'] = $_email;
						$info['email_id'] = $_email;
						$info['user_type'] = 2;
						$info['status'] = 1;
						$info['password'] = getEncryptedPassword('pass!23');
					}
					/*
					* Insert into User table and fetch the user emp id for mapping
					*/
					if(!empty($info)) {
						$_user_id = insert_record('tm_user_mas',$info);
						//$userObj = new users();
						//$users_id = $userObj->insertUser($info);
						$_arr_user_ids[$info['emp_id']] = $info['emp_id'];
					}
					
				}
			}
		}
	}
	if(is_array($_arr_user_ids) && !empty($_arr_user_ids)) {
		return array_keys($_arr_user_ids);
	} else {
		return $_arr_user_ids;
	}
	
}

function getMOMInfo($event_id,$arr_filter_actions=array(),$_arr_fiter_comments=array()) {
	$event_details = array();
	$_status = getMomStatus();
	if(!empty($event_id)) {
		$sql = "SELECT * FROM `mom_tracker` WHERE event_id=".$event_id;
		$result = cameo_query($sql);
		if(cameo_num_rows($result) > 0) {
			$event_details["event_details"] = cameo_fetch_array($result);
		}
		$event_details["discussion"] = array();
		$event_details["action_item"] = array();
		$event_details["attachments"] = array();
		$_dis_sql = "SELECT * FROM mom_tracker_discussion_item WHERE event_id=".$event_id;
		$_dis_result = cameo_query($_dis_sql);
		if(cameo_num_rows($_dis_result) > 0) {
			while($diss_row = cameo_fetch_array($_dis_result)) {				
				$event_details["discussion"][] = $diss_row;
			}
		}
		$_act_sql = " SELECT act.*,usr.name as action_owner_name,usr.email_id as action_owner_email FROM mom_tracker_action_item act 
					  LEFT JOIN tm_user_mas as usr ON usr.emp_id = act.action_owner WHERE act.event_id=".$event_id;
		if(is_array($arr_filter_actions) && !empty($arr_filter_actions)) {
			$_act_sql .= " AND act.event_action_id IN(".implode(",",$arr_filter_actions).")";
		}		
		$_act_result = cameo_query($_act_sql);
		if(cameo_num_rows($_act_result) > 0) {
			while($act_row = cameo_fetch_array($_act_result)) {				
				$act_row['estimated_date'] = ' - ';
				if(!empty($act_row['estimated_time'])) {
					$act_row['estimated_date'] = date(DEFAULT_DATE_FORMAT,$act_row['estimated_time']);
				}
				$act_row['actual_closed_date_formated'] = ' - ';
				if(!empty($act_row['actual_completed_date'])) {
					$act_row['actual_closed_date_formated'] = date(DEFAULT_DATE_FORMAT,$act_row['actual_completed_date']);
				}
				$act_row['action_status_name'] = $_status[$act_row['action_status']];
				$event_details["action_item"][] = $act_row;
			}
		}
		$_attach_sql = "SELECT * FROM mom_attachments WHERE event_id=".$event_id;
		$_attach_result = cameo_query($_attach_sql);
		if(cameo_num_rows($_attach_result) > 0) {
			while($attach_row = cameo_fetch_array($_attach_result)) {				
				$event_details["attachments"][] = $attach_row;
			}
		}
		$_comments_sql='Select ic.*,tum.name from mom_tracker_action_item_comments ic
                  LEFT JOIN tm_user_mas tum ON ic.created_by = tum.emp_id  
                  where ic.event_id=%d ';
		if(is_array($_arr_fiter_comments) && !empty($_arr_fiter_comments)) {
			$_comments_sql .= " AND ic.event_action_item IN(".implode(",",$_arr_fiter_comments).")";
		}
		$_comments_sql .=' ORDER BY ic.id asc';
		$_comments_event=cameo_query($_comments_sql,$event_id);
		while($_row_comment =cameo_fetch_array($_comments_event)){			
			$_row_comment['estimated_date'] = '';
			if(!empty($_row_comment['estimated_time'])) {
				$_row_comment['estimated_date'] = date(DEFAULT_DATE_FORMAT,$_row_comment['estimated_time']);
			}
			$_row_comment['actual_completed_date_formated'] = '';
			if(!empty($_row_comment['actual_completed_date'])) {
				$_row_comment['actual_completed_date_formated'] = date(DEFAULT_DATE_FORMAT,$_row_comment['actual_completed_date']);
			}
			$_row_comment['created_on_formated'] = '';
			if(!empty($_row_comment['created_on'])) {
				$_row_comment['created_on_formated'] = date(DEFAULT_DATE_FORMAT,$_row_comment['created_on']);
			}			
			$_row_comment['action_status_name'] = $_status[$_row_comment['action_status']];
			$event_details["action_comments"][] = $_row_comment;
		}
	}
	return $event_details;
}

function event_comments($_eventid) {
	$comments = array();
	$_comments_sql='Select ic.*,tum.name from mom_tracker_action_item_comments ic
			  LEFT JOIN tm_user_mas tum ON ic.created_by = tum.emp_id  
			  where ic.event_id=%d ORDER BY ic.id asc';     
	$_comments_event=cameo_query($_comments_sql,$_eventid);
	while($_row_comment =cameo_fetch_array($_comments_event)){			
		$_row_comment['estimated_date'] = '';
		if(!empty($_row_comment['estimated_time'])) {
			$_row_comment['estimated_date'] = date(DEFAULT_DATE_FORMAT,$_row_comment['estimated_time']);
		}
		$_row_comment['actual_completed_date_formated'] = '';
		if(!empty($_row_comment['actual_completed_date'])) {
			$_row_comment['actual_completed_date_formated'] = date(DEFAULT_DATE_FORMAT,$_row_comment['actual_completed_date']);
		}
		$_row_comment['created_on_formated'] = '';
		if(!empty($_row_comment['created_on'])) {
			$_row_comment['created_on_formated'] = date(DEFAULT_DATE_FORMAT,$_row_comment['created_on']);
		}			
		$_row_comment['action_status_name'] = $_status[$_row_comment['action_status']];
		$comments[] = $_row_comment;
	}
}

function getEmailAndName($_emp_ids) {
	$_emp_id_str = '';
	if( is_array($_emp_ids) && !empty($_emp_ids)) {
		$_emp_id_str = implode(",",$_emp_ids);
	} else {
		$_emp_id_str = $_emp_ids;
	}
	$_arr_user = array();
	if(!empty($_emp_id_str)) {
		$_emp_name_sql='Select emp_id,email_id,name from tm_user_mas tum 
					  where tum.emp_id IN('.$_emp_id_str.')';     
		$_emp_name_rs=cameo_query($_emp_name_sql);		
		while($_row_user=cameo_fetch_object($_emp_name_rs)){
			$_arr_user[$_row_user->emp_id] =array('id'=>$_row_user->email_id,'name'=>$_row_user->name);
		}
	}
	return $_arr_user;
}


function getEmailTemplate1($id) {
	$emailTemplate = array() ;
	$emailTemplate[1] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>[momtitle]</title>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
.table_head	{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #34495E;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:5px;
}
.table_head_row{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #16A085;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:0px;
}
.table_css{
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 12px;
font-weight: normal;
color: #000000;
text-decoration: none;
}
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" >
  <tr>
    <td><table width="100%" class="table_css">
        <tr>
          <td><img src="[logo]" /><br>
            <br></td>
        </tr>
        <tr>
          <td><p>Hi [username],</p>
            <p>You have been assigned the following action items from a meeting. The details have been provided below. Click <a href="https://qmg.csscorp.com/">here</a> to update the status and comments.<br>
              <br>
            </p></td>
        </tr>
        <tr>
          <td><B>Meeting Title: [momtitle]</B></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head">AGENDA:</td>
        </tr>
        <tr>
          <td>[momagenda]</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head"> ACTION ITEM(S): </td>
        </tr>
        <tr>
          <td><table width="100%" border="0" class="tableborder_grey">
              <tr class="table_head_row">
                <td align="center"><strong>S.No</strong></td>
                <td align="center"><strong>Action Item </strong></td>
                <td align="center"><strong>Owner</strong></td>
                <td align="center"><strong>Priority</strong></td>
                <td align="center"><strong>Due Date </strong></td>
                <td align="center"><strong>Comments</strong></td>
              </tr>
			  [actionitemlists]               
            </table></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Click <a href="https://qmg.csscorp.com/">here</a> to access the QMG MOM Manager tool.</td>
        </tr>
        <tr>
          <td><br>
            Regards ,<br>
            [momsignature].</td>
        </tr>
        <tr>
          <td><br>
            <i>Note: This is auto generated mail from the QMG MOM Manager application. Please do-not reply to this mail.</i></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>';
$emailTemplate[2] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>[momtitle]</title>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
.table_head	{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #34495E;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:5px;
}
.table_head_row{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #16A085;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:0px;
}
.table_css{
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 12px;
font-weight: normal;
color: #000000;
text-decoration: none;
}
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" >
  <tr>
    <td><table width="100%" class="table_css">
        <tr>
          <td><img src="[logo]" /><br>
            <br></td>
        </tr>
        <tr>
          <td>Hi [username],<br>
            <br></td>
        </tr>
        <tr>
          <td><B>Meeting Title: [momtitle]</B></td>
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr>
          <td valign="top">[mominvitedetails]</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head">AGENDA:</td>
        </tr>
        <tr>
          <td>[momagenda]</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
		[momadisscusseditem]        
        <tr>
          <td>&nbsp;</td>
        </tr>
        [actionitemlists]
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Click <a href="https://qmg.csscorp.com/">here</a> to access the QMG MOM Manager tool.</td>
        </tr>
        <tr>
          <td><br>
            Regards ,<br>
            [momsignature].</td>
        </tr>
        <tr>
          <td><br>
            <i>Note: This is auto generated mail from the QMG MOM Manager application. Please do-not reply to this mail.</i></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>';
$emailTemplate[3] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>[momtitle]</title>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
.table_head	{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #34495E;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:5px;
}
.table_head_row{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #16A085;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:0px;
}
.table_css{
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 12px;
font-weight: normal;
color: #000000;
text-decoration: none;
}
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" >
  <tr>
    <td><table width="100%" class="table_css">
        <tr>
          <td><img src="[logo]" /><br>
            <br></td>
        </tr>
        <tr>
          <td>Hi [username],<br>
            <br></td>
        </tr>
        <tr>
         <td>This is to intimate you on the pending action item for the below meeting. </td>
        </tr>
        <tr>
          <td><B>Meeting Title: [momtitle]</B></td>
        </tr>
        <tr>
          <td></td>
        </tr>
       
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head">AGENDA:</td>
        </tr>
        <tr>
          <td>[momagenda]</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head"> ACTION ITEM(S): </td>
        </tr>
        <tr>
          <td>[actionitemlists]</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Click <a href="https://qmg.csscorp.com/">here</a> to access the QMG MOM Manager tool.</td>
        </tr>
        <tr>
          <td><br>
            Regards ,<br>
            [momsignature].</td>
        </tr>
        <tr>
          <td><br>
            <i>Note: This is auto generated mail from the QMG MOM Manager application. Please do-not reply to this mail.</i></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>';
$emailTemplate[4] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>[momtitle]</title>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
.table_head	{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #34495E;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:5px;
}
.table_head_row{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #16A085;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:0px;
}
.table_css{
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 12px;
font-weight: normal;
color: #000000;
text-decoration: none;
}
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" >
  <tr>
    <td><table width="100%" class="table_css">
        <tr>
          <td><img src="[logo]" /><br>
            <br></td>
        </tr>
        <tr>
          <td>Hi [username],<br>
            <br></td>
        </tr>
        <tr>
         <td>This is to initimate you on your reportees pending action item for the below meeting.  </td>
        </tr>
        <tr>
          <td><B>Meeting Title: [momtitle]</B></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head">AGENDA:</td>
        </tr>
        <tr>
          <td>[momagenda]</td>
        </tr>
        
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td class="table_head"> ACTION ITEM(S): </td>
        </tr>
        <tr>
          <td>[actionitemlists]</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Click <a href="https://qmg.csscorp.com/">here</a> to access the QMG MOM Manager tool.</td>
        </tr>
        <tr>
          <td><br>
            Regards ,<br>
            [momsignature].</td>
        </tr>
        <tr>
          <td><br>
            <i>Note: This is auto generated mail from the QMG MOM Manager application. Please do-not reply to this mail.</i></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>';

$emailTemplate[5] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>[momtitle]</title>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
.table_head	{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #34495E;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:5px;
}
.table_head_row{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #16A085;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:0px;
}
.table_css{
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 12px;
font-weight: normal;
color: #000000;
text-decoration: none;
}
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" >
  <tr>
    <td><table width="100%" class="table_css">
        <tr>
          <td><img src="[logo]" /><br>
            <br></td>
        </tr>
        <tr>
          <td>Hi [username],<br>
            <br></td>
        </tr>
        <tr>
         <td>This is to intimate you on the pending action item for the below meeting. </td>
        </tr>
        [chained_action_items]
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Click <a href="https://qmg.csscorp.com/">here</a> to access the QMG MOM Manager tool.</td>
        </tr>
        <tr>
          <td><br>
            Regards ,<br>
            [momsignature].</td>
        </tr>
        <tr>
          <td><br>
            <i>Note: This is auto generated mail from the QMG MOM Manager application. Please do-not reply to this mail.</i></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>';

$emailTemplate[6] = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>[momtitle]</title>
<style>
.tableborder_grey{
border-style:solid;
border-width: 1px;
border-color: #CCCCCC;
}
.table_head	{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #34495E;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:5px;
}
.table_head_row{
font-family		: Verdana, Arial, Helvetica, sans-serif;
font-size		: 11px;
color			: #FFFFFF;
padding			: 1px ;
background-color: #16A085;
font-weight		: bold;
white-space: nowrap;
text-align: left;
vertical-align:middle;
padding:0px;
}
.table_css{
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 12px;
font-weight: normal;
color: #000000;
text-decoration: none;
}
</style>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" >
  <tr>
    <td><table width="100%" class="table_css">
        <tr>
          <td><img src="[logo]" /><br>
            <br></td>
        </tr>
        <tr>
          <td>Hi [username],<br>
            <br></td>
        </tr>
        <tr>
         <td>This is to initimate you on your reportees pending action item for the below meeting.  </td>
        </tr>
		<tr>
          <td>&nbsp;</td>
        </tr>        
        <tr>
          <td class="table_head"> ACTION ITEM(S): </td>
        </tr>
		<tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>[actionitemlists]</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Click <a href="https://qmg.csscorp.com/">here</a> to access the QMG MOM Manager tool.</td>
        </tr>
        <tr>
          <td><br>
            Regards ,<br>
            [momsignature].</td>
        </tr>
        <tr>
          <td><br>
            <i>Note: This is auto generated mail from the QMG MOM Manager application. Please do-not reply to this mail.</i></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>';
return $emailTemplate[$id];
}

function _mailsend($_subject='',$_body_html='',$_plain_txt='',$_arr_from=array(),$_arr_to=array(),$_arr_cc=array(),$_arr_bcc=array(),$_attachment=array(),$_options,$_ical='') {
	require_once './misc/Swift/swift_required.php';
	//$mailer_transport_setup = Swift_SmtpTransport::newInstance('10.8.16.56', 25)
	//	  ->setUsername('roxio.csat2@intra.csscorp.com')
	//	  ->setPassword('R@x!t+23')
	//	  ;
	try {
	
		if(empty($_arr_from)) {
			$_arr_from =array();
			$_arr_from[MOM_FROM_EMAIL] = MOM_FROM_NAME;
		}
		if(empty($_arr_bcc)) {
			$_arr_bcc =array();
			$_arr_bcc['mahesh.mahendran@csscorp.com'] = 'Mahesh Mahendran';
		}
		$mailer_transport_setup = Swift_SendmailTransport::newInstance('/usr/sbin/sendmail -t -i'); 
		$mailer  = Swift_Mailer::newInstance($mailer_transport_setup);
		$message = Swift_Message::newInstance($_subject)
				  ->setFrom($_arr_from)
				  ->setTo($_arr_to)
				  ->setBody($_body_html, 'text/html');
		if(!empty($_arr_cc)) {
			$message->setCc($_arr_cc);
		}
		if(!empty($_arr_bcc)) {
			$message->setBcc($_arr_bcc);
		}
		if(!empty($_plain_txt))
			$message->addPart($_plain_txt, 'text/plain');
		if(!empty($_ical))
			$message->addPart($_ical,'text/calendar');
		$result = $mailer->send($message, $failures);
		//echo '<pre>';
		//var_dump($failures);
		if(empty($failures)) {
			return true;
		} else {
			return $failures;
		}
	} catch(\Swift_TransportException $e){
        $response = $e->getMessage() ;
    }
}

function sendInviteAndAlert($event_id,$_cal_action='create',$ical=true,$invite=true,$action=true) {	
	$_arr_event = getMOMInfo($event_id);	
	if(!empty($_arr_event)) {
		$_spoc = getEmailAndName($_arr_event['event_details']['spoc']);
		$_spoc_help = getEmailAndName($_arr_event['event_details']['spoc_help']);
		$_internal_invites_sent = getEmailAndName($_arr_event['event_details']['internal_invites_sent']);
		$_internal_invites_present = getEmailAndName($_arr_event['event_details']['internal_present']);
		$_internal_invites_absent = getEmailAndName($_arr_event['event_details']['internal_absent']);
		$invited = explode(",",$_arr_event['event_details']['internal_invites_sent']);
		$_arr_present_final = explode(",",$_arr_event['event_details']['internal_present']);
		$_arr_absent_final = explode(",",$_arr_event['event_details']['internal_absent']);
		$iCalString = '';
		if($ical) {
			/*
			* Prepare ical and send mail
			*/			
			/*$tz = $_arr_event['event_details']['event_timezone']; 
			if(empty($tz)) {
				$tz = 'Asia/Kolkatta';
			}
			$config = array( "unique_id" => "qmg.csscorp.com",// set Your unique id, // required if any component UID is missing
							  "TZID"      => $tz );  
			$v = new vcalendar( $config );                             // create a new calendar object instance
			$v->setProperty( "method", "PUBLISH" );                    // required of some calendar software
			//$v->setProperty( "x-wr-calname", "QMG Mom Manager" );      // required of some calendar software
			//$v->setProperty( "X-WR-CALDESC", "QMG Mom Manager - The Event Note Taker" ); // required of some calendar software
			//$v->setProperty( "X-WR-TIMEZONE", $tz );                   // required of some calendar software

			$xprops = array( "X-LIC-LOCATION" => $tz );                // required of some calendar software
			iCalUtilityFunctions::createTimezone( $v, $tz, $xprops );  // create timezone component(-s) 
			$vevent = & $v->newComponent( "vevent" );                  // create an event calendar component
			
			$vevent->setProperty( "dtstart", array( "year"  => date('Y',$_arr_event['event_details']['event_start_time'])
											  , "month" => date('m',$_arr_event['event_details']['event_start_time'])
											  , "day"   => date('d',$_arr_event['event_details']['event_start_time'])
											  , "hour"  => date('H',$_arr_event['event_details']['event_start_time'])
											  , "min"   => date('i',$_arr_event['event_details']['event_start_time'])
											  , "sec"   => date('s',$_arr_event['event_details']['event_start_time']) ));
			$vevent->setProperty( "dtend",   array( "year"  => date('Y',$_arr_event['event_details']['event_end_time'])
											  , "month" => date('m',$_arr_event['event_details']['event_end_time'])
											  , "day"   => date('d',$_arr_event['event_details']['event_end_time'])
											  , "hour"  => date('H',$_arr_event['event_details']['event_end_time'])
											  , "min"   => date('i',$_arr_event['event_details']['event_end_time'])
											  , "sec"   => date('s',$_arr_event['event_details']['event_end_time']) ));
			
			$vevent->setProperty( "LOCATION", $_arr_event['event_details']['location'] ); 
			$vevent->setProperty( "summary", $_arr_event['event_details']['title'] );	
			$vevent->setProperty( "description", $_arr_event['event_details']['agenda'] );
			$vevent->setProperty( "comment", $_arr_event['event_details']['agenda'] );	
			$vevent->setProperty( "organizer" , $_spoc[$_arr_event['event_details']['spoc']]['id'], array( "CN" => $_spoc[$_arr_event['event_details']['spoc']]['name']));
			
			$_arr_invite_list = array();
			if(!empty($invited)) {
				foreach($invited as $emp_id) {								
					$vevent->setProperty( "attendee", $_internal_invites_sent[$emp_id]['id'] , array("cutype" => "INDIVIDUAL" , "CN" => $_internal_invites_sent[$emp_id]['name'], "PARTSTAT" => "ACCEPTED" , "RSVP" => "TRUE"));
				}
			}
			$valarm = & $vevent->newComponent( "valarm" );             // create an event alarm
			$valarm->setProperty("action", "DISPLAY" );
			$valarm->setProperty("description", $vevent->getProperty( "description" ));
			$d = sprintf( '%04d%02d%02d %02d%02d%02d', date('Y',$_arr_event['event_details']['event_start_time']), date('m',$_arr_event['event_details']['event_start_time']), date('d',$_arr_event['event_details']['event_start_time']), 15, 0, 0 );
			iCalUtilityFunctions::transformDateTime( $d, $tz, "UTC", "Ymd\THis\Z");
			$valarm->setProperty( "trigger", $d );
			$iCalString = $v->createCalendar();*/
		if(empty($_arr_event['event_details']['event_timezone'])) {
			$_arr_event['event_details']['event_timezone'] = 'Asia/Kolkata';
		}
		$reminder_time = '10M';
		$reminder_chk = true;
		
		$_cal_starttime = $_arr_event['event_details']['event_start_time'];
		$_cal_endtime = $_arr_event['event_details']['event_end_time'];
		$domain = '-'.'csscorp.com';
		$event_start = new DateTime("@$_cal_starttime", new DateTimeZone($_arr_event['event_details']['event_timezone']));
		$event_start->setTimezone(new DateTimeZone('America/Los_Angeles'));
		$cal_event_start = $event_start->format('Y-m-d H:i:s');
		$event_end = new DateTime("@$_cal_endtime", new DateTimeZone($_arr_event['event_details']['event_timezone']));
		$event_end->setTimezone(new DateTimeZone('America/Los_Angeles'));
		$cal_event_end = $event_end->format('Y-m-d H:i:s');
		/*if (date('H:i:s', strtotime($cal_event_start)) == '00:00:00') {
			$dtstart = (string) gmdate('Ymd', strtotime($cal_event_start));
		} else {
			$dtstart = (string) gmdate('Ymd\THi00\Z', strtotime($cal_event_start));
		}
		if (date('H:i:s', strtotime($cal_event_end)) == '00:00:00') {
			$dtend = (string) gmdate('Ymd', strtotime($cal_event_end));
		} else {
			$dtend = (string) gmdate('Ymd\THi00\Z', strtotime($cal_event_end));
		}*/
		$dtstart = (string) $event_start->format('Ymd\THi00');
		$dtend = (string) $event_end->format('Ymd\THi00');
		$tz = new DateTimeZone($_arr_event['event_details']['event_timezone']);
		$nowTz = new DateTime("now", $tz);
		$offset = $nowTz->getOffset();
		$offsetHours = round(abs($offset)/3600);
		$offsetMinutes = round((abs($offset) - $offsetHours * 3600) / 60);
		if($offsetMinutes < 0) {
			$offsetHours = $offsetHours - 1;
			$offsetMinutes = 60 - ($offsetMinutes * -1);
		}
		$offsetString = ($offset < 0 ? '-' : '+')
                . ($offsetHours < 10 ? '0' : '') . $offsetHours               
                . ($offsetMinutes < 10 ? '0' : '') . $offsetMinutes;
		$dtstamp = (string) gmdate('Ymd\THis', time());//'20130926T094359Z';
		//$created = $this->cal_event_created;
		//$last_modified = $this->cal_event_modified;			
		$created = (string) gmdate('Ymd\THis', time());
		$last_modified = (string) gmdate('Ymd\THis', time());
		$uid = date('Ymd').'T'.date('His')."-".rand().$domain;
		$_arr_timezone_name = getTimeZones2($_arr_event['event_details']['event_timezone']);
		if(!empty($_arr_timezone_name)) {
			if(!empty($_arr_timezone_name[3])) {
				$timezone = $_arr_timezone_name[3];
			} else {
				$timezone = $_arr_event['event_details']['event_timezone'];
			}
		} else {
			$timezone = "India Standard Time";//$_arr_event['event_details']['event_timezone'];
		}
		$cal_subject = $_arr_event['event_details']['title'];
		$cal_location = $_arr_event['event_details']['location'];
		if(isset($_arr_event["event_details"]['uid']) && !empty($_arr_event["event_details"]['uid'])) {
			$uid = $_arr_event["event_details"]['uid'];
		}
		if(isset($_arr_event["event_details"]['sequence']) && !empty($_arr_event["event_details"]['sequence'])) {
			$cal_sequence = $_arr_event["event_details"]['sequence']+1;
		} else {
			$cal_sequence = 0;
		}
		if($cal_sequence == 0) {			
			$_update_uid_sql = "update mom_tracker SET uid='%s', sequence=%d WHERE event_id=%d";
			cameo_query($_update_uid_sql,$uid,$cal_sequence,$_arr_event['event_details']['event_id']);
		} else {
			$_update_uid_sql = "update mom_tracker SET sequence=%d WHERE event_id=%d";
			cameo_query($_update_uid_sql,$cal_sequence,$_arr_event['event_details']['event_id']);
		}
		/*if(!empty($this->reminder_time)) 
			$reminder_time = $this->reminder_time;
		else*/
		   
		//ATTENDEE;CN="Mahesh Mahendran";RSVP=TRUE:mailto:mahesh.mahendran@csscorp.com\n
		//ORGANIZER;CN="Vijay Durairaj":mailto:vijay.durairaj@csscorp.com\n
		//STATUS:CANCELLED
		$STATUS = '';
		$ORGANIZER ='';
		$ATTENDEE = '';		
		$ALARM = '';
		$ALARM =<<<ICALALARM
BEGIN:VALARM\n
ACTION:DISPLAY\n
DESCRIPTION:REMINDER\n
TRIGGER;RELATED=START:-PT$reminder_time\n
END:VALARM\n
ICALALARM;
		if(!$reminder_chk) $ALARM = '';
		if(empty($_cal_action)) {
			$action_event = 'create';
		} else {
			$action_event = $_cal_action;
		}
		if($action_event == 'create') {
			$method = 'REQUEST';
			//$last_modified = $created;
			$STATUS = 'STATUS:CONFIRMED'.CRLF;
			$busy_status = 'TENTATIVE';
			$intended_status = 'BUSY';
			$summary_cancel = '';
		} elseif($action_event == 'update') {
			$method = 'REQUEST';
			$STATUS = 'STATUS:CONFIRMED'.CRLF;
			//$cal_sequence = $cal_sequence + 1;
			$busy_status = 'TENTATIVE';
			$intended_status = 'BUSY';
			$summary_cancel = '';
		} elseif($action_event == 'delete') {
			$ALARM = '';
			$method = 'CANCEL';
			$STATUS = 'STATUS:CANCELLED'.CRLF;
			$busy_status = 'FREE';
			$intended_status = 'FREE';
			$summary_cancel = ':Canceled';
		} else {
			//create
			$method = 'REQUEST';
			$STATUS = 'STATUS:CONFIRMED'.CRLF;
			$busy_status = 'TENTATIVE';
			$intended_status = 'BUSY';
			$summary_cancel = '';
		}
				
		$ORGANIZER = 'ORGANIZER;CN="'.$_spoc[$_arr_event['event_details']['spoc']]['name'].'":MAILTO:'.trim($_spoc[$_arr_event['event_details']['spoc']]['id'])."\n";
		if(!empty($invited)) {
			foreach($invited as $emp_id) {
				$ATTENDEE .= 'ATTENDEE;CN="'.$_internal_invites_sent[$emp_id]['name'].'";RSVP=TRUE:MAILTO:'.trim($_internal_invites_sent[$emp_id]['id']);//.CRLF;
			}
        }
		/*if (count($this->cc) > 0) {
            foreach($this->cc as $_arr_cc) {
				$ATTENDEE .= 'ATTENDEE;CN="'.$_arr_cc[1].'";ROLE=OPT-PARTICIPANT;RSVP=TRUE:MAILTO:'.trim($_arr_cc[0]).self::CRLF;
			}
        }*/
		
		$iCalString = <<<ICALSESSION
BEGIN:VCALENDAR\n
METHOD:$method\n
PRODID:-//Microsoft Corporation//Outlook 15.0 MIMEDIR//EN\n
VERSION:2.0\n
BEGIN:VTIMEZONE\n
TZID:$timezone\n
BEGIN:STANDARD\n
DTSTART:16010101T000000\n
TZOFFSETFROM:$offsetString\n
TZOFFSETTO:$offsetString\n
END:STANDARD\n
BEGIN:DAYLIGHT\n
DTSTART:16010101T000000\n
TZOFFSETFROM:$offsetString\n
TZOFFSETTO:$offsetString\n
END:DAYLIGHT\n
END:VTIMEZONE\n
BEGIN:VEVENT\n
$ORGANIZER
$ATTENDEE
DESCRIPTION:\n
SUMMARY;LANGUAGE=en-us$summary_cancel:$cal_subject\n
DTSTART;TZID="$timezone":$dtstart\n
DTEND;TZID="$timezone":$dtend\n
UID:$uid\n
CLASS:PUBLIC\n
PRIORITY:5\n
DTSTAMP:$dtstamp\n
TRANSP:OPAQUE\n
$STATUS
SEQUENCE:$cal_sequence\n
LOCATION;LANGUAGE=en-US:$cal_location\n
X-MICROSOFT-CDO-APPT-SEQUENCE:$cal_sequence\n
X-MICROSOFT-CDO-BUSYSTATUS:$busy_status\n
X-MICROSOFT-CDO-INTENDEDSTATUS:$intended_status\n
X-MICROSOFT-CDO-ALLDAYEVENT:FALSE\n
X-MICROSOFT-CDO-IMPORTANCE:1\n
X-MICROSOFT-CDO-INSTTYPE:0\n
X-MICROSOFT-DISALLOW-COUNTER:FALSE\n
$ALARM
END:VEVENT\n
END:VCALENDAR\n
ICALSESSION;
		}		
		if($invite) {
			$_template = getEmailTemplate1(2);
			$_mom_start_end_duration = '';
			if(strtotime(date("Y-m-d",$_arr_event['event_details']['event_start_time'])) != strtotime(date("Y-m-d",$_arr_event['event_details']['event_end_time']))) {
				$_mom_start_end_duration = date(DEFAULT_DATE_FORMAT,$_arr_event['event_details']['event_start_time']).' - ' . date(DEFAULT_DATE_FORMAT,$_arr_event['event_details']['event_end_time']) .' - '.date(DEFAULT_DATE_FORMAT_TIME,$_arr_event['event_details']['event_start_time']).' - ' . date(DEFAULT_DATE_FORMAT_TIME,$_arr_event['event_details']['event_end_time']);
			} else {
				$_mom_start_end_duration = date(DEFAULT_DATE_FORMAT,$_arr_event['event_details']['event_start_time']).' - '.date(DEFAULT_DATE_FORMAT_TIME,$_arr_event['event_details']['event_start_time']).' - ' . date(DEFAULT_DATE_FORMAT_TIME,$_arr_event['event_details']['event_end_time']);
			}
			$_f_invite_names = array();
			if(!empty($invited)) {
				foreach($invited as $emp_id) {
					$_f_invite_names[] = $_internal_invites_sent[$emp_id]['name'];
				}
			}
			$_f_present_names = array();
			if(!empty($_arr_present_final)) {
				foreach($_arr_present_final as $_tpresent) {
					$_f_present_names[] = $_internal_invites_present[$_tpresent]['name'];
				}
			}
			$_f_absent_names = array();
			if(!empty($_arr_absent_final)) {
				foreach($_arr_absent_final as $_tabsent) {
					$_f_absent_names[] = $_internal_invites_absent[$_tabsent]['name'];
				}
			}
			$_project_name_fn = get_project_name($_arr_event['event_details']['project_id']);
			$_category_name_fn = mom_category_name($_arr_event['event_details']['category_id']);
			$_project_name = (!empty($_project_name_fn))?$_project_name_fn:'NA';
			$_category_name = (!empty($_category_name_fn))?$_category_name_fn:'NA';
			$_invite_details = '<table width="100%" border="0" class="table_css">
				  <tr>
					<td width="15%"><strong>Organizer</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td width="37%">'.$_spoc[$_arr_event['event_details']['spoc']]['name'].'</td>
				  </tr>
				  <tr>
					<td width="15%"><strong>Invitee(s)</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td>'.implode(",",$_f_invite_names).'</td>
				  </tr>
				  <tr>
					<td width="15%"><strong>Attendee(s)</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td>'.implode(",",$_f_present_names).'</td>
				  </tr>
				  <tr>
					<td width="15%"><strong>Location</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td>'.$_arr_event['event_details']['location'].'</td>
				  </tr>
				  <tr>
					<td width="15%"><strong>Date &amp; Time</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td>'.$_mom_start_end_duration.'</td>
				  </tr>
				  <tr>
					<td width="15%"><strong>Department</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td>'.$_project_name.'</td>
				  </tr>
				  <tr>
					<td width="15%"><strong>Category</strong></td>
					<td width="2%" align="center"><strong>:</strong></td>
					<td>'.$_category_name.'</td>
				  </tr>
				</table>';
			if(count($_arr_event['discussion'])	 > 0) {
				$_discussed_details = '<tr>
					  <td class="table_head">DISCUSSION ITEM(S):</td>
					</tr>
					<tr>
					  <td>';
				$_discussed_details .= '<table width="100%" border="0" >';
				$i =1;
				foreach($_arr_event['discussion'] as $key=>$discuss) {
					if(!empty($discuss['discuss_item'])) {
					$_discussed_details .= '<tr>
						<td width="3%" align="center" valign="top">'.$i.'.</td>
						<td width="262" align="left">'.$discuss['discuss_item'].'</td>
					  </tr>';
					}
					$i++;
				}
				$_discussed_details .= '</table>';
				$_discussed_details .= '</td></tr>';
			}
			if(count($_arr_event['action_item']) > 0 ) {
				$_actioned_item_details = '<tr>
				  <td class="table_head"> ACTION ITEM(S): </td>
				</tr>
				<tr>
				  <td>';
				$_actioned_item_details .= '<table width="100%" border="0" class="tableborder_grey">
					  <tr class="table_head_row">
						<td align="center"><strong>S.No</strong></td>
						<td align="center"><strong>Action Item </strong></td>
						<td align="center"><strong>Owner</strong></td>
						<td align="center"><strong>Priority</strong></td>
						<td align="center"><strong>Due Date </strong></td>
						<td align="center"><strong>Comments</strong></td>
					  </tr>';
				if(is_array($_arr_event['action_item']) && !empty($_arr_event['action_item'])) {
					$i = 1;
					foreach($_arr_event['action_item'] as $key=>$item) {					
						$action_owner_details = getEmailAndName($item['action_owner']);					
						$_actioned_item_details .= '<tr>
											<td width="3%" align="center" valign="top">'.$i.'</td>
											<td>'.$item['action_item'].'</td>
											<td align="center" valign="top">'.$action_owner_details[$item['action_owner']]['name'].'</td>
											<td align="center" valign="top">'.$item['priority'].'</td>
											<td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$item['estimated_time']).'</td>
											<td align="left" valign="top">'.$item['comment'].'</td>
										</tr> ';//$user[$item['action_owner']]
						$i++;
					}
				}	
				$_actioned_item_details .= '</table>';
				$_actioned_item_details .= '</td></tr>';
			}
			$sitelogo = base_url().'/logos/css_logo.png';
			$project_logo = '';
			/*if(!empty($logo[$momInfo['project_id']]) && file_exists($site_url.'logos/'.$logo[$momInfo['project_id']])) {
				$project_logo = $site_url.'logos/'.$logo[$momInfo['project_id']];
			}*/			
			if(!empty($invited)) {
				foreach($invited as $emp_id) {				
					$_name = $_internal_invites_sent[$emp_id]['name'];
					$_email = $_internal_invites_sent[$emp_id]['id'];
					$search= array('[username]','[momtitle]','[momagenda]','[mominvitedetails]','[momadisscusseditem]','[actionitemlists]','[logo]','[project_logo]','[momsignature]');
					$replace= array($_name,ucfirst($_arr_event['event_details']['title']),$_arr_event['event_details']['agenda'],$_invite_details,$_discussed_details,$_actioned_item_details,$sitelogo,$project_logo,MOM_SIGNATURE);
					$content = str_replace($search,$replace,$_template);	
					$_arr_from = array();				
					$_arr_from[$_spoc[$_arr_event['event_details']['spoc']]['id']] =  $_spoc[$_arr_event['event_details']['spoc']]['name'];
					$_to = array();
					$_to[trim($_email)] = $_name;
					$_options = array();					
					if(!empty($iCalString)) {
						_mailsend($_arr_event['event_details']['title'],$content,$_arr_event['event_details']['title'],$_arr_from,$_to,array(),array(),array(),$_options,$iCalString);
					} else {
						_mailsend($_arr_event['event_details']['title'],$content,$_arr_event['event_details']['title'],$_arr_from,$_to,array(),array(),array(),$_options);
					}
				}
				/*
				* Alert the same to organizer
				*/
				if(isset($_spoc) && !empty($_spoc)) {
					$_name = $_spoc[$_arr_event['event_details']['spoc']]['name'];
					$_email = $_spoc[$_arr_event['event_details']['spoc']]['id'];
					$search= array('[username]','[momtitle]','[momagenda]','[mominvitedetails]','[momadisscusseditem]','[actionitemlists]','[logo]','[project_logo]','[momsignature]');
					$replace= array($_name,ucfirst($_arr_event['event_details']['title']),$_arr_event['event_details']['agenda'],$_invite_details,$_discussed_details,$_actioned_item_details,$sitelogo,$project_logo,MOM_SIGNATURE);
					$content = str_replace($search,$replace,$_template);	
					$_arr_from = array();				
					$_arr_from[$_spoc[$_arr_event['event_details']['spoc']]['id']] =  $_spoc[$_arr_event['event_details']['spoc']]['name'];
					$_to = array();
					$_to[trim($_email)] = $_name;
					$_options = array();					
					if(!empty($iCalString)) {
						_mailsend($_arr_event['event_details']['title'],$content,$_arr_event['event_details']['title'],$_arr_from,$_to,array(),array(),array(),$_options,$iCalString);
					} else {
						_mailsend($_arr_event['event_details']['title'],$content,$_arr_event['event_details']['title'],$_arr_from,$_to,array(),array(),array(),$_options);
					}
				}
			}			
		}
		if($action) {
			$_actionItemToMail = array();
			if(is_array($_arr_event['action_item']) && !empty($_arr_event['action_item'])) {
				foreach($_arr_event['action_item'] as $key=>$actionInfo) {
					$users_email = getEmailAndName($actionInfo['action_owner']);
					if(!empty($users_email[$actionInfo['action_owner']]['id'])) {
						$_actionItemToMail[$users_email[$actionInfo['action_owner']]['id']]['name'] = $users_email[$actionInfo['action_owner']]['name'];
						$_actionItemToMail[$users_email[$actionInfo['action_owner']]['id']]['actitems'][] = $actionInfo;
					}
				}
			}			
			if(is_array($_actionItemToMail) && !empty($_actionItemToMail)) {
				foreach($_actionItemToMail as $email=>$actionitem) {
					//_mailsend($_subject='',$_body_html='',$_plain_txt='',$_arr_from=array(),$_arr_to=array(),$_arr_cc=array(),$_arr_bcc=array(),$_attachment=array(),$_ical='')
							
					$_actitem_str = '';
					$_arr_priority = array();
					if(is_array($actionitem['actitems']) && !empty($actionitem['actitems'])) {
						$i = 1;
						foreach($actionitem['actitems'] as $items) {
							$_actitem_str .= '<tr>
												<td width="3%" align="center" valign="top">'.$i.'</td>
												<td>'.$items['action_item'].'</td>
												<td align="center" valign="top">'.$actionitem['name'].'</td>
												<td align="center" valign="top">'.$items['priority'].'</td>
												<td align="center" valign="top">'.date(DEFAULT_DATE_FORMAT_DATE,$items['estimated_time']).'</td>
												<td align="left" valign="top">'.$items['comment'].'</td>
											</tr> ';
							$_arr_priority[] = $items['priority'];
						$i++;
						}
					}
					$_linktoactivity = $site_url.'list_activity.php';
					$sitelogo =  base_url().'/logos/css_logo.png';
					$project_logo = '';
					/*if(!empty($logo[$momInfo['project_id']]) && file_exists($site_url.'logos/'.$logo[$momInfo['project_id']])) {
						$project_logo = $site_url.'logos/'.$logo[$momInfo['project_id']];
					}*/
					$_arr_from = array();				
					$_arr_from[$_spoc[$_arr_event['event_details']['spoc']]['id']] =  $_spoc[$_arr_event['event_details']['spoc']]['name'];
					$_to = array();
					$_to[$email] = $actionitem['name'];				
					$_template = getEmailTemplate1(1);				
					$search= array('[username]','[momtitle]','[momagenda]','[actionitemlists]','[momactionitemlink]','[logo]','[project_logo]','[momsignature]');
					$replace= array($actionitem['name'],ucfirst($_arr_event['event_details']['title']),$_arr_event['event_details']['agenda'],$_actitem_str,$_linktoactivity,$sitelogo,$project_logo,MOM_SIGNATURE);
					$content = str_replace($search,$replace,$_template);				
					$_subject='Action item for: '.$_arr_event['event_details']['title'];
					$_body_html = $content;
					$_plain_txt = $_arr_event['event_details']['title'];
					$_options = array();
					if(in_array('P1',$_arr_priority)) {
						$_options['priority'] = 'high';
					}
					//_mailsend($_subject='',$_body_html='',$_plain_txt='',$_arr_from=array(),$_arr_to=array(),$_arr_cc=array(),$_arr_bcc=array(),$_attachment=array(),$_options,$_ical='') 
					_mailsend($_subject,$_body_html,$_plain_txt,$_arr_from,$_to,array(),array(),array(),$_options);
					//$_options
				}
			}
			
		}
		
		
	}
}

function getTimeZones() {
	$_timezonelists = DateTimeZone::listIdentifiers (DateTimeZone::ALL);
	return $_timezonelists;
}

function getTimeZones2($key='') {
	$_timezone_lists = array();
	$_timezone_lists['Pacific/Midway'] = array('(GMT-11:00) Midway Island, Samoa','Pacific/Midway','1','Samoa Standard Time');
	$_timezone_lists['Pacific/Honolulu'] = array('(GMT-10:00) Hawaii','Pacific/Honolulu','','Hawaiian Standard Time');
	$_timezone_lists['America/Anchorage'] = array('(GMT-09:00) Alaska','America/Anchorage','','Alaskan Standard Time');
	$_timezone_lists['America/Tijuana'] = array('(GMT-08:00) Baja California','America/Tijuana','','');
	$_timezone_lists['America/Los_Angeles'] = array('(GMT-08:00) Pacific Time (US and Canada)','America/Los_Angeles','1','Pacific Standard Time');
	$_timezone_lists['America/Phoenix'] = array('(GMT-07:00) Arizona','America/Phoenix','','US Mountain Standard Time');
	$_timezone_lists['America/Chihuahua'] = array('(GMT-07:00) Chihuahua, La Paz, Mazatlan','America/Chihuahua','','Mountain Standard Time (Mexico)');
	$_timezone_lists['America/Denver'] = array('(GMT-07:00) Mountain Time (US and Canada)','America/Denver','1','Mountain Standard Time');
	$_timezone_lists['America/Belize'] = array('(GMT-06:00) Central America','America/Belize','','Central America Standard Time');
	$_timezone_lists['America/Chicago'] = array('(GMT-06:00) Central Time (US and Canada)	','America/Chicago','1','Central Standard Time');
	$_timezone_lists['America/Mexico_City'] = array('(GMT-06:00) Guadalajara, Mexico City, Monterrey','America/Mexico_City','','Central Standard Time (Mexico)');
	$_timezone_lists['America/Regina'] = array('(GMT-06:00) Saskatchewan','America/Regina','1','Canada Central Standard Time');
	$_timezone_lists['America/Bogota'] = array('(GMT-05:00) Bogota, Lima, Quito','America/Bogota','','SA Pacific Standard Time');
	$_timezone_lists['America/New_York'] = array('(GMT-05:00) Eastern Time (US and Canada)','America/New_York','','Eastern Standard Time');
	$_timezone_lists['America/Indiana/Indianapolis'] = array('(GMT-05:00) Indiana (East)','America/Indiana/Indianapolis','1','US Eastern Standard Time');
	$_timezone_lists['America/Caracas'] = array('(GMT-04:30) Caracas','America/Caracas','','');
	$_timezone_lists['America/Asuncion'] = array('(GMT-04:00) Asuncion','America/Asuncion','','');
	$_timezone_lists['America/Halifax'] = array('(GMT-04:00) Atlantic Time (Canada)','America/Halifax','','Atlantic Standard Time');
	$_timezone_lists['America/Cuiaba'] = array('(GMT-04:00) Cuiaba','America/Cuiaba','','');
	$_timezone_lists['America/Manaus'] = array('(GMT-04:00) Georgetown, La Paz, Manaus, San Juan','America/Manaus','1','SA Western Standard Time / Central Brazilian Standard Time');
	$_timezone_lists['America/Santiago'] = array('(GMT-04:00) Santiago','America/Santiago','1','Pacific SA Standard Time');
	$_timezone_lists['America/St_Johns'] = array('(GMT-03:30) Newfoundland and Labrador','America/St_Johns','','Newfoundland Standard Time');
	$_timezone_lists['America/Sao_Paulo'] = array('(GMT-03:00) Brasilia','America/Sao_Paulo','1','E. South America Standard Time');
	$_timezone_lists['America/Buenos_Aires'] = array('(GMT-03:00) Buenos Aires	','America/Buenos_Aires','1','SA Eastern Standard Time');
	$_timezone_lists['America/Cayenne'] = array('(GMT-03:00) Cayenne, Fortaleza','America/Cayenne','','');
	$_timezone_lists['America/Godthab'] = array('(GMT-03:00) Greenland','America/Godthab','','Greenland Standard Time');
	$_timezone_lists['America/Montevideo'] = array('(GMT-03:00) Montevideo','America/Montevideo','','');
	$_timezone_lists['America/Bahia'] = array('(GMT-03:00) Salvador','America/Bahia','','');
	$_timezone_lists['America/Noronha'] = array('(GMT-02:00) Mid-Atlantic','America/Noronha','','Mid-Atlantic Standard Time');
	$_timezone_lists['Atlantic/Azores'] = array('(GMT-01:00) Azores','Atlantic/Azores','','Azores Standard Time');
	$_timezone_lists['Atlantic/Cape_Verde'] = array('(GMT-01:00) Cape Verde Islands','Atlantic/Cape_Verde','','Cape Verde Standard Time');
	$_timezone_lists['Europe/London'] = array('(GMT) Greenwich Mean Time : Dublin, Edinburgh, Lisbon, London','Europe/London','','GMT Standard Time');
	$_timezone_lists['Africa/Casablanca'] = array('(GMT) Casablanca, Monrovia','Africa/Casablanca','','Greenwich Standard Time');
	$_timezone_lists['Europe/Amsterdam'] = array('(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna','Europe/Amsterdam','1','W. Europe Standard Time');
	$_timezone_lists['Europe/Belgrade'] = array('(GMT+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague','Europe/Belgrade','','Central Europe Standard Time');
	$_timezone_lists['Europe/Brussels'] = array('(GMT+01:00) Brussels, Copenhagen, Madrid, Paris','Europe/Brussels','','Romance Standard Time');
	$_timezone_lists['Europe/Warsaw'] = array('(GMT+01:00) Sarajevo, Skopje, Warsaw, Zagreb','Europe/Warsaw','','Central European Standard Time');
	$_timezone_lists['Africa/Algiers'] = array('(GMT+01:00) West Central Africa','Africa/Algiers','','W. Central Africa Standard Time');
	$_timezone_lists['Africa/Windhoek'] = array('(GMT+01:00) Windhoek','Africa/Windhoek','','Namibia Standard Time');
	$_timezone_lists['Europe/Athens'] = array('(GMT+02:00) Athens, Bucharest','Europe/Athens','','GTB Standard Time');
	$_timezone_lists['Asia/Beirut'] = array('(GMT+02:00) Beirut','Asia/Beirut','','');
	$_timezone_lists['Africa/Cairo'] = array('(GMT+02:00) Cairo','Africa/Cairo','','Egypt Standard Time');
	$_timezone_lists['Asia/Damascus'] = array('(GMT+02:00) Damascus','Asia/Damascus','','');
	$_timezone_lists['EET'] = array('(GMT+02:00) Eastern Europe','EET','1','E. Europe Standard Time');
	$_timezone_lists['Africa/Harare'] = array('(GMT+02:00) Harare, Pretoria','Africa/Harare','','South Africa Standard Time');
	$_timezone_lists['Europe/Helsinki'] = array('(GMT+02:00) Helsinki, Kiev, Riga, Sofia, Tallinn, Vilnius','Europe/Helsinki','','FLE Standard Time');
	$_timezone_lists['Asia/Istanbul'] = array('(GMT+02:00) Istanbul','Asia/Istanbul','','');
	$_timezone_lists['Asia/Jerusalem'] = array('(GMT+02:00) Jerusalem','Asia/Jerusalem','','Israel Standard Time');
	$_timezone_lists['Asia/Amman'] = array('(GMT+03:00) Amman','Asia/Amman','','');
	$_timezone_lists['Asia/Baghdad'] = array('(GMT+03:00) Baghdad','Asia/Baghdad','','Arabic Standard Time');
	$_timezone_lists['Europe/Kaliningrad'] = array('(GMT+03:00) Kalinigrad, Minsk','Europe/Kaliningrad','','');
	$_timezone_lists['Asia/Kuwait'] = array('(GMT+03:00) Kuwait, Riyadh','Asia/Kuwait','1','Arab Standard Time');
	$_timezone_lists['Africa/Nairobi'] = array('(GMT+03:00) Nairobi','Africa/Nairobi','','E. Africa Standard Time');
	$_timezone_lists['Asia/Tehran'] = array('(GMT+03:30) Tehran','Asia/Tehran','','Iran Standard Time');
	$_timezone_lists['Asia/Muscat'] = array('(GMT+04:00) Abu Dhabi, Muscat','Asia/Muscat','1','Arabian Standard Time');
	$_timezone_lists['Asia/Baku'] = array('(GMT+04:00) Baku','Asia/Baku','1','Azerbaijan Standard Time');
	$_timezone_lists['Europe/Moscow'] = array('(GMT+04:00) Moscow, St. Petersburg, Volgograd','Europe/Moscow','1','Russian Standard Time');
	$_timezone_lists['Indian/Mauritius'] = array('(GMT+04:00) Port Louis','Indian/Mauritius','','');
	$_timezone_lists['Asia/Tbilisi'] = array('(GMT+04:00) Tblisi','Asia/Tbilisi','','Georgian Standard Time');
	$_timezone_lists['Asia/Yerevan'] = array('(GMT+04:00) Yerevan','Asia/Yerevan','','Caucasus Standard Time');
	$_timezone_lists['Asia/Kabul'] = array('(GMT+04:30) Kabul','Asia/Kabul','','Afghanistan Standard Time');
	$_timezone_lists['Asia/Karachi'] = array('(GMT+05:00) Islamabad, Karachi','Asia/Karachi','1','West Asia Standard Time');
	$_timezone_lists['Asia/Tashkent'] = array('(GMT+05:00) Tashkent','Asia/Tashkent','','');
	$_timezone_lists['Asia/Kolkata'] = array('(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi','Asia/Kolkata','','India Standard Time');
	$_timezone_lists['Asia/Colombo'] = array('(GMT+05:30) Sri Jayawardenepura','Asia/Colombo','','Sri Lanka Standard Time');
	$_timezone_lists['Asia/Katmandu'] = array('(GMT+05:45) Kathmandu','Asia/Katmandu','','Nepal Standard Time');
	$_timezone_lists['Asia/Almaty'] = array('(GMT+06:00) Astana','Asia/Almaty','','Central Asia Standard Time');
	$_timezone_lists['Asia/Dhaka'] = array('(GMT+06:00) Dhaka','Asia/Dhaka','1','');
	$_timezone_lists['Asia/Yekaterinburg'] = array('(GMT+06:00) Ekaterinburg','Asia/Yekaterinburg','','Ekaterinburg Standard Time');
	$_timezone_lists['Asia/Rangoon'] = array('(GMT+06:30) Yangon (Rangoon)','Asia/Rangoon','','Myanmar Standard Time');
	$_timezone_lists['Asia/Bangkok'] = array('(GMT+07:00) Bangkok, Hanoi, Jakarta','Asia/Bangkok','','SE Asia Standard Time');
	$_timezone_lists['Asia/Novosibirsk'] = array('(GMT+07:00) Novosibirsk','Asia/Novosibirsk','','Omsk Time');
	$_timezone_lists['Asia/Chongqing'] = array('(GMT+08:00) Beijing, Chongqing, Hong Kong SAR, Urumqi','Asia/Chongqing','1','China Standard Time');
	$_timezone_lists['Asia/Krasnoyarsk'] = array('(GMT+08:00) Krasnoyarsk','Asia/Krasnoyarsk','','North Asia Standard Time');
	$_timezone_lists['Asia/Kuala_Lumpur'] = array('(GMT+08:00) Kuala Lumpur, Singapore','Asia/Kuala_Lumpur','','Singapore Standard Time');
	$_timezone_lists['Australia/Perth'] = array('(GMT+08:00) Perth','Australia/Perth','','W. Australia Standard Time');
	$_timezone_lists['Asia/Taipei'] = array('(GMT+08:00) Taipei','Asia/Taipei','','Taipei Standard Time');
	$_timezone_lists['Asia/Ulaanbaatar'] = array('(GMT+08:00) Ulaanbaatar','Asia/Ulaanbaatar','1','North Asia East Standard Time');
	$_timezone_lists['Asia/Irkutsk'] = array('(GMT+09:00) Irkutsk','Asia/Irkutsk','','');
	$_timezone_lists['Asia/Tokyo'] = array('(GMT+09:00) Osaka, Sapporo, Tokyo','Asia/Tokyo','1','Tokyo Standard Time');
	$_timezone_lists['Asia/Seoul'] = array('(GMT+09:00) Seoul','Asia/Seoul','','Korea Standard Time');
	$_timezone_lists['Australia/Adelaide'] = array('(GMT+09:30) Adelaide','Australia/Adelaide','','Cen. Australia Standard Time');
	$_timezone_lists['Australia/Darwin'] = array('(GMT+09:30) Darwin','Australia/Darwin','','AUS Central Standard Time');
	$_timezone_lists['Australia/Brisbane'] = array('(GMT+10:00) Brisbane','Australia/Brisbane','1','E. Australia Standard Time');
	$_timezone_lists['Australia/Canberra'] = array('(GMT+10:00) Canberra, Melbourne, Sydney','Australia/Canberra','1','AUS Eastern Standard Time');
	$_timezone_lists['Pacific/Guam'] = array('(GMT+10:00) Guam, Port Moresby','Pacific/Guam','','West Pacific Standard Time');
	$_timezone_lists['Australia/Hobart'] = array('(GMT+10:00) Hobart','Australia/Hobart','','Tasmania Standard Time');
	$_timezone_lists['Asia/Yakutsk'] = array('(GMT+10:00) Yakutsk','Asia/Yakutsk','','Yakutsk Standard Time');
	$_timezone_lists['Pacific/Guadalcanal'] = array('(GMT+11:00) Solomon Islands, New Caledonia','Pacific/Guadalcanal','','Central Pacific Standard Time');
	$_timezone_lists['Asia/Vladivostok'] = array('(GMT+11:00) Vladivostok','Asia/Vladivostok','','Vladivostok Standard Time');
	$_timezone_lists['Pacific/Auckland'] = array('(GMT+12:00) Auckland, Wellington','Pacific/Auckland','','New Zealand Standard Time');
	$_timezone_lists['Pacific/Fiji'] = array('(GMT+12:00) Fiji Islands, Kamchatka, Marshall Islands','Pacific/Fiji','','Fiji Standard Time');
	$_timezone_lists['Asia/Magadan'] = array('(GMT+12:00) Magadan','Asia/Magadan','','');
	$_timezone_lists['Pacific/Tongatapu'] = array('(GMT+13:00) Nuku\'alofa','Pacific/Tongatapu','','Tonga Standard Time');
	$_timezone_lists['Pacific/Apia'] = array('(GMT+13:00) Samoa','Pacific/Apia','','');
	if(!empty($key)) {
		if(isset($_timezone_lists[$key])) {
			return $_timezone_lists[$key];			
		} else {
			return array();
		}
	} else {
		return $_timezone_lists;
	}
}

?>