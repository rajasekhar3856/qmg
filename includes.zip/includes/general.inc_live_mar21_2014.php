<?php 
$_SESSION['MY_TITTLE']='QMG-CSS CORP';
function getClientIp() {
		 
		return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0000';
}
	
function getIpTable() {
	$_ipArray = file('./custom/settings/.iptable', FILE_IGNORE_NEW_LINES + FILE_SKIP_EMPTY_LINES);
	return $_ipArray;
}

function ipArrayToRegex($_ipArray) {
	$_return = array();
	foreach ($_ipArray as $_key => $_value) {
		$_value = trim($_value);
		if ($_value) {
			$_value = explode('.', $_value);
			if (4 == count($_value)) {
				$_return[$_key] = '/^' . preg_quote(implode('.', $_value)) . '$/';
			} else {
				$_return[$_key] = '/^' . preg_quote(implode('.', $_value)) . '/';
			}
		}
	}
	return $_return;
}
function pageid($id){
    $pages=array("1"=>"Monitoring User","2"=>"Monitoring Audit","3"=>"Callibration","4"=>"Calibration Audit");    
    return $pages[$id];
}
function blockIp() {
	global $user;
	$allowed = false;
	if($user->user_type != 2 &&  $user->active_role!=6 ) {
		$allowed = false;
		$_userIp    = getClientIp();
		if($_userIp == "::1") {
			$allowed = true;
		} else {
			$_allowedIp = ipArrayToRegex(getIpTable());
			foreach ($_allowedIp as $_regex) {
				if (preg_match($_regex, $_userIp)) {
					$allowed = true;
				}
			}
		}
	} else {
		$allowed = true;
	}
	$allowed = true;
	return $allowed;
}
function subval_sort($a,$subkey,$order='asc') {
    foreach($a as $k=>$v) {
            $b[$k] = strtolower($v[$subkey]);
    }
	if($order == 'asc')
		asort($b);
	else
		arsort($b);
    foreach($b as $key=>$val) {
            $c[] = $a[$key];
    }
    return $c;
}
function ExcelToPHP($dateValue = 0, $ExcelBaseDate = 1900) {
    if ($ExcelBaseDate == 1900) {
        $myExcelBaseDate = 25569;
        //    Adjust for the spurious 29-Feb-1900 (Day 60)
        if ($dateValue < 60) {
            --$myExcelBaseDate;
        }
    } else {
        $myExcelBaseDate = 24107;
    }

    // Perform conversion
    if ($dateValue >= 1) {
        $utcDays = $dateValue - $myExcelBaseDate;
        $returnValue = round($utcDays * 86400);
        if (($returnValue <= PHP_INT_MAX) && ($returnValue >= -PHP_INT_MAX)) {
            $returnValue = (integer) $returnValue;
        }
    } else {
        $hours = round($dateValue * 24);
        $mins = round($dateValue * 1440) - round($hours * 60);
        $secs = round($dateValue * 86400) - round($hours * 3600) - round($mins * 60);
        $returnValue = (integer) gmmktime($hours, $mins, $secs);
    }

    // Return
    return $returnValue;
}
function ExcelToPHPObject($dateValue = 0, $ExcelBaseDate = 1900) {
    $dateTime = ExcelToPHP($dateValue, $ExcelBaseDate);
    $days = floor($dateTime / 86400);
    $time = round((($dateTime / 86400) - $days) * 86400);
    $hours = round($time / 3600);
    $minutes = round($time / 60) - ($hours * 60);
    $seconds = round($time) - ($hours * 3600) - ($minutes * 60);
//	echo "<br>===>ss".$days."===".$hours."===".$minutes."===".$seconds;
    $dateObj = date_create('1-Jan-1970+'.$days.' days');
    $dateObj->setTime($hours,$minutes,$seconds);

    return $dateObj;
}

function find_week($ddate){
$duedt = explode("-", $ddate);
$date  = mktime(0, 0, 0, $duedt[1], $duedt[2], $duedt[0]);
$week  = (int)date('W', $date);
return $week;
}

function work_flow_processes() {
	$_arr_workflow = array('evaluation_done'=>'Evaluation Done','evaluation_done_fail'=>'Evaluation Done - Failed Transactions','coaching_done'=>'Coaching Done','coaching_accepted'=>'Coaching Accepted','coaching_escalated'=>'Coaching Escalated','coaching_escalation_com'=>'Coaching Escalation Comments');
	return $_arr_workflow;
}

function work_flow_processes_templates($_process) {
	$_arr_workflow = array('evaluation_done'=>1,'evaluation_done_fail'=>1,'coaching_done'=>2,'coaching_accepted'=>3,'coaching_escalated'=>4,'coaching_escalation_com'=>5);
	return $_arr_workflow[$_process];
}
function work_flow_processes_templates_bysheet($_sheet,$_process) {
	$_arr_workflow = array();
	//$_arr_workflow = array(1=>array('evaluation_done'=>1,'evaluation_done_fail'=>2,'coaching_done'=>3,'coaching_accepted'=>4,'coaching_escalated'=>5,'coaching_escalation_com'=>6));
	return (isset($_arr_workflow[$_sheet][$_process])?$_arr_workflow[$_sheet][$_process]:false);
}

function select_workflow_template($_sheet,$_process) {
	$template_id = work_flow_processes_templates_bysheet($_sheet,$_process);
	if(!$template_id) {
		$template_id = work_flow_processes_templates($_process);
	} 
	return $template_id;
	
}

function parse_template($_sheet,$_process,$replacements) {	
	/*$replacements = array(
	   'tl' => 'mytlname',
	   'agent' => 'myname',
	);*/
	$template_id = select_workflow_template($_sheet,$_process);	
	$sql = "SELECT * FROM `tm_email_templates` WHERE template_id=".$template_id;
	$result = cameo_query($sql);
	$_parsed_array = array();
	if(cameo_num_rows($result) > 0) {
		$row = cameo_fetch_object($result);
		//print_r($row);
		//\{\{ *form *\| *(\S+) *\}\}
		$template_to = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			return $replacements[strtolower($match[1])];
		}, $row->template_to);
		$template_cc = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			return $replacements[strtolower($match[1])];
		}, $row->template_cc);
		$template_bcc = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			return $replacements[strtolower($match[1])];
		}, $row->template_bcc);
		$template_subject = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			$_arr_result = explode(".",$match[1]);
			if(count($_arr_result)>1) {
				return $replacements[strtolower($_arr_result[0])][$_arr_result[1]];
			} else {
				return $replacements[strtolower($_arr_result[0])];
			}
		}, $row->template_subject);
		$template_content = preg_replace_callback('/\{*(\S+)\}/', function ($match)
			use ($replacements) {
			$_arr_result = explode(".",$match[1]);
			if(count($_arr_result)>1) {
				return $replacements[strtolower($_arr_result[0])][$_arr_result[1]];
			} else {
				return $replacements[strtolower($_arr_result[0])];
			}
		}, $row->template_content);
		$_parsed_array =  array('template_to'=>$template_to,'template_cc'=>$template_cc,'template_bcc'=>$template_bcc,'template_subject'=>$template_subject,'template_content'=>$template_content);
		
	}
	return $_parsed_array;
}   

function category_name($cat_id){
    $cat="SELECT  category_name FROM tm_categories_mas Where category_id=".$cat_id;
    $category = cameo_query($cat);
    $category_data = cameo_fetch_object($category);
    return $category_data->category_name;
}

function question_name($que_id){
    $quest="SELECT  question_name FROM tm_questions_mas Where question_id=".$que_id;
    $question = cameo_query($quest);
    $question_data = cameo_fetch_object($question);
    return $question_data->question_name;
}

function answer_name($ans_id){
    $answ="SELECT  answer FROM tm_answer_mas Where answer_id=".$ans_id;
    $answer = cameo_query($answ);
    $answer_data = cameo_fetch_object($answer);
    return $answer_data->answer;
}

function evaluation_details($_eval_id) {
	$tid = $_eval_id;
	$headsql = "SELECT m.eval_id_pk, m.emp_id, m.emp_reporting_1 as reporting_1, m.emp_reporting_2 as reporting_2, m.project_id,m.sheet_id,m.monitor_by, m.monitor_by_role as role_id,
                m.monitor_date, m.overall_score, m.trans_status, m.coaching_type,m.trans_type,m.direction_type,
                m.call_duration, m.cls_id, m.cls_date,m.case_no, nt.ntrans_name, tq.qtrans_name, mt.mtype_name, 
                g.geography_name, prj.project_name, 
                usr.name, usr1.name as monitor_name, usr2.name as tl_name, usr3.name as rep_name
                FROM tm_user_monitoring_mas m 
                LEFT JOIN tm_geography_mas g ON g.geography_id=m.geography_id
                LEFT JOIN tm_projects_mas prj ON prj.project_id = m.project_id 
                LEFT JOIN tm_nature_transaction_mas nt ON nt.ntrans_id =m.trans_nature
                LEFT JOIN tm_monitoring_type_mas mt ON mt.mtype_id = m.monitor_type
                LEFT JOIN tm_transaction_quality_mas tq ON tq.qtrans_id = m.trans_quality 
                LEFT JOIN tm_user_mas usr ON usr.emp_id = m.emp_id 
                LEFT JOIN tm_user_mas usr1 ON usr1.emp_id = m.monitor_by 
                LEFT JOIN tm_user_mas usr2 ON usr2.emp_id = m.emp_reporting_1  
                LEFT JOIN tm_user_mas usr3 ON usr3.emp_id = m.emp_reporting_2                
                WHERE m.eval_id_pk=%d";
   $headrs = cameo_query($headsql, $tid);  
   
   while($headrow = cameo_fetch_object($headrs)) {
       $data['headers'] = $headrow;
   }
   $cfheader = "SELECT scf.cf_id, cf.cf_name, cf.cf_type FROM tm_sheet_custom_field_map scf 
                LEFT JOIN  tm_user_monitoring_mas mon ON mon.sheet_id=scf.sheet_id 
                LEFT JOIN tm_custom_field_mas cf ON cf.cf_id=scf.cf_id
                WHERE mon.eval_id_pk=%d";
   $cfheadrs = cameo_query($cfheader, $tid);
   while($cfheadrow = cameo_fetch_object($cfheadrs)) {
       $data["cfheaders"][$cfheadrow->cf_id]["name"] = $cfheadrow->cf_name;
        if($cfheadrow->cf_type==1 || $cfheadrow->cf_type==2){
            $cfs[] = "m.cf_$cfheadrow->cf_id"; 
        } else if($cfheadrow->cf_type==3 || $cfheadrow->cf_type==4){
            $cfs[] = "cft_$cfheadrow->cf_id.text cf_$cfheadrow->cf_id";
            $cftb .= "LEFT JOIN tm_custom_field_options_trans cft_$cfheadrow->cf_id ON cft_$cfheadrow->cf_id.cf_id_fk='$cfheadrow->cf_id' and m.cf_$cfheadrow->cf_id=cft_$cfheadrow->cf_id.cf_opt_id ";
        }
   }
   $cfdsql = "SELECT ". implode(",",$cfs)." FROM tm_user_monitoring_headers_trans m $cftb WHERE m.eval_id_fk=%d";
   $cfdrs = cameo_query($cfdsql,$tid);
   
   foreach($data["cfheaders"] as $cfkey=>$cfd) {
       $data["cfheaddata"][] = array($cfd["name"], cameo_result($cfdrs, 0,"cf_".$cfkey));
   }
   $gsql = "SELECT ctgy.category_id, ctgy.category_name, q.question_id, q.question_name,a.answer, mt.comments, mt.score, crtl.color , crtl.critical_name, crtl.short_code
            FROM tm_user_monitoring_tmf_trans mt 
            LEFT JOIN tm_categories_mas ctgy ON ctgy.category_id=mt.category_id 
            LEFT JOIN tm_questions_mas q ON q.question_id=mt.question_id
            LEFT JOIN tm_answer_mas a ON a.answer_id=mt.answer_id
	    LEFT JOIN tm_criticals_mas crtl ON crtl.critical_id=mt.critical_id
            WHERE mt.eval_id_fk =%d ORDER BY mt.fk_tree_id ASC";
   
   $grs = cameo_query($gsql, $tid);
   while($grow = cameo_fetch_object($grs)) {
       $data['gradings'][$grow->category_id]["name"] = $grow->category_name;
       $data['gradings'][$grow->category_id]["questions"][$grow->question_id] = array($grow->question_name,$grow->answer, $grow->score,$grow->comments, $grow->color, $grow->critical_name, $grow->short_code);
   }
   $tmfcrtsql = "SELECT * FROM `tm_user_monitoring_tmf_criticals_trans` tmfctrns
                LEFT JOIN tm_form_type_mas ft ON ft.form_type_id =tmfctrns.form_type_id 
                WHERE eval_id_fk=%d";
   $tmfcrtrs = cameo_query($tmfcrtsql, $tid);
   $tmfcrtrow = cameo_fetch_object($tmfcrtrs);
   $crtlsql = "SELECT * FROM `tm_criticals_mas` WHERE `default`=1";
   $crtlrs = cameo_query($crtlsql);
   
   while($crtlrow = cameo_fetch_object($crtlrs)) {
       $cid = $crtlrow->critical_id;
       if($tmfcrtrow->{c.$cid._id}!=NULL) {
       $data['criticals'][$crtlrow->form_type_id]["name"] = $tmfcrtrow->form_type_name;
       $data['criticals'][$crtlrow->form_type_id]["critical"][$crtlrow->critical_id] = array($crtlrow->critical_name, $tmfcrtrow->{c.$cid._score});
       }
   }
   
   $crtsql = "SELECT crts.critical_id, crts.critical_name, ft.form_type_id,ft.form_type_name, ct.score FROM tm_user_monitoring_criticals_trans ct 
            LEFT JOIN tm_criticals_mas crts ON crts.critical_id= ct.critical_id
            LEFT JOIN tm_form_type_mas ft ON ft.form_type_id = ct.form_type_id WHERE ct.eval_id_fk =%d";
   $crtrs = cameo_query($crtsql, $tid);
   while($crtrow = cameo_fetch_object($crtrs)) {
       $data['criticals'][$crtrow->form_type_id]["name"] = $crtrow->form_type_name;
       $data['criticals'][$crtrow->form_type_id]["critical"][$crtrow->critical_id] = array($crtrow->critical_name, $crtrow->score);

   }
	$replacements=array();	
	$replacements['agent_id'] = $data['headers']->emp_id;
	$replacements['tl_id'] = $data['headers']->reporting_1;
	$replacements['tm_id'] = $data['headers']->reporting_2;		
	$replacements['project_id'] = $data['headers']->project_id;
	$replacements['sheet_id'] = $data['headers']->sheet_id;
	$replacements['monitor_by_id'] = $data['headers']->monitor_by;
	$replacements['monitor_by_role_id'] = $data['headers']->role_id;
	$emp_ids = $data['headers']->emp_id.','.$data['headers']->reporting_1.','.$data['headers']->reporting_2.','.$data['headers']->monitor_by;
	$_email_arr = get_email_address($emp_ids);
	$replacements['agent_email'] = (isset($_email_arr[$data['headers']->emp_id]))?$_email_arr[$data['headers']->emp_id]['email']:'';
	$replacements['tl_email'] = (isset($_email_arr[$data['headers']->reporting_1]))?$_email_arr[$data['headers']->reporting_1]['email']:'';
	$replacements['tm_email'] = (isset($_email_arr[$data['headers']->reporting_2]))?$_email_arr[$data['headers']->reporting_2]['email']:'';
	$replacements['monitor_by_email'] = (isset($_email_arr[$data['headers']->monitor_by]))?$_email_arr[$data['headers']->monitor_by]['email']:'';
	
	
	$replacements['agent_name'] = (isset($_email_arr[$data['headers']->emp_id]))?$_email_arr[$data['headers']->emp_id]['name']:'';
	$replacements['tl_name'] = (isset($_email_arr[$data['headers']->reporting_1]))?$_email_arr[$data['headers']->reporting_1]['name']:'';
	$replacements['tm_name'] = (isset($_email_arr[$data['headers']->reporting_2]))?$_email_arr[$data['headers']->reporting_2]['name']:'';		
	$replacements['project_name'] = get_project_name($data['headers']->project_id);
	$replacements['sheet_name'] = get_sheet_name($data['headers']->sheet_id);
	$replacements['monitor_by_name'] = (isset($_email_arr[$data['headers']->monitor_by]))?$_email_arr[$data['headers']->monitor_by]['name']:'';
	$replacements['monitor_by_role_name'] = get_role_name($data['headers']->role_id);
	
	$replacements['monitoring_details'] = (array)$data['headers'];
	
   
   return $replacements;
   
}

function send_workflow_email($_sheet,$_process,$replacements=array(),$bmsg=false,$bsub=false) {
	$sql = "SELECT email_enabled,email_workflow FROM tm_sheets_mas WHERE sheet_id='%d'";
	//echo sprintf($sql,$_sheet);
	$result_set = cameo_query($sql,$_sheet);
	if(cameo_num_rows($result_set) > 0) {
		$_allowed_workflow = array();
		$row = cameo_fetch_object($result_set);
		if(!empty($row->email_workflow)) {
			$_allowed_workflow = explode(",",$row->email_workflow);
		}
		//print_r($_allowed_workflow);
		if($row->email_enabled == 1  && in_array($_process,$_allowed_workflow) ) {			
			$_parsed_array = parse_template($_sheet,$_process,$replacements);
			if(!empty($_parsed_array)) {
				//Sent mail to configred mails
				if($bmsg !== false ) {
				//Template already ready so just send
					$_parsed_array['template_content'] = $bmsg;
				} 
				if($bsub !== false) {
				//Template already ready so just send
					$_parsed_array['template_subject'] = $bsub;
				}
				$to_address = get_email_address(substr(trim($_parsed_array['template_to']), 0, -1));
				$cc_address = get_email_address(substr(trim($_parsed_array['template_cc']), 0, -1));
				$bcc_address = get_email_address(substr(trim($_parsed_array['template_bcc']), 0, -1));
				$_mail_array = array();
				$_mail_array['to'] = $to_address;
				$_mail_array['cc'] = $cc_address;
				$_mail_array['bcc'] = $bcc_address;
				$_mail_array['subject'] = trim($_parsed_array['template_subject']);
				$_mail_array['body'] = trim($_parsed_array['template_content']);
				//print_r($_mail_array);
				sendmail($_mail_array);
			} 
		}
	}
	//exit;
}

function get_email_address($emp_ids) {
	$_sql = "SELECT emp_id,email_id,name FROM tm_user_mas WHERE emp_id IN($emp_ids)";
	$_rset = cameo_query($_sql);
	$_email_arr = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset)) {
			$_email_arr[$row->emp_id] = array('name'=>$row->name,'email'=>$row->email_id);
		}
	}
	return $_email_arr;
}

function get_project_name($_project_id) {
	$_sql = "SELECT project_name FROM tm_projects_mas WHERE project_id = $_project_id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->project_name;
	}
	return '';
}

function critical_name($id){
    $_sql = "SELECT critical_name FROM tm_criticals_mas WHERE critical_id = $id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->critical_name;
	}
	return '';
}

function user_name($id){
    $_sql = "SELECT name FROM tm_user_mas WHERE emp_id = $id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->name;
	}
	return '';
}

function get_first_letter($string){
        $temp = explode(' ', $string);
        $result = '';
        foreach($temp as $t)
            $result .= $t[0];

        return strtoupper($result);
    }

function get_sheet_name($_sheet_id) {
	$_sql = "SELECT sheet_name FROM tm_sheets_mas WHERE sheet_id = $_sheet_id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->sheet_name;
	}
	return '';
}

function get_role_name($_role_id) {
	$_sql = "SELECT user_role_name FROM tm_user_role_mas WHERE user_role_id = $_role_id";
	$_rset = cameo_query($_sql);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
		return $row->user_role_name;
	}
	return '';
}

function sendmail($_mail_array) {
	$mail = new PHPMailer(true);
	try {
		//$mail->SetFrom('mahesh.mahendran@csscorp.com', 'Mahesh M');
		$mail->AddReplyTo('noreply-qmg@csscorp.com', 'Quality Management Group');
		if(!empty($_mail_array['to'])) {
			foreach($_mail_array['to'] as $emails) {
				if (filter_var($emails['email'], FILTER_VALIDATE_EMAIL)) {
					$mail->AddAddress($emails['email'], $emails['name']);
				}
			}
		}
		if(!empty($_mail_array['cc'])) {
			foreach($_mail_array['cc'] as $emails) {
				if (filter_var($emails['email'], FILTER_VALIDATE_EMAIL)) {
					$mail->AddCC($emails['email'], $emails['name']);
				}
			}
		}
		if(!empty($_mail_array['bcc'])) {
			foreach($_mail_array['bcc'] as $emails) {
				if (filter_var($emails['email'], FILTER_VALIDATE_EMAIL)) {
					$mail->AddBCC($emails['email'], $emails['name']);
				}
			}
		}
		$mail->Subject = $_mail_array['subject'];
		$mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // optional - MsgHTML will create an alternate automatically
		$mail->MsgHTML($_mail_array['body']);
		$mail->Send();
		//print_r($mail);		
	} catch (phpmailerException $e) {
		echo $e->errorMessage();
	} catch (Exception $e) {
		echo $e->errorMessage();
	}
}

function getIsoWeeksInYear($year) {
	$date = new DateTime;
	$date->setISODate($year, 53);
	return ($date->format("W") === "53" ? 53 : 52);
}

function getStartAndEndDate($week, $year) {
	$date_string = $year . 'W' . sprintf('%02d', $week);
	$return[0] = date('Y-m-d', strtotime($date_string));
	$return[1] = date('Y-m-d', strtotime($date_string . '7'));
	return $return;
}

function getweeks($month,$year) {
    $months = array(1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December');
    $ts = strtotime("$months[$month] $year");
    $firstdate=date('Y-m-01', $ts);
    $lastdate=date('Y-m-t', $ts);
    $stweek=date('W',  strtotime($firstdate));
    $ltweek=date('W',  strtotime($lastdate));
	$weeks = array();
    for ($week=$stweek; $week<=$ltweek; $week++) {
       $weeks[] = (int)$week.'-'.$year;
    }    
    return $weeks;    
}

function screen_status($status,$param=''){
    if($status==1)
        $current_status='Waiting for TL/TM Approval';
    else if($status==2 && $param==0)
        $current_status='Declined by TL/TM';
    else if($status==2 && $param!=0)
        $current_status='Declined by TL/TM-Parameter';
    else if($status==3)
        $current_status='Improved Suggestion';
//    else if($status==4)
//        $current_status='Declined by Agent';
    else if($status==5)
        $current_status='TL/TM Accepted, Waiting for Manager Approval';
    else if($status==6)
        $current_status='Need Improvement by TL/TM';

    else if($status==8)
        $current_status='Accepted By Manager';
    else if($status==9)
        $current_status='Declined By Manager';
    else if($status==10)
        $current_status='Implementation status';
    else if($status==11)
        $current_status='Waiting for Certification';
     else if($status==12)
        $current_status='Implementation status-Yes';
      else if($status==13)
        $current_status='Implementation status-No';
       else if($status==14)
        $current_status='Implementation status-Pending';
    
    
    return $current_status;
    
}

function page_name($name){
    $select_name='Select module_name from fw_modules_mas Where page LIKE "%'.$name.'/%"  ORDER BY uid DESC  LIMIT 0,1';
   
    $_rset = cameo_query($select_name);
	if(cameo_num_rows($_rset) > 0) {
		$row = cameo_fetch_object($_rset);
                return ucfirst(str_replace("_", " ", $row->module_name));
        }else{
            $exp_name=explode($name);
            if($name=='/'){
                 return 'Home';
            }elseif ($exp_name[0]=='default') {
                  return 'Home';
             }else{            
             return 'Home';
             }
        }
}

function folder_tree($archive=0) {
    global $user;
    if($archive==0)
    $deleted=' AND tm_folder_mas.deleted=0 ';
else
    $deleted='';
	$select_name="select tm_folder_mas.*, (select count(distinct c1.folder_id) from tm_folder_mas as c1   where c1.folder_pararent_id = tm_folder_mas.folder_id ) as ChildCount from tm_folder_mas WHERE 1 $deleted  AND status=1 order by folder_order";
	$_rset = cameo_query($select_name);
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[] = $row;
		}
	}
	return $rows;	
}

function product_list($name='',$archive=0) { global $user;
if($archive==0)
    $deleted=' AND tm_documents_mas.deleted=0 ';
else
    $deleted='';
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND pfm.project_id='".$user->project_active."' AND pfm.sheet_id='".$user->project_skill."' AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id NOT IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .= " AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}

function product_list_common($name='',$archive=0) { global $user;
if($archive==0)
    $deleted=' AND tm_documents_mas.deleted=0 ';
else
    $deleted='';
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .=" AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}



function recurse($folder_tree, $parent = null, $level = 0,$product_list= array(),$archive=0) {
    if($archive==0)
        $id='browser';
     else
        $id='browser-1';
    
	if($level == 0) {
		$ret = '<ul id="'.$id.'" class="filetree">';
	} else {
		$ret = '<ul>';
	}
    foreach($folder_tree as $index => $_tree)
    {
        if($_tree->folder_pararent_id == $parent)
        {
            $ret .= '<li><span class="folder">' . $_tree->folder_name . '</span></a>';
            if($_tree->ChildCount > 0)
                $ret .= recurse($folder_tree, $_tree->folder_id, $level+1,$product_list);
			 
			 $ret .= product($product_list,$_tree->folder_id);
            $ret .= '</li>';
        }
    }
    return $ret . '</ul>';
}

function product($product_list, $folder_id = '') {	
	 $plist = '';
	if(is_array($product_list[$folder_id]) && !empty($product_list[$folder_id])) {
		 $plist = '<ul id="folder'.$folder_id.'">';
		foreach($product_list[$folder_id] as $index => $_product)
		{
			if($_product->version_no==0)
                            $_product->version_no='1.0';
			$plist .= '<li><span class="file" doc_id="'.$_product->doc_id.'" unique_id="'.$_product->doc_path.'" exet="'.$_product->doc_ext.'">' . $_product->doc_name . ' - V '.$_product->version_no.'</span>';
			$plist .= '</li>';
			
		}
		 $plist .= '</ul>';
	}
    return $plist;
}

//************************************************************ List Folder *********************************************************/

function folder_tree_list($archive=0) {
    global $user;
  $deleted=' AND tm_folder_mas.deleted=0 ';
	$select_name="select tm_folder_mas.*, (select count(distinct c1.folder_id) from tm_folder_mas as c1   where c1.folder_pararent_id = tm_folder_mas.folder_id ) as ChildCount from tm_folder_mas WHERE 1 $deleted  AND status=1 order by folder_order";
	$_rset = cameo_query($select_name);
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[] = $row;
		}
	}
	return $rows;	
}

function product_list_list($name='',$archive=0) { global $user;
$deleted=' AND tm_documents_mas.deleted=0 ';
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND pfm.project_id='".$user->project_active."' AND pfm.sheet_id='".$user->project_skill."' AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id NOT IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .= " AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}

function product_list_common_list($name='',$archive=0) { global $user; 
    $deleted=' AND tm_documents_mas.deleted=0 '; 
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND tm_documents_mas.archive='".$archive."' AND tm_documents_mas.folder_id IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .=" AND tm_documents_mas.document_status=3 GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}



function recurse_list($folder_tree, $parent = null, $level = 0,$product_list= array(),$archive=0) {
    if($archive==0)
        $id='browser';
     else
        $id='browser-1';
    
	if($level == 0) {
		$ret = '<ul id="'.$id.'" class="filetree">';
	} else {
		$ret = '<ul>';
	}
        $i=0;
    foreach($folder_tree as $index => $_tree)
    {
        if($_tree->folder_pararent_id == $parent)
        {
            $ret .= '<li   id="del_'.$_tree->folder_id.'" ><span class="folder">' . $_tree->folder_name . ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit/'.$_tree->folder_id.'"><img src='.base_path(). path_to_theme().'/images/edit_icon.png /></a> &nbsp;<a href="#" id="delete_'.$i.'_'.$_tree->folder_id.'" class="delete"><img src='.base_path(). path_to_theme().'/images/remove.jpeg /></a>';
			if($_tree->ChildCount > 0)
				$ret .= '&nbsp;<img src="'.base_path(). path_to_theme().'/images/sort.jpeg" class="im_g" style="cursor: pointer;"   onclick=$("#sortid").val('.$_tree->folder_id.') />';
			$ret .= '</span>';
            if($_tree->ChildCount > 0)
                $ret .= recurse_list($folder_tree, $_tree->folder_id, $level+1,$product_list);
			 
			 
            $ret .= '</li>';
        }
		$i++;
	}
    return $ret . '</ul>';
}

 
/********************************************** End List Folder******************************************************************/



/************************************************************ List Folder Document *********************************************************/


function folder_tree_document($archive=0) {
    global $user;    
    $deleted=' AND tm_folder_mas.deleted=0 ';
 
	$select_name="select tm_folder_mas.*, (select count(distinct c1.folder_id) from tm_folder_mas as c1   where c1.folder_pararent_id = tm_folder_mas.folder_id ) as ChildCount from tm_folder_mas WHERE 1 $deleted  AND status=1 order by folder_order";
	$_rset = cameo_query($select_name);
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[] = $row;
		}
	}
	return $rows;	
}

function product_list_document($name='',$archive=0) { global $user;
 
    $deleted=' AND tm_documents_mas.deleted=0 ';
 
	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1 AND pfm.project_id='".$user->project_active."' AND pfm.sheet_id='".$user->project_skill."'   AND tm_documents_mas.folder_id NOT IN(1,5) AND tm_documents_mas.status=1  ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .= "  GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}

function product_list_common_document($name='',$archive=0) { global $user;

    $deleted=' AND tm_documents_mas.deleted=0 ';

	$select_name="select tm_documents_mas.* from tm_documents_mas
                   LEFT JOIN tm_project_folder_map pfm ON pfm.document_id=tm_documents_mas.doc_id
                   WHERE 1    ".$deleted;// AND tm_documents_mas.archive='".$archive."'
	if(!empty($name)) {
		$select_name .=" AND doc_name like '%".$name."%' ";
	}
	$select_name .="   GROUP BY tm_documents_mas.doc_id ORDER BY sort " ;
	 
	$_rset = cameo_query( $select_name );
	$rows = array();
	if(cameo_num_rows($_rset) > 0) {
		while($row = cameo_fetch_object($_rset) ) {			
			$rows[$row->folder_id][] = $row;
		}
	}
	return $rows;	
}



function recurse_document($folder_tree, $parent = null, $level = 0,$product_list= array(),$archive=0) {
    if($archive==0)
        $id='browser';
     else
        $id='browser-1';
    
	if($level == 0) {
		$ret = '<ul id="'.$id.'" class="filetree">';
	} else {
		$ret = '<ul>';
	}
    foreach($folder_tree as $index => $_tree)
    {
        if($_tree->folder_pararent_id == $parent)
        {    
            $sort='';
            if(is_array($product_list[$_tree->folder_id]) && !empty($product_list[$_tree->folder_id])) 
             $sort='&nbsp;<img src="'.base_path(). path_to_theme().'/images/sort.jpeg" class="im_g" style="cursor: pointer;"   onclick=$("#sortid").val('.$_tree->folder_id.') />';
            
            $ret .= '<li><span class="folder">' . $_tree->folder_name . $sort.'</span>';
            if($_tree->ChildCount > 0)
                $ret .= recurse_document($folder_tree, $_tree->folder_id, $level+1,$product_list);
			 
			 $ret .= product_document($product_list,$_tree->folder_id);
                         
            $ret .= '</li>';
        }
    }
    return $ret . '</ul>';
}


function product_document($product_list, $folder_id = '') {	
	 $plist = '';
	if(is_array($product_list[$folder_id]) && !empty($product_list[$folder_id])) {
		 $plist = '<ul id="folder'.$folder_id.'">';
                 $i=0;
		foreach($product_list[$folder_id] as $index => $_product)
		{
			if($_product->version_no==0)
                            $_product->version_no='1.0';
			$plist .= '<li><span class="file" doc_id="'.$_product->doc_id.'" unique_id="'.$_product->doc_path.'" exet="'.$_product->doc_ext.'">' . $_product->doc_name . ' - V '.$_product->version_no.' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit/'.$_product->doc_id.'"><img src='.base_path(). path_to_theme().'/images/edit_icon.png /></a> &nbsp;<a href="#" id="delete_'.$i.'_'.$_product->doc_id.'" class="delete"><img src='.base_path(). path_to_theme().'/images/remove.jpeg /></a></span>';
			$plist .= '</li>';
		$i++;	
		}
		 $plist .= '</ul>';
	}
    return $plist;
}
/********************************************** End List Folder document******************************************************************/


function document_status($st){
    $status=array(
         "0"=>"Wating for Review",
        "1"=>"Approved By reviewer",
        "2"=>"Declined By reviewer",
        "3"=>"Approved By Approver",
        "4"=>"Declined By Approver"
    );
    return $status[$st];
}

?>